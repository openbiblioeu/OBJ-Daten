window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1587411424145555456",
      "fullText" : "@kfnhannover @TGRuediger Meldet mal bitte bei @OpenBiblioJobs.",
      "expandedUrl" : "https://twitter.com/i/web/status/1587411424145555456"
    }
  },
  {
    "like" : {
      "tweetId" : "1546442674072420352",
      "fullText" : "@OpenBiblioJobs #Congratulations 🎉 schön das es sie gibt. https://t.co/zVtlKdFYAA",
      "expandedUrl" : "https://twitter.com/i/web/status/1546442674072420352"
    }
  },
  {
    "like" : {
      "tweetId" : "1563062880047575041",
      "fullText" : "Hinweise für Fristverlängerungen von Stellen in OpenBiblioJobs - https://t.co/GitfqAkzx8 -  https://t.co/aW5jXoXOmi (DB) (cc @OpenBiblioJobs )",
      "expandedUrl" : "https://twitter.com/i/web/status/1563062880047575041"
    }
  },
  {
    "like" : {
      "tweetId" : "1560687882939076608",
      "fullText" : "Vielleicht ist das ja auch eine Möglichkeit für mehr Bewerber*innen - allerdings vielleicht statt YouTube gleich auf TicToc. Könnte ich mir zumindest für Ausbildungsstellen gut vorstellen. https://t.co/OxEveRYkqv",
      "expandedUrl" : "https://twitter.com/i/web/status/1560687882939076608"
    }
  },
  {
    "like" : {
      "tweetId" : "1554918806778150912",
      "fullText" : "@OpenBiblioJobs  Dank an euch es hat geklappt!",
      "expandedUrl" : "https://twitter.com/i/web/status/1554918806778150912"
    }
  },
  {
    "like" : {
      "tweetId" : "1552878667616948225",
      "fullText" : "@OpenBiblioJobs Stimmt, da scheint eine Zeile zu viel drin zu sein. Wir geben das weiter. Danke!",
      "expandedUrl" : "https://twitter.com/i/web/status/1552878667616948225"
    }
  },
  {
    "like" : {
      "tweetId" : "1524831665410953231",
      "fullText" : "Stellenangebote bei @OpenBiblioJobs freischalten: 23 Stück warten auf Überprüfung. Bitte mal Daumen drücken, dass bei den wenigsten noch Ergänzungen notwendig werden oder erst nachrecherchiert werden müssen, weil kein Permalink verwendet wurde.  - War ein langer Tag heute.",
      "expandedUrl" : "https://twitter.com/i/web/status/1524831665410953231"
    }
  },
  {
    "like" : {
      "tweetId" : "1518273454461657090",
      "fullText" : "@OpenBiblioJobs @KarinSchwarzFHP Und ganz herzlichen Dank fürs Retweeten der Stellenausschreibung (tolle Sichtbarkeit) und auch, dass wir auf die Antworten aufmerksam gemacht wurden! @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/1518273454461657090"
    }
  },
  {
    "like" : {
      "tweetId" : "1516062182663983120",
      "fullText" : "Müttercafé // Материнське кафе \n21.4., 16:30-17:30 Uhr\n27.4., 10:30-11:30 Uhr\nBeim Müttercafé in der Kinderbibliothek haben ukrainische Mütter mit ihren Kindern die Möglichkeit, sich mit anderen Müttern auszutauschen.\nTeilnahme kostenlos. Anmeldung unter: Telefon 0621 293 8916. https://t.co/uTOUMqhmmM",
      "expandedUrl" : "https://twitter.com/i/web/status/1516062182663983120"
    }
  },
  {
    "like" : {
      "tweetId" : "1515314565831028736",
      "fullText" : "итання дітям українською мовою з Оленою Хайндл (20.04., 14:00)\nДітям: 4-6 років\nБезкоштовно\n\nБажаючих просимо зареєструватися:\nсамостійно в бібліотеці, по телефону: 4000-15165 або пишить на ел.адресу: kinderbuechereimeiselmarkt@buechereien.wien.gv.at",
      "expandedUrl" : "https://twitter.com/i/web/status/1515314565831028736"
    }
  },
  {
    "like" : {
      "tweetId" : "1515314314059517953",
      "fullText" : "Am 20.04. (14h) findet in unserer Kinderbücherei der Weltsprachen eine Vorlesestunde auf Ukrainisch statt. Anmeldung telefonisch (4000-15165) oder per E-Mail: kinderbuechereimeiselmarkt@buechereien.wien.gv.at https://t.co/njtpW1zUQh",
      "expandedUrl" : "https://twitter.com/i/web/status/1515314314059517953"
    }
  },
  {
    "like" : {
      "tweetId" : "1511711133564084225",
      "fullText" : "Drei aus der Ukraine geflüchtete Bibliothekarinnen wohnen bei uns in Dienst-Appartements und arbeiten an Büroplätzen. Mit Stipendien unterstützen wir sie finanziell. Patinnen aus dem Haus helfen bei allen Fragen. Heute zeigen wir ihnen unsere Frankfurter Bibliothek. https://t.co/S2vlr0qsrj",
      "expandedUrl" : "https://twitter.com/i/web/status/1511711133564084225"
    }
  },
  {
    "like" : {
      "tweetId" : "1509893970716995592",
      "fullText" : "Das Wochenende steht vor der Tür, das Wetter eher mäh – Zeit für einen UBL-Filmtipp! 🍿 Wir sind besonders stolz auf dieses filmische Portrait, dem es gelungen ist, die #UniversitätsbibliothekLeipzig mit all ihren Facetten und Blickwinkeln einzufangen: https://t.co/7lTfKIFDxg",
      "expandedUrl" : "https://twitter.com/i/web/status/1509893970716995592"
    }
  },
  {
    "like" : {
      "tweetId" : "1505913775563714562",
      "fullText" : "Tolle Aktion von @OpenBiblioJobs zur Unterstützung von ukrainischen Bibliothekar*innen / OpenBiblioJobs supports Ukrainian librarians / OpenBiblioJobs підтримує українських бібліотекарів https://t.co/OKXA637fRt #StandWithUkraine️ /mt https://t.co/vC8FINZhWi",
      "expandedUrl" : "https://twitter.com/i/web/status/1505913775563714562"
    }
  },
  {
    "like" : {
      "tweetId" : "1505831305677836291",
      "fullText" : "Das @BundesarchivD koordiniert die Ukraine-Hilfe im archivfachlichen Bereich. Mehr Informationen siehe Link unten. Weitersagen, damit viele Archive in Deutschland erreicht werden und effektive Hilfe geleistet werden kann! #archive #ukraine #plsshare https://t.co/RFGvP440dU https://t.co/GeT3Owymmx",
      "expandedUrl" : "https://twitter.com/i/web/status/1505831305677836291"
    }
  },
  {
    "like" : {
      "tweetId" : "1497285749733052424",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1497285749733052424"
    }
  },
  {
    "like" : {
      "tweetId" : "1496398525302779905",
      "fullText" : "@OpenBiblioJobs OK, jemand muss es... https://t.co/PHM7ZM4S1h",
      "expandedUrl" : "https://twitter.com/i/web/status/1496398525302779905"
    }
  },
  {
    "like" : {
      "tweetId" : "1496390579755831296",
      "fullText" : "@OpenBiblioJobs Damit hat sich das frühe Freischalten von Stellen schon gelohnt. Das hat mindestens ein Lächeln ins Gesicht gezaubert. - Guten Morgen 😊",
      "expandedUrl" : "https://twitter.com/i/web/status/1496390579755831296"
    }
  },
  {
    "like" : {
      "tweetId" : "1493595288229093383",
      "fullText" : "Data scientists all over the world rely on @internetarchive collections for digital humanities research &amp; data-intensive inquiry. \n\nHear from these scholars &amp; learn about their research projects in our new series, 𝗟𝗶𝗯𝗿𝗮𝗿𝘆 𝗮𝘀 𝗟𝗮𝗯𝗼𝗿𝗮𝘁𝗼𝗿𝘆: https://t.co/CWOgAQGFDN https://t.co/gzKKpSLKTI",
      "expandedUrl" : "https://twitter.com/i/web/status/1493595288229093383"
    }
  },
  {
    "like" : {
      "tweetId" : "1493255705226366981",
      "fullText" : "Vom Azubi zur Führungskraft 🎉🙌 https://t.co/XGa3OShBhc",
      "expandedUrl" : "https://twitter.com/i/web/status/1493255705226366981"
    }
  },
  {
    "like" : {
      "tweetId" : "1493203490545545221",
      "fullText" : "@bibliothekarin @OpenBiblioJobs Vielen Dank fürs Teilen der Ergebnisse! Das bestätigt unser gefühltes Wissen aus den Gesprächen mit den BID-Einrichtungen!",
      "expandedUrl" : "https://twitter.com/i/web/status/1493203490545545221"
    }
  },
  {
    "like" : {
      "tweetId" : "1493210582211825673",
      "fullText" : "Reflektiertes Mail eines Kunden, der das angeblich bereits retournierte Buch doch noch daheim gefunden hat. \nAndere brauchen für diese Erkenntnis jahrelange Psychotherapie. https://t.co/PqJZ8Dqzrm",
      "expandedUrl" : "https://twitter.com/i/web/status/1493210582211825673"
    }
  },
  {
    "like" : {
      "tweetId" : "1493132592937324544",
      "fullText" : "@OpenBiblioJobs https://t.co/GrS0xBYVPi",
      "expandedUrl" : "https://twitter.com/i/web/status/1493132592937324544"
    }
  },
  {
    "like" : {
      "tweetId" : "1493134682170429441",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1493134682170429441"
    }
  },
  {
    "like" : {
      "tweetId" : "1491510948791738370",
      "fullText" : "@OpenBiblioJobs Ein Zimmer... was essen musst du auch noch, Versicherungen usw. Vielleicht gibt's ja bei den Bücherhallen noch eine 22,5h-Stelle.😉",
      "expandedUrl" : "https://twitter.com/i/web/status/1491510948791738370"
    }
  },
  {
    "like" : {
      "tweetId" : "1491373553522188292",
      "fullText" : "@OpenBiblioJobs Will ich doch hoffen, wenn es sich um so ein einmalig episches Ereignis handelt ;-)",
      "expandedUrl" : "https://twitter.com/i/web/status/1491373553522188292"
    }
  },
  {
    "like" : {
      "tweetId" : "1491362959158915079",
      "fullText" : "Vielleicht sollten wir sparsam mit den Stellen sein, die wir freischalten. \"Da wir zum 22.02.2022 die Schnapszahl 22.222 erreichen möchten, kann es zu Verzögerung bei der Freischaltung von Stellen kommen ;-)\" https://t.co/fDObAKcHm8",
      "expandedUrl" : "https://twitter.com/i/web/status/1491362959158915079"
    }
  },
  {
    "like" : {
      "tweetId" : "1488819127284166658",
      "fullText" : "@NiklasBravo Yes, boss. Tuesday, 8 February 2022 at 12:00 GMT+0000. One new reminder, coming right up.",
      "expandedUrl" : "https://twitter.com/i/web/status/1488819127284166658"
    }
  },
  {
    "like" : {
      "tweetId" : "1488819126055448578",
      "fullText" : "@OpenBiblioJobs @RemindMe_OfThis in 6 days",
      "expandedUrl" : "https://twitter.com/i/web/status/1488819126055448578"
    }
  },
  {
    "like" : {
      "tweetId" : "1487134444435738626",
      "fullText" : "@NaturNord @OpenBiblioJobs Du verantwortest Medien für ein bestimmtes Thema = Etat, Medienauswahl, bestellen, makulieren. In Öffentlichen Bibliotheken macht das oft der gehobene Dienst, an wissenschaftlichen Bibliotheken oft der höhere Dienst. Ich mache das in einer ÖB in Berlin. E10 👍, besser als E9b.",
      "expandedUrl" : "https://twitter.com/i/web/status/1487134444435738626"
    }
  },
  {
    "like" : {
      "tweetId" : "1487048116704616451",
      "fullText" : "@OpenBiblioJobs Hab das FAQ angepasst: https://t.co/g1gBUxBU2u",
      "expandedUrl" : "https://twitter.com/i/web/status/1487048116704616451"
    }
  },
  {
    "like" : {
      "tweetId" : "1487040180376805378",
      "fullText" : "@OpenBiblioJobs 270 Euro für die Kaffeekasse?",
      "expandedUrl" : "https://twitter.com/i/web/status/1487040180376805378"
    }
  },
  {
    "like" : {
      "tweetId" : "1474313506363260948",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1474313506363260948"
    }
  },
  {
    "like" : {
      "tweetId" : "1472175249764593670",
      "fullText" : "@OpenBiblioJobs Ich habe zu danken, fürs anpassen und korrigieren 😊 und euren schnellen und unkomplizierten Service 😘",
      "expandedUrl" : "https://twitter.com/i/web/status/1472175249764593670"
    }
  },
  {
    "like" : {
      "tweetId" : "1443880867970027534",
      "fullText" : "Ganz exklusiv schon vorab die Info und demnächst auch unter @OpenBiblioJobs zu finden 😋 ein neues Jobangebot der #StadtbibliothekBonn 👍 schaut doch mal, ob das was für euch ist 😊 \n📋 Stellenausschreibung Lektorat und bibliothekspädagogische Betreuung der Jugendbibliothek",
      "expandedUrl" : "https://twitter.com/i/web/status/1443880867970027534"
    }
  },
  {
    "like" : {
      "tweetId" : "1433502684489916418",
      "expandedUrl" : "https://twitter.com/i/web/status/1433502684489916418"
    }
  },
  {
    "like" : {
      "tweetId" : "1425754433477128193",
      "fullText" : "\"Warum muss man in der Bücherei eigentlich leise sein?\"\nDamit man hört, wenn das Handy läutet.",
      "expandedUrl" : "https://twitter.com/i/web/status/1425754433477128193"
    }
  },
  {
    "like" : {
      "tweetId" : "1418123681105076226",
      "fullText" : "@c_riesen tue ich gerne, aber bin bei \"Master oder vergleichbar\" in Dtld noch NIE bis zum Interview vorgedrungen. Hab mich aus dem UK bei ca. 15 Stellen beworben. Es geht auch nicht nur um diese Stelle, ich würde gerne deutsche Einrichtungen für diese Thema etwas mehr sensibilisieren. :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/1418123681105076226"
    }
  },
  {
    "like" : {
      "tweetId" : "1414605362410496006",
      "fullText" : "Fachangestellte/r für Medien und Informationsdienste, E 6 TV-L, befristet für 2 Jahre, Vollzeit (Teilzeit möglich), Ref. #09-21002 https://t.co/lQ9Gx4P1rq Senckenberg Deutsches Entomologisches Institut (SDEI), Spezialbibliothek, Standort Müncheberg",
      "expandedUrl" : "https://twitter.com/i/web/status/1414605362410496006"
    }
  },
  {
    "like" : {
      "tweetId" : "1410257770323103747",
      "fullText" : "Spannend wie es jetzt mit den Begrüßungsritualen weitergeht. V.a. wenn ein Part zu Bussi-Bussi und der andere zu Fistbump ansetzt, könnte das eine schmerzhafte Erfahrung werden.",
      "expandedUrl" : "https://twitter.com/i/web/status/1410257770323103747"
    }
  },
  {
    "like" : {
      "tweetId" : "1410119373700931584",
      "fullText" : "Auf gehts in den letzten Tag #HomeOffice. Ab morgen wieder täglich vor Ort in der Bibliothek. Dann enden vielleicht die Fragen \"Arbeitest du wieder oder machst du noch Home Office?\".",
      "expandedUrl" : "https://twitter.com/i/web/status/1410119373700931584"
    }
  },
  {
    "like" : {
      "tweetId" : "1405852233800077315",
      "fullText" : "Wir sprechen ständig über Open Access und Open Science. Wir fordern einen freien Zugang zu Inhalten. Warum gibt es kein frei zugängliches Streaming vom #bibtag21? Gibt es schon ein Konzept für #OpenConference?",
      "expandedUrl" : "https://twitter.com/i/web/status/1405852233800077315"
    }
  },
  {
    "like" : {
      "tweetId" : "1405977831579033603",
      "fullText" : "@HWiesenmueller @jmiba Es geht mir auch etwas ums Prinzip. Wie viele Vorträge gab es zu OpenAccess/OpenScience? Wieviele Menschen mehr hätten Vorträge gesehen, wenn sie frei zugänglich wären? Wie ist unser Anspruch an uns selbst?",
      "expandedUrl" : "https://twitter.com/i/web/status/1405977831579033603"
    }
  },
  {
    "like" : {
      "tweetId" : "1405821022666952706",
      "fullText" : "#IchbinHanna war einmal. \n#IchwarHanna ist meine neue Realität. Seit 3 Monaten bin ich im Wissenschaftsmanagement der @TUDarmstadt tätig. \nWarum mein Ausstieg eine Erfolgsgeschichte ist, erzähle (nach reiflicher Überlegung) jetzt und die nächsten Tage. Los geht's",
      "expandedUrl" : "https://twitter.com/i/web/status/1405821022666952706"
    }
  },
  {
    "like" : {
      "tweetId" : "1403655613427683332",
      "expandedUrl" : "https://twitter.com/i/web/status/1403655613427683332"
    }
  },
  {
    "like" : {
      "tweetId" : "1400220180710674434",
      "fullText" : "@OpenBiblioJobs Wusste gar nicht dass fami n Studiengang ist https://t.co/QCZax9D3gm",
      "expandedUrl" : "https://twitter.com/i/web/status/1400220180710674434"
    }
  },
  {
    "like" : {
      "tweetId" : "1397918126268837905",
      "fullText" : "Ich will auch 😢 https://t.co/wgZSn6OLjQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1397918126268837905"
    }
  },
  {
    "like" : {
      "tweetId" : "1388041047817793536",
      "fullText" : "Der Pop-Titan @dirtydieter in jungen Jahren: Ein Kinderzimmer, eine Gitarre, jede Menge dumme Sprüche und die #Nachhilfe, die alles verändert hat. Was wäre wohl aus @moderntalkingtr ohne Englisch-Nachhilfe von #GoStudent geworden? @BILD_Promis https://t.co/bD0Fj2h7jU",
      "expandedUrl" : "https://twitter.com/i/web/status/1388041047817793536"
    }
  },
  {
    "like" : {
      "tweetId" : "1395409465302716423",
      "fullText" : "Heute nach dem #Homeoffice passende #Blumen 🌼🌺🌸 gepflanzt und ein #Insektenhotel gekauft. Mal sehen, ob sich die ein oder andere Wildbiene nach #Steglitz verirrt 🐝. Wir werden berichten 😉!\n#Weltbienentag https://t.co/sbEiJp2Dkr",
      "expandedUrl" : "https://twitter.com/i/web/status/1395409465302716423"
    }
  },
  {
    "like" : {
      "tweetId" : "1393208060726874113",
      "fullText" : "Ein kleiner Fehler hatte sich eingeschlichen. Wir suchen für die Zentralbibliothek! \n(bp)",
      "expandedUrl" : "https://twitter.com/i/web/status/1393208060726874113"
    }
  },
  {
    "like" : {
      "tweetId" : "648913596156637184",
      "fullText" : "@OpenBiblioJobs das war keine Kritik an Euch!!! Ich bin superhappy das es @OpenBiblioJobs gibt!!! 👍",
      "expandedUrl" : "https://twitter.com/i/web/status/648913596156637184"
    }
  },
  {
    "like" : {
      "tweetId" : "648912570951331840",
      "fullText" : "@OpenBiblioJobs Genau das meine ich ja! 😠",
      "expandedUrl" : "https://twitter.com/i/web/status/648912570951331840"
    }
  },
  {
    "like" : {
      "tweetId" : "648912325886537728",
      "fullText" : "@OpenBiblioJobs Leben ja,aber\"Familie ernähren?\"Das sind\"typische Frauenjobs\"geworden&amp; damit sinkt das Lohnniveau und das nervt!",
      "expandedUrl" : "https://twitter.com/i/web/status/648912325886537728"
    }
  },
  {
    "like" : {
      "tweetId" : "648910957440278528",
      "fullText" : "@OpenBiblioJobs  findet außer mir niemand Bibliotheksleitung mit TVL 9 vergüten eine Frechheit?!?Wer kann den davon eine \"Familie ernähren\"?",
      "expandedUrl" : "https://twitter.com/i/web/status/648910957440278528"
    }
  },
  {
    "like" : {
      "tweetId" : "644499530306691072",
      "fullText" : "@johrols @Lambo @OpenBiblioJobs Das ließe sich u.A. auf die Bibliotheksinformatik-Studiengänge in Leipzig und Wildau übertragen.",
      "expandedUrl" : "https://twitter.com/i/web/status/644499530306691072"
    }
  },
  {
    "like" : {
      "tweetId" : "644458470327087104",
      "fullText" : "Konstanze Söllner &amp; Publikum: @OpenBiblioJobs-Daten könnten und sollten regelmäßig untersucht werden, erlauben wichtige Einsichten. #oebt15",
      "expandedUrl" : "https://twitter.com/i/web/status/644458470327087104"
    }
  },
  {
    "like" : {
      "tweetId" : "644455581412147200",
      "fullText" : "Interessante Ergebnisse der Analyse des @OpenBiblioJobs Korpus auf Inhalte wissensch. BibliothekarInnen-Stellen. Leseempfehlung. #oebt15",
      "expandedUrl" : "https://twitter.com/i/web/status/644455581412147200"
    }
  },
  {
    "like" : {
      "tweetId" : "644454812986294272",
      "fullText" : "Konstanze Söllner bedankt sich bei @OpenBiblioJobs für Stellenausschreibungen-Sammlung die sie mit Textmining untersuchen konnte. #oebt15",
      "expandedUrl" : "https://twitter.com/i/web/status/644454812986294272"
    }
  },
  {
    "like" : {
      "tweetId" : "642353898221608960",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/642353898221608960"
    }
  },
  {
    "like" : {
      "tweetId" : "641297200555950080",
      "fullText" : "School of #LIS at  Kent State University (@KentStateSLIS) is looking for a new director: http://t.co/wchGduUjDP /cc @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/641297200555950080"
    }
  },
  {
    "like" : {
      "tweetId" : "641254124160438273",
      "fullText" : "@OpenBiblioJobs VOLONTÄR/-IN IM BEREICH BIBLIOTHEKEN AM GOETHE-INSTITUT IN DER ZENTRALE MÜNCHEN - https://t.co/azmEPx3G18",
      "expandedUrl" : "https://twitter.com/i/web/status/641254124160438273"
    }
  },
  {
    "like" : {
      "tweetId" : "639138741119025152",
      "fullText" : "@OpenBiblioJobs @OPL_Tante Perfekt, vielen Dank! ;-)",
      "expandedUrl" : "https://twitter.com/i/web/status/639138741119025152"
    }
  },
  {
    "like" : {
      "tweetId" : "639076775709003777",
      "fullText" : "@Wolfsoulmate schon bei @OpenBiblioJobs gemeldet?",
      "expandedUrl" : "https://twitter.com/i/web/status/639076775709003777"
    }
  },
  {
    "like" : {
      "tweetId" : "637720599838724096",
      "fullText" : "@OpenBiblioJobs Danke! ☺",
      "expandedUrl" : "https://twitter.com/i/web/status/637720599838724096"
    }
  },
  {
    "like" : {
      "tweetId" : "637572588319981568",
      "fullText" : "@herr_tu Das stimmt leider. Ist mir auch schon aufgefallen. Vielen Dank! //@OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/637572588319981568"
    }
  },
  {
    "like" : {
      "tweetId" : "637571159903588352",
      "fullText" : "@herr_tu Wegen mir nicht! In der Beschr. Steht Teilzeit &amp; Gehalt. Für 50% E9 ist das Gehalt normal :( //@OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/637571159903588352"
    }
  },
  {
    "like" : {
      "tweetId" : "637566537478610944",
      "fullText" : "@OpenBiblioJobs so wie ich das sehe ist das eine Teilzeitstelle. Da wäre die genaue Stundenanzahl interessant.",
      "expandedUrl" : "https://twitter.com/i/web/status/637566537478610944"
    }
  },
  {
    "like" : {
      "tweetId" : "636134780212543488",
      "fullText" : "ZBMed in Köln sucht Bibliothekarinnen #job #zbmed #koeln #bibliothek https://t.co/bNLMJ1Els3",
      "expandedUrl" : "https://twitter.com/i/web/status/636134780212543488"
    }
  },
  {
    "like" : {
      "tweetId" : "633666466525638657",
      "fullText" : "@OpenBiblioJobs @bib_info Der Gestaltungsspielraum ist ja oft eher mäßig",
      "expandedUrl" : "https://twitter.com/i/web/status/633666466525638657"
    }
  },
  {
    "like" : {
      "tweetId" : "633685925751562240",
      "fullText" : "@OpenBiblioJobs  ich wäre hocherfreut wenn Ihr die Ortsangabe in den Tweets unterbringen könntet.",
      "expandedUrl" : "https://twitter.com/i/web/status/633685925751562240"
    }
  },
  {
    "like" : {
      "tweetId" : "632174248216256512",
      "fullText" : "Wir suchen neue Kollegen ;)! #hbz #bewerbung https://t.co/QJGksqagzK",
      "expandedUrl" : "https://twitter.com/i/web/status/632174248216256512"
    }
  },
  {
    "like" : {
      "tweetId" : "632174311877550080",
      "fullText" : "gleich zweimal *g* #hbz #bewerbung https://t.co/wmi3MoSSEx",
      "expandedUrl" : "https://twitter.com/i/web/status/632174311877550080"
    }
  },
  {
    "like" : {
      "tweetId" : "629237281241571328",
      "fullText" : "@OpenBiblioJobs dann bestelle doch bitte auch von mir ein großes Dankeschön dafür ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/629237281241571328"
    }
  },
  {
    "like" : {
      "tweetId" : "628995715902083072",
      "fullText" : "Wozu noch studieren.  https://t.co/yUwcNB32Vr",
      "expandedUrl" : "https://twitter.com/i/web/status/628995715902083072"
    }
  },
  {
    "like" : {
      "tweetId" : "625896528880779264",
      "fullText" : "@OpenBiblioJobs Vielen Dank! Das wünschen wir auch! :)",
      "expandedUrl" : "https://twitter.com/i/web/status/625896528880779264"
    }
  },
  {
    "like" : {
      "tweetId" : "624228789812391937",
      "fullText" : "Herzlichen! https://t.co/P6gVDs7AZe",
      "expandedUrl" : "https://twitter.com/i/web/status/624228789812391937"
    }
  },
  {
    "like" : {
      "tweetId" : "623192259757010944",
      "fullText" : "@OpenBiblioJobs Herzlichen Glückwunsch und vielen Dank für die Arbeit!",
      "expandedUrl" : "https://twitter.com/i/web/status/623192259757010944"
    }
  },
  {
    "like" : {
      "tweetId" : "621229622928244736",
      "fullText" : "@fahrenkrog Schöne Grüße, sie sollen sich mal einen Ruck geben und freie Stellen bei uns melden. (Phu)",
      "expandedUrl" : "https://twitter.com/i/web/status/621229622928244736"
    }
  },
  {
    "like" : {
      "tweetId" : "621228742707429376",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/621228742707429376"
    }
  },
  {
    "like" : {
      "tweetId" : "619823310067601408",
      "fullText" : "@OPL_Tante @OpenBiblioJobs klar",
      "expandedUrl" : "https://twitter.com/i/web/status/619823310067601408"
    }
  },
  {
    "like" : {
      "tweetId" : "619812983313670144",
      "fullText" : "@UltraBiblioteka schon an @OpenBiblioJobs gemeldet?",
      "expandedUrl" : "https://twitter.com/i/web/status/619812983313670144"
    }
  },
  {
    "like" : {
      "tweetId" : "616575961463681024",
      "fullText" : "Some insightful criticism: “The Semantic Web – A Vision Come True, or Giving Up the Great Plan?” http://t.co/P2iMzOXjot /via @Miel_vds",
      "expandedUrl" : "https://twitter.com/i/web/status/616575961463681024"
    }
  },
  {
    "like" : {
      "tweetId" : "612188805550997504",
      "fullText" : "Here's a job for an archivist in the Stasi archives: https://t.co/FUJfvSwllx",
      "expandedUrl" : "https://twitter.com/i/web/status/612188805550997504"
    }
  },
  {
    "like" : {
      "tweetId" : "610530429213523970",
      "fullText" : "Cool wäre jetzt noch ein Textmining, das @OpenBiblioJobs-Inhalte aus @InetBibList rausfiltert, um das Rauschen zu verringern...",
      "expandedUrl" : "https://twitter.com/i/web/status/610530429213523970"
    }
  },
  {
    "like" : {
      "tweetId" : "603640451804098561",
      "fullText" : "@UltraBiblioteka @bibliothekarin @herr_tu Jetzt ist es auch dort. War jedenfalls kein Vorsatz, das dort _nicht_ aufzuführen.@OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/603640451804098561"
    }
  },
  {
    "like" : {
      "tweetId" : "601469468905250816",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/601469468905250816"
    }
  },
  {
    "like" : {
      "tweetId" : "601469181238845440",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/601469181238845440"
    }
  },
  {
    "like" : {
      "tweetId" : "598609623168491520",
      "fullText" : "0:00 Uhr. Wir sind seit 8 stunden unterwegs. Und endlich an Dresden vorbei #heimreise",
      "expandedUrl" : "https://twitter.com/i/web/status/598609623168491520"
    }
  },
  {
    "like" : {
      "tweetId" : "598583771923877888",
      "fullText" : "Empfehle für morgen #ausschlafen.",
      "expandedUrl" : "https://twitter.com/i/web/status/598583771923877888"
    }
  },
  {
    "like" : {
      "tweetId" : "598244259259613184",
      "fullText" : "@OpenBiblioJobs Sehr seltsam. \"Eingestellt von unbekannt.\" Keine Ahnung, wie das passieren konnte.",
      "expandedUrl" : "https://twitter.com/i/web/status/598244259259613184"
    }
  },
  {
    "like" : {
      "tweetId" : "598098392548560897",
      "fullText" : "Stellenangebot @StabiHH: RT @OpenBiblioJobs EDV-gestützte Zugangsbearb. fortlauf. Sammelwerke, E9, befristet 1 Jahr: http://t.co/Rtm8GIhE8R",
      "expandedUrl" : "https://twitter.com/i/web/status/598098392548560897"
    }
  },
  {
    "like" : {
      "tweetId" : "593141320568414208",
      "fullText" : "@OpenBiblioJobs Danke, falls ich mir paar Zutaten wünschen darf: Medienbearbeitung, Primo &amp; Social Media.",
      "expandedUrl" : "https://twitter.com/i/web/status/593141320568414208"
    }
  },
  {
    "like" : {
      "tweetId" : "593124335390457857",
      "fullText" : "@m_minze Momentchen, wir müssen die noch backen.",
      "expandedUrl" : "https://twitter.com/i/web/status/593124335390457857"
    }
  },
  {
    "like" : {
      "tweetId" : "593103141459140609",
      "fullText" : "Das waren eben grad 4 unbefristete Stellen der Stadtbibliothek Bremen. Husch, husch, bewerbt Euch! Wir drücken die Daumen.",
      "expandedUrl" : "https://twitter.com/i/web/status/593103141459140609"
    }
  },
  {
    "like" : {
      "tweetId" : "593111091468759040",
      "fullText" : "@OpenBiblioJobs wer will schon nach Bremen… Bitte nun 4 Stellen für Berlin. ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/593111091468759040"
    }
  },
  {
    "like" : {
      "tweetId" : "591497770780889089",
      "fullText" : "Social Media Jobs is out! http://t.co/uWZtvu87DV Stories via @itparkjobs @DorotaHaller @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/591497770780889089"
    }
  },
  {
    "like" : {
      "tweetId" : "590021553875726336",
      "fullText" : "@OpenBiblioJobs @BISmagazin Moin. Ja, das ist geplant. Eine Übersicht mit den Links gibt es in Kürze im #Slublog. /jb",
      "expandedUrl" : "https://twitter.com/i/web/status/590021553875726336"
    }
  },
  {
    "like" : {
      "tweetId" : "589467360039460866",
      "fullText" : "@OpenBiblioJobs geht",
      "expandedUrl" : "https://twitter.com/i/web/status/589467360039460866"
    }
  },
  {
    "like" : {
      "tweetId" : "589500245085659136",
      "fullText" : "@OpenBiblioJobs done. Auf G+ kommt kein Bild (gut), auf FB das TIB-Bild, ansonsten alles normal",
      "expandedUrl" : "https://twitter.com/i/web/status/589500245085659136"
    }
  },
  {
    "like" : {
      "tweetId" : "588442928286040064",
      "fullText" : "Hm, ich war das wohl mit dem 5.555 Job auf @OpenBiblioJobs  http://t.co/AALm85V0no #obj2",
      "expandedUrl" : "https://twitter.com/i/web/status/588442928286040064"
    }
  },
  {
    "like" : {
      "tweetId" : "588680308129734656",
      "fullText" : "Beeindruckend: https://t.co/1gbZbFcGm7",
      "expandedUrl" : "https://twitter.com/i/web/status/588680308129734656"
    }
  },
  {
    "like" : {
      "tweetId" : "588591148429496323",
      "fullText" : "Danke! https://t.co/zxsg3ThBl8",
      "expandedUrl" : "https://twitter.com/i/web/status/588591148429496323"
    }
  },
  {
    "like" : {
      "tweetId" : "583591663349661696",
      "fullText" : "Konkurrenzlos. MT @bibliothekarin: @OpenBiblioJobs – georeferenziert und tabellarisch http://t.co/HtFeS4HiuA #obj2 /cc @bib_info",
      "expandedUrl" : "https://twitter.com/i/web/status/583591663349661696"
    }
  },
  {
    "like" : {
      "tweetId" : "583499966141833216",
      "fullText" : "Müssen jetzt alle ganz tapfer sein. RT @jafurtado Internet Access Makes You Think You’re Smarter Than You Really Are https://t.co/ShLskmgPhn",
      "expandedUrl" : "https://twitter.com/i/web/status/583499966141833216"
    }
  },
  {
    "like" : {
      "tweetId" : "583191326885281792",
      "fullText" : "Wie prüfe ich Fakten im Internet? Ein Beispiel http://t.co/3auZYw5klT via blog4search",
      "expandedUrl" : "https://twitter.com/i/web/status/583191326885281792"
    }
  },
  {
    "like" : {
      "tweetId" : "583207908550283264",
      "fullText" : "Dramatische Entwicklung rund um die #KaroBoys der Mediothek #Krefeld: https://t.co/es3Hg9mz2L #bibliothek",
      "expandedUrl" : "https://twitter.com/i/web/status/583207908550283264"
    }
  },
  {
    "like" : {
      "tweetId" : "583208121847304192",
      "fullText" : "Common Craft: Libraries in the Internet Age http://t.co/m7fL7LgfNR",
      "expandedUrl" : "https://twitter.com/i/web/status/583208121847304192"
    }
  },
  {
    "like" : {
      "tweetId" : "583210225014083584",
      "fullText" : "Blogbeitrag aus dem Deutschen Musikarchiv Today is your Tomorrow (and vice versa)  http://t.co/BwlMzQvLiM http://t.co/xve0HPoisr @eu_sounds",
      "expandedUrl" : "https://twitter.com/i/web/status/583210225014083584"
    }
  },
  {
    "like" : {
      "tweetId" : "582132080475148288",
      "fullText" : "IG WBS – Portraits von selbständigen KollegInnen https://t.co/S6CZXrccVg",
      "expandedUrl" : "https://twitter.com/i/web/status/582132080475148288"
    }
  },
  {
    "like" : {
      "tweetId" : "580836210064678913",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/580836210064678913"
    }
  },
  {
    "like" : {
      "tweetId" : "580609765304303616",
      "fullText" : "@OpenBiblioJobs @hauschke Selten, meist reicht die  Liste.",
      "expandedUrl" : "https://twitter.com/i/web/status/580609765304303616"
    }
  },
  {
    "like" : {
      "tweetId" : "580480162124431360",
      "fullText" : "@textundblog @OpenBiblioJobs Finde ich auch sinnvoller",
      "expandedUrl" : "https://twitter.com/i/web/status/580480162124431360"
    }
  },
  {
    "like" : {
      "tweetId" : "580479438208561152",
      "fullText" : "@OpenBiblioJobs Filter nach Stellentyp nutze ich (ohne RSS), will zB manchmal nur Azubi-Stellen sehen. #dankefüreuerengagement",
      "expandedUrl" : "https://twitter.com/i/web/status/580479438208561152"
    }
  },
  {
    "like" : {
      "tweetId" : "580479299603591169",
      "fullText" : "@OpenBiblioJobs Direkt zum Stellenangebot finde ich zielführender.",
      "expandedUrl" : "https://twitter.com/i/web/status/580479299603591169"
    }
  },
  {
    "like" : {
      "tweetId" : "580478642037325824",
      "fullText" : "@OpenBiblioJobs @FITC2014 @bibliothekarin Ja,Ortsangabe sehr gewünscht!Letztes Jahr hieß es, das TwitterPlugin kann das leider nicht. #danke",
      "expandedUrl" : "https://twitter.com/i/web/status/580478642037325824"
    }
  },
  {
    "like" : {
      "tweetId" : "580475055664197633",
      "fullText" : "@OpenBiblioJobs hmmm, hat beides Vor-&amp;Nachteile. Tendiere eher zu 1. da hier die Informationen gleich gegliedert sind.",
      "expandedUrl" : "https://twitter.com/i/web/status/580475055664197633"
    }
  },
  {
    "like" : {
      "tweetId" : "580467155872976896",
      "fullText" : "OpenBiblioJobs – Feedback erwünscht » Bibliothekarisch.de http://t.co/bpheMKhQUq (DB) #obj2",
      "expandedUrl" : "https://twitter.com/i/web/status/580467155872976896"
    }
  },
  {
    "like" : {
      "tweetId" : "580467055402573826",
      "fullText" : "@OpenBiblioJobs danke für die Info!",
      "expandedUrl" : "https://twitter.com/i/web/status/580467055402573826"
    }
  },
  {
    "like" : {
      "tweetId" : "580466745405792256",
      "fullText" : "@bookotecarian eine Kartenansicht ist in Arbeit (jetzt wirklich ...) und ist jetzt Prio 1!",
      "expandedUrl" : "https://twitter.com/i/web/status/580466745405792256"
    }
  },
  {
    "like" : {
      "tweetId" : "580464243713142784",
      "fullText" : "@OpenBiblioJobs icke hab's genutzt während meiner Arbeitssuche, um jeden Tag auf dem laufenden zu bleiben - zähle aber wohl nicht ;-)",
      "expandedUrl" : "https://twitter.com/i/web/status/580464243713142784"
    }
  },
  {
    "like" : {
      "tweetId" : "577827045310365696",
      "fullText" : "Ach, schöne Jobangebote bei @OpenBiblioJobs gesehen. Leider nicht in meiner Stadt. Aber ich bin ja erst am Anfang der Suche. #immerPositiv",
      "expandedUrl" : "https://twitter.com/i/web/status/577827045310365696"
    }
  },
  {
    "like" : {
      "tweetId" : "575280170929627136",
      "fullText" : "@gehtsie @OpenBiblioJobs Ja, wir melden in der Regel freie Jobs, bei denen ein bibliothekarischer Hintergrund erforderlich ist.",
      "expandedUrl" : "https://twitter.com/i/web/status/575280170929627136"
    }
  },
  {
    "like" : {
      "tweetId" : "574893132787093504",
      "fullText" : ".@OpenBiblioJobs @hauschke Dialog erinnert mich daran, dass ich längst aus @bib_info ausgetreten sein wollte. (Mit öffentlicher Begründung.)",
      "expandedUrl" : "https://twitter.com/i/web/status/574893132787093504"
    }
  },
  {
    "like" : {
      "tweetId" : "574873760551010304",
      "fullText" : "@Lambo @hauschke @bib_info \"Konkurrenz\" ist Quatsch mit Käse, wir betreiben so eine Art \"Mängelkompensation\", bis der Mangel behoben ist.",
      "expandedUrl" : "https://twitter.com/i/web/status/574873760551010304"
    }
  },
  {
    "like" : {
      "tweetId" : "574311632966447105",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/574311632966447105"
    }
  },
  {
    "like" : {
      "tweetId" : "573953930004144128",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/573953930004144128"
    }
  },
  {
    "like" : {
      "tweetId" : "574203687813451777",
      "fullText" : "\"@hauschke: Das Team hinter @OpenBiblioJobs verdient sich gar nicht dumm und dusselig damit? Shocking! http://t.co/UaHwsIp4iF #obj2\"",
      "expandedUrl" : "https://twitter.com/i/web/status/574203687813451777"
    }
  },
  {
    "like" : {
      "tweetId" : "573568372505448448",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/573568372505448448"
    }
  },
  {
    "like" : {
      "tweetId" : "568773508299431936",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/568773508299431936"
    }
  },
  {
    "like" : {
      "tweetId" : "543874158502096896",
      "fullText" : "Bald möglich: Libreas Beiträge online annotieren mit http://t.co/4TMFfFjGuL #reproducibleLIS #newLIS http://t.co/ZHG52YQPgL",
      "expandedUrl" : "https://twitter.com/i/web/status/543874158502096896"
    }
  },
  {
    "like" : {
      "tweetId" : "543505607001923586",
      "fullText" : "Endlich mal wieder #ff @BibTag2015 @exilbohne @Cherrycat5782 @iamfranziw @OpenBiblioJobs @larsbobach @todoist @evernotetipps @evernote",
      "expandedUrl" : "https://twitter.com/i/web/status/543505607001923586"
    }
  },
  {
    "like" : {
      "tweetId" : "543062888924319744",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/543062888924319744"
    }
  },
  {
    "like" : {
      "tweetId" : "541937193439485952",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/541937193439485952"
    }
  },
  {
    "like" : {
      "tweetId" : "541937952205832193",
      "fullText" : "Ich lebe nur noch auf 19 Uhr hin. RT @fahrenkrog: Nicht vergessen: heute ist Stammtisch … und ich freue mich schon auf Euch! 🙋\n #bibstahh",
      "expandedUrl" : "https://twitter.com/i/web/status/541937952205832193"
    }
  },
  {
    "like" : {
      "tweetId" : "541937998137671681",
      "fullText" : "WUHU! RT @fahrenkrog Nicht vergessen: heute ist Stammtisch. Tisch ist reserviert und ich freue mich schon auf Euch! 🙋 #bibstahh",
      "expandedUrl" : "https://twitter.com/i/web/status/541937998137671681"
    }
  },
  {
    "like" : {
      "tweetId" : "539514098707619841",
      "fullText" : "@OpenBiblioJobs RT @SKB_Soemmerda: Achtung!\nWir suchen Verstärkung f. unser Bibo-Team, e. Azubi/ne z. 1.9.15!\n\nDie... http://t.co/peOdcrL3sP",
      "expandedUrl" : "https://twitter.com/i/web/status/539514098707619841"
    }
  },
  {
    "like" : {
      "tweetId" : "521632509470474240",
      "fullText" : "@OpenBiblioJobs Unter \"Archivar\" stelle ich mir etwas anderes vor. Ich denke, die Archivare auch ... ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/521632509470474240"
    }
  },
  {
    "like" : {
      "tweetId" : "519810426176290816",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/519810426176290816"
    }
  },
  {
    "like" : {
      "tweetId" : "519808756910407680",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/519808756910407680"
    }
  },
  {
    "like" : {
      "tweetId" : "519806988721848320",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/519806988721848320"
    }
  },
  {
    "like" : {
      "tweetId" : "516898978877952000",
      "fullText" : "JOB: Diplom-Bibliothekar/-in, München, Zentralinstitut für Kunstgeschichte - @OpenBiblioJobs - http://t.co/IgtWHYaK9T",
      "expandedUrl" : "https://twitter.com/i/web/status/516898978877952000"
    }
  },
  {
    "like" : {
      "tweetId" : "516486630551871488",
      "fullText" : "@OpenBiblioJobs Es wird immer bunter. Was ist \"ca. eine halbe Stelle\"? Wird die Gehaltsabrechnung dann ähnlich exakt? Ca.Titelaufnahmen??",
      "expandedUrl" : "https://twitter.com/i/web/status/516486630551871488"
    }
  },
  {
    "like" : {
      "tweetId" : "515230928558624769",
      "fullText" : "Ich habe es tatsächlich geschafft und bin pünktlich und ohne Probleme in Chur angekommen @InfoWissChur freue mich auf morgen!",
      "expandedUrl" : "https://twitter.com/i/web/status/515230928558624769"
    }
  },
  {
    "like" : {
      "tweetId" : "514750831623929856",
      "fullText" : "Stellenausschreibung: Leitung Diözesanarchiv Graz/Seckau | BIÖG http://t.co/Cybep9NQ8N cc @OpenBiblioJobs @archive20",
      "expandedUrl" : "https://twitter.com/i/web/status/514750831623929856"
    }
  },
  {
    "like" : {
      "tweetId" : "512699561513451520",
      "fullText" : "@Rauhaardackel Guck mal, wie viele Stellen in unserer Berufsgruppe gibt! https://t.co/cx6BWIsOoG",
      "expandedUrl" : "https://twitter.com/i/web/status/512699561513451520"
    }
  },
  {
    "like" : {
      "tweetId" : "509704509023850496",
      "fullText" : "@OpenBiblioJobs @infoclio Job: Wissenschaftliche/n Bibliothekar/in http://t.co/YcuDAgVtRZ",
      "expandedUrl" : "https://twitter.com/i/web/status/509704509023850496"
    }
  },
  {
    "like" : {
      "tweetId" : "509348970985185281",
      "fullText" : "@OpenBiblioJobs Wiss. Volontär/-in digitales Stadtgedächtnis, Stadtarchiv Leipzig\nhttp://t.co/ThnAKjjKq4",
      "expandedUrl" : "https://twitter.com/i/web/status/509348970985185281"
    }
  },
  {
    "like" : {
      "tweetId" : "502374436029603840",
      "fullText" : "@OpenBiblioJobs Und leider kein Einzelfall mehr. Ungelerntengehalt bei qualifizierten Anforderungen.",
      "expandedUrl" : "https://twitter.com/i/web/status/502374436029603840"
    }
  },
  {
    "like" : {
      "tweetId" : "501330300648296449",
      "fullText" : "@OpenBiblioJobs Gerne, so er Parameter bietet, die Enthusiasmus würdigen und verdienen ;-)",
      "expandedUrl" : "https://twitter.com/i/web/status/501330300648296449"
    }
  },
  {
    "like" : {
      "tweetId" : "493676405486784513",
      "fullText" : "Wissenschaftsmanager/in (TV-L 14) am Standort Köln gesucht #jobs http://t.co/RkdnB7vKmG @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/493676405486784513"
    }
  },
  {
    "like" : {
      "tweetId" : "490131885444833280",
      "fullText" : "Die ZB MED sucht eine/n Systembetreuerin/Systembetreuer f Linux-Server- und Endbenutzersysteme http://t.co/UhpeNY8uFl #jobs @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/490131885444833280"
    }
  },
  {
    "like" : {
      "tweetId" : "490148267360288768",
      "fullText" : "@OpenBiblioJobs \"@DNB_Aktuelles: Stellenangebot Ffm: Weiterentwicklung Datenformate  #LinkedData #SemanticWeb - http://t.co/Up8Vj3aHiJ\"",
      "expandedUrl" : "https://twitter.com/i/web/status/490148267360288768"
    }
  },
  {
    "like" : {
      "tweetId" : "476784671419039744",
      "fullText" : "@OpenBiblioJobs ok, dachte ich mir schon fast. vielleicht lernt das plugin ja irgendwann dazu ;-) trotzdem danke!",
      "expandedUrl" : "https://twitter.com/i/web/status/476784671419039744"
    }
  },
  {
    "like" : {
      "tweetId" : "471702959798370304",
      "fullText" : "lol: Die @StabiHH fragt in der Nutzerumfrage: „Wie oft besuchen Sie uns?“ Eine Antwort-Option: „Ich habe aktuell Hausverbot“ m) #gründlich",
      "expandedUrl" : "https://twitter.com/i/web/status/471702959798370304"
    }
  },
  {
    "like" : {
      "tweetId" : "462329747033579521",
      "fullText" : "Erster Arbeitstag gut überstanden.  Nach Bremen darf ich auch :)",
      "expandedUrl" : "https://twitter.com/i/web/status/462329747033579521"
    }
  },
  {
    "like" : {
      "tweetId" : "448465711447674880",
      "fullText" : "@OpenBiblioJobs - ein gelungenes Angebot! Auch für Arbeitgeber mit übersichtlich gestalteter Eingabemaske - eintragen und gespannt sein!",
      "expandedUrl" : "https://twitter.com/i/web/status/448465711447674880"
    }
  },
  {
    "like" : {
      "tweetId" : "437941657938710528",
      "fullText" : "Information in action is out! http://t.co/zh4UmI7wwK Stories via @bibliothekarin @OpenBiblioJobs @hjbove",
      "expandedUrl" : "https://twitter.com/i/web/status/437941657938710528"
    }
  },
  {
    "like" : {
      "tweetId" : "425523533658087425",
      "fullText" : "@OpenBiblioJobs die beiden aktuellen Links funktionieren nicht. (07:58)",
      "expandedUrl" : "https://twitter.com/i/web/status/425523533658087425"
    }
  },
  {
    "like" : {
      "tweetId" : "425657298476744704",
      "fullText" : "Hallo @OpenBiblioJobs, habt ihr Statistiken darüber, wie viele Stellen bei euch so pro Monat veröffentlicht werden?",
      "expandedUrl" : "https://twitter.com/i/web/status/425657298476744704"
    }
  },
  {
    "like" : {
      "tweetId" : "420899673100914688",
      "fullText" : "Auch im neuen Jahr gibt es wieder zahlreiche Stellen im Bibliotheksbereich @OpenBiblioJobs - http://t.co/vXPhYjHknc #jobs #bibliothek",
      "expandedUrl" : "https://twitter.com/i/web/status/420899673100914688"
    }
  },
  {
    "like" : {
      "tweetId" : "412835941749760000",
      "fullText" : "Schon erledigt. :-) @OpenBiblioJobs RT: @Lesewolke Bitte mal den Link zu uns aktualisieren :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/412835941749760000"
    }
  },
  {
    "like" : {
      "tweetId" : "408575812506779648",
      "fullText" : "Die Pläne von @ViFaPol_de gefallen mir; v.a. Punkt 8, wiki.ViFaPol: \"an das Erfolgsmodell des cibera Forscher-Wikis anzuschließen\". ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/408575812506779648"
    }
  },
  {
    "like" : {
      "tweetId" : "405249542226202625",
      "fullText" : "#Stellenangebote #Jobs in #Bibliothek &amp; #Archiv http://t.co/CzEGqr7maC via @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/405249542226202625"
    }
  },
  {
    "like" : {
      "tweetId" : "405098168355794944",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/405098168355794944"
    }
  },
  {
    "like" : {
      "tweetId" : "405098369623678976",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/405098369623678976"
    }
  },
  {
    "like" : {
      "tweetId" : "397622769954725888",
      "fullText" : "Bibliotheksamtfrau / -mann A 11– unbefristet, Vollzeit – Gruppenleitung Ausleihzentrum &amp; Magazine SUB Hamburg http://t.co/RcyKm9hFuO #obj2",
      "expandedUrl" : "https://twitter.com/i/web/status/397622769954725888"
    }
  },
  {
    "like" : {
      "tweetId" : "397695963105484801",
      "fullText" : "@OpenBiblioJobs Wir bilden kommendes Jahr zum #Fami aus, hier die Ausschreibung http://t.co/843VljdM0L",
      "expandedUrl" : "https://twitter.com/i/web/status/397695963105484801"
    }
  },
  {
    "like" : {
      "tweetId" : "390496765956198400",
      "fullText" : "wiss. Mitarbeiter/in EconBiz, Vollzeit, befristet auf 4 Jahre nach WissZeitVG, E 13 TV-L, ZBW Kiel/Hamburg http://t.co/2oSpn1GhYH #obj2",
      "expandedUrl" : "https://twitter.com/i/web/status/390496765956198400"
    }
  },
  {
    "like" : {
      "tweetId" : "384014543326040064",
      "fullText" : "ZBW MediaTalk Daily is out! http://t.co/FAdLEzEg79 ▸ Top stories today via @mobilbranche @OpenBiblioJobs @m_boesch",
      "expandedUrl" : "https://twitter.com/i/web/status/384014543326040064"
    }
  },
  {
    "like" : {
      "tweetId" : "381003604662169600",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/381003604662169600"
    }
  },
  {
    "like" : {
      "tweetId" : "381001291587018753",
      "fullText" : "Mein heutiges #ff geht an @OpenBiblioJobs. Ein toller Service für alle Leute aus dem Umfeld der Bibliotheks- und Informationswissenschaften.",
      "expandedUrl" : "https://twitter.com/i/web/status/381001291587018753"
    }
  },
  {
    "like" : {
      "tweetId" : "378475367096680448",
      "fullText" : "Danke für #ff @gonzo_archivist @OpenBiblioJobs @Mareike2405 @RegistrarTrekDE",
      "expandedUrl" : "https://twitter.com/i/web/status/378475367096680448"
    }
  },
  {
    "like" : {
      "tweetId" : "378407289020874753",
      "fullText" : "Weil doch #ff reitag ist: @OpenBiblioJobs @Persephone176 @Mareike2405 @RegistrarTrekDE",
      "expandedUrl" : "https://twitter.com/i/web/status/378407289020874753"
    }
  },
  {
    "like" : {
      "tweetId" : "375545947717398528",
      "fullText" : "@OpenBiblioJobs Super, danke!",
      "expandedUrl" : "https://twitter.com/i/web/status/375545947717398528"
    }
  },
  {
    "like" : {
      "tweetId" : "374978439587303424",
      "fullText" : "Wir suchen zum 1.1. eine/n Bibliothekar/in o. jemanden mit vergleichbarer Qualifikation: http://t.co/pLayDaNFbc cc @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/374978439587303424"
    }
  },
  {
    "like" : {
      "tweetId" : "374807487624785920",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/374807487624785920"
    }
  },
  {
    "like" : {
      "tweetId" : "370936991015505921",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/370936991015505921"
    }
  },
  {
    "like" : {
      "tweetId" : "370278043438546944",
      "fullText" : "#Audi sucht #Archivar @OpenBiblioJobs http://t.co/ZRqwRAbLm4",
      "expandedUrl" : "https://twitter.com/i/web/status/370278043438546944"
    }
  },
  {
    "like" : {
      "tweetId" : "369376221458481152",
      "fullText" : "@OpenBiblioJobs Danke für Eure tolle Arbeit :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/369376221458481152"
    }
  },
  {
    "like" : {
      "tweetId" : "364355013008560128",
      "fullText" : "@OpenBiblioJobs Euch gebührt mehr als nur #Lob. Denn ohne euer #Engagement würden einige #Arbeitssuchende ziemlich in die Röhre gucken!",
      "expandedUrl" : "https://twitter.com/i/web/status/364355013008560128"
    }
  },
  {
    "like" : {
      "tweetId" : "364358696605712384",
      "fullText" : "Der vdb ist schon dabei, wann unterstützt wohl der @bib_info @OpenBiblioJobs?",
      "expandedUrl" : "https://twitter.com/i/web/status/364358696605712384"
    }
  },
  {
    "like" : {
      "tweetId" : "364353762011267072",
      "fullText" : "@OpenBiblioJobs Danke :-) #openbibliojobs ist aber auch Gold wert!",
      "expandedUrl" : "https://twitter.com/i/web/status/364353762011267072"
    }
  },
  {
    "like" : {
      "tweetId" : "363946112320667648",
      "fullText" : "@OpenBiblioJobs richtig so :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/363946112320667648"
    }
  },
  {
    "like" : {
      "tweetId" : "358262437537005568",
      "fullText" : "@OpenBiblioJobs Bitte Sparten unterscheiden (Archivwesen), Archivjobs sind wichtiger als Verwaltungsjobs",
      "expandedUrl" : "https://twitter.com/i/web/status/358262437537005568"
    }
  },
  {
    "like" : {
      "tweetId" : "357898432104509440",
      "fullText" : "@OpenBiblioJobs ich bin auch für nein @bibliothekarin und @leerleser haben alles andere schon gesagt :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/357898432104509440"
    }
  },
  {
    "like" : {
      "tweetId" : "357855598378889217",
      "fullText" : "@OpenBiblioJobs Nein!!!",
      "expandedUrl" : "https://twitter.com/i/web/status/357855598378889217"
    }
  },
  {
    "like" : {
      "tweetId" : "357797305958666240",
      "fullText" : "@OpenBiblioJobs ich bin für nein. Schwerpunkt sollte erhalten bleiben.  Sind keine Jobbörse für die Verwaltung. #obj",
      "expandedUrl" : "https://twitter.com/i/web/status/357797305958666240"
    }
  },
  {
    "like" : {
      "tweetId" : "357798697460969472",
      "fullText" : "@OpenBiblioJobs Nein, ihr seid für Bibliotheken da. Wer auch in Verwaltungen suchen will, kann hierhin gehen: interamt.de",
      "expandedUrl" : "https://twitter.com/i/web/status/357798697460969472"
    }
  },
  {
    "like" : {
      "tweetId" : "357799968578351105",
      "fullText" : "+1 RT @leerleser: @OpenBiblioJobs Nein, ihr seid für Bibliotheken da. Wer auch in Verwaltungen suchen will, kann hierhin gehen: interamt.de",
      "expandedUrl" : "https://twitter.com/i/web/status/357799968578351105"
    }
  },
  {
    "like" : {
      "tweetId" : "355668440327012354",
      "fullText" : "@OpenBiblioJobs Wunderbar, das funktioniert hervorragend! Vielen Dank! :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/355668440327012354"
    }
  },
  {
    "like" : {
      "tweetId" : "355421915940274178",
      "fullText" : "@OpenBiblioJobs Hat auch eure schöne neue Seite einen RSS-Feed? Ich fand das bisher sehr hilfreich! Vielen Dank schon mal im Voraus! :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/355421915940274178"
    }
  },
  {
    "like" : {
      "tweetId" : "355240028693204992",
      "fullText" : "@bibliothekarin @OpenBiblioJobs @ger23mthings quatsch :-) die anderen Themen sind genauso spannend - also fast genauso :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/355240028693204992"
    }
  },
  {
    "like" : {
      "tweetId" : "354941700994637824",
      "fullText" : "@OpenBiblioJobs Oh, gar nicht gesehen. Danke :)",
      "expandedUrl" : "https://twitter.com/i/web/status/354941700994637824"
    }
  },
  {
    "like" : {
      "tweetId" : "354532408445513729",
      "fullText" : "@OpenBiblioJobs ist ab sofort unter https://t.co/9DkjhyKSfU erreichbar.",
      "expandedUrl" : "https://twitter.com/i/web/status/354532408445513729"
    }
  },
  {
    "like" : {
      "tweetId" : "354532413294129156",
      "fullText" : "@OpenBiblioJobs ist ab sofort unter https://t.co/zQ1gvs1wL8 erreichbar.",
      "expandedUrl" : "https://twitter.com/i/web/status/354532413294129156"
    }
  },
  {
    "like" : {
      "tweetId" : "354295870470111232",
      "fullText" : "@bibliothekarin @OpenBiblioJobs Ich weiß. Aber schon diese wenigen Metadaten können für Auswertungen von Nutzen sein.",
      "expandedUrl" : "https://twitter.com/i/web/status/354295870470111232"
    }
  },
  {
    "like" : {
      "tweetId" : "354277271126814721",
      "fullText" : "@OpenBiblioJobs http://t.co/wnrX5PbnIE",
      "expandedUrl" : "https://twitter.com/i/web/status/354277271126814721"
    }
  },
  {
    "like" : {
      "tweetId" : "354194524957974528",
      "fullText" : "RT @hauschke: Infobib: Stellenangebote auf http://t.co/7OHo1Srscf http://t.co/jKlgIfwoqh #obj #openbibliojobs",
      "expandedUrl" : "https://twitter.com/i/web/status/354194524957974528"
    }
  },
  {
    "like" : {
      "tweetId" : "354206699076333568",
      "fullText" : "OpenBiblioJobs an neuer Stelle http://t.co/SXAjmr62Ko via @netbib #obj #openbibliojobs",
      "expandedUrl" : "https://twitter.com/i/web/status/354206699076333568"
    }
  },
  {
    "like" : {
      "tweetId" : "354223857340661760",
      "fullText" : "Auch die Nachrichten für Öffentliche Bibliotheken NRW berichten: Open BiblioJobs zieht um http://t.co/yz5mmxzp6p #obj #openbibliojobs (DB)",
      "expandedUrl" : "https://twitter.com/i/web/status/354223857340661760"
    }
  },
  {
    "like" : {
      "tweetId" : "1387810416676511745",
      "fullText" : "@OpenBiblioJobs @bibliothekarin Für manche ist es ja auch o.k.",
      "expandedUrl" : "https://twitter.com/i/web/status/1387810416676511745"
    }
  },
  {
    "like" : {
      "tweetId" : "1385673694446604293",
      "fullText" : "Lektorat DVD und Auskunftsdienst in der Musikbibliothek und das für einen FaMI in TVöD-VKA E 9a unbefristet ☺️🤓 besser kann man als FaMI nicht eingestellt werden, cool 👍 @stabi_erlangen https://t.co/9Wm1QbCRcV",
      "expandedUrl" : "https://twitter.com/i/web/status/1385673694446604293"
    }
  },
  {
    "like" : {
      "tweetId" : "1382671306605350912",
      "fullText" : "@OpenBiblioJobs Seems legit 😉😂",
      "expandedUrl" : "https://twitter.com/i/web/status/1382671306605350912"
    }
  },
  {
    "like" : {
      "tweetId" : "1382671623208198150",
      "fullText" : "@OpenBiblioJobs Profil überprüfen - oder neue Chancen wahrnehmen ;-)",
      "expandedUrl" : "https://twitter.com/i/web/status/1382671623208198150"
    }
  },
  {
    "like" : {
      "tweetId" : "1382674112460492802",
      "fullText" : "Falls jemand Lust auf einen Berufswechsel hat.\nOder: Nachwuchsmangel führt zu kreativen Wegen! https://t.co/wHmPLbZ3XG",
      "expandedUrl" : "https://twitter.com/i/web/status/1382674112460492802"
    }
  },
  {
    "like" : {
      "tweetId" : "1382674857792569348",
      "fullText" : "@OpenBiblioJobs Im Handwerk gibt's noch größeren Personalmangel als in Bibliotheken. Die versuchen jetzt wohl einfach alles.",
      "expandedUrl" : "https://twitter.com/i/web/status/1382674857792569348"
    }
  },
  {
    "like" : {
      "tweetId" : "1382309222881300481",
      "fullText" : "@OpenBiblioJobs @bub_magazin Danke für die schnelle Antwort. Das kann ich gut nachvollziehen.",
      "expandedUrl" : "https://twitter.com/i/web/status/1382309222881300481"
    }
  },
  {
    "like" : {
      "tweetId" : "1381387448186458112",
      "fullText" : "This Tweet is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1381387448186458112"
    }
  },
  {
    "like" : {
      "tweetId" : "1381387444029915138",
      "fullText" : "This Tweet is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1381387444029915138"
    }
  },
  {
    "like" : {
      "tweetId" : "1380613111812620288",
      "fullText" : "@OpenBiblioJobs wir haben mit den Analysen gerade erst angefangen und werden im Laufe des Jahres noch weiter dran arbeiten und die Ergebnisse, Daten etc. dann nach und nach veröffentlichen",
      "expandedUrl" : "https://twitter.com/i/web/status/1380613111812620288"
    }
  },
  {
    "like" : {
      "tweetId" : "1377591762714304512",
      "fullText" : "Heute dürfen wir @swagunke als neue Fachreferentin u.a. für Geschichte und Ansprechpartnerin für den Bereich #DigitalHumanities bei uns begrüßen. Wir wünschen ihr einen guten Start und freuen uns auf eine gute Zusammenarbeit. #Fachreferat https://t.co/8vkGzSV3ZS",
      "expandedUrl" : "https://twitter.com/i/web/status/1377591762714304512"
    }
  },
  {
    "like" : {
      "tweetId" : "1360314505771769860",
      "fullText" : "@OpenBiblioJobs Done 😀",
      "expandedUrl" : "https://twitter.com/i/web/status/1360314505771769860"
    }
  },
  {
    "like" : {
      "tweetId" : "1354042035062374405",
      "fullText" : "@bodop @testroetm @OpenBiblioJobs Ja das muss halt jedem bewusst sein. Für Berufsanfänger und/oder Personen die in den letzten Zügen eines Bibliotheksstudiums sind. Ich bin trotzdem gespannt, zumal die Person dann zu uns in das Kinder- und Jugendbibliotheksteam kommt 🤗☺️",
      "expandedUrl" : "https://twitter.com/i/web/status/1354042035062374405"
    }
  },
  {
    "like" : {
      "tweetId" : "1352696723190198273",
      "fullText" : "@bibliothekarin @OpenBiblioJobs Danke für die Mühe.!!!",
      "expandedUrl" : "https://twitter.com/i/web/status/1352696723190198273"
    }
  },
  {
    "like" : {
      "tweetId" : "1352694685760942080",
      "fullText" : "Feststellung: Heute mussten viele kleine Wichtelmänner Überstunden machen. Jetzt prüfe ich 32 gemeldete Stellen bei @OpenBiblioJobs Mal sehen, wieviele für heute einzigartig sind und daher in die Freiheit der OBJ-Auflistung entlassen werden können. #ToDoAmFreitagAbend",
      "expandedUrl" : "https://twitter.com/i/web/status/1352694685760942080"
    }
  },
  {
    "like" : {
      "tweetId" : "1346367026042966016",
      "expandedUrl" : "https://twitter.com/i/web/status/1346367026042966016"
    }
  },
  {
    "like" : {
      "tweetId" : "1346355052542353409",
      "fullText" : "Gern geschehen! Und ich nütze die Gelegenheit als Mitglied des #VDB-Vorstands, um mich bei den vielen Kolleg:innen zu bedanken, die aktiv bei @OpenBiblioJobs mitmachen und ihre Zeit dafür investieren! Ihr seid toll 👏👏👏 https://t.co/aAQIcQEbwP",
      "expandedUrl" : "https://twitter.com/i/web/status/1346355052542353409"
    }
  },
  {
    "like" : {
      "tweetId" : "1341708012390658049",
      "fullText" : "Der Nachteil, wenn man für digitale Angebote zuständig ist:\nStatt selbstgebackener Kekse kriegt man Rentier-GIFs.",
      "expandedUrl" : "https://twitter.com/i/web/status/1341708012390658049"
    }
  },
  {
    "like" : {
      "tweetId" : "1341116303575298049",
      "fullText" : "@OpenBiblioJobs oha, interessant",
      "expandedUrl" : "https://twitter.com/i/web/status/1341116303575298049"
    }
  },
  {
    "like" : {
      "tweetId" : "1336413239408812034",
      "fullText" : "@OpenBiblioJobs Danke für eure Arbeit! Den Feierabend habt ihr mehr als verdient! :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1336413239408812034"
    }
  },
  {
    "like" : {
      "tweetId" : "1336056118582382593",
      "fullText" : "@OpenBiblioJobs Ich bin zuversichtlich, dass ich ab dem Wochende wieder mehr unterstützen kann.",
      "expandedUrl" : "https://twitter.com/i/web/status/1336056118582382593"
    }
  },
  {
    "like" : {
      "tweetId" : "1331703945815859201",
      "fullText" : "@biblioreader Herzlichen Glückwunsch! \nHabe gerade auf @OpenBiblioJobs die Stellenanzeige für Saarbrücken gesehen und war leicht irritiert😉\nAber das erklärt es natürlich 😉👍",
      "expandedUrl" : "https://twitter.com/i/web/status/1331703945815859201"
    }
  },
  {
    "like" : {
      "tweetId" : "1328696868193394688",
      "fullText" : "Wir haben als #Stadtbibliothek den #OpenLibraryBadge erhalten für:\n\n📌 Lernmaterialien unter offener Lizenz\n📌 Bürger*innenbeteiligung\n📌 WomenEdit\n📌 Fotos auf Wikimedia Commons\n📌 Angebote zur #Integration &amp;  #Inklusion \n\n➡️ https://t.co/E7t4twOnLx /mn https://t.co/9A0Uj99JOJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1328696868193394688"
    }
  },
  {
    "like" : {
      "tweetId" : "1321814163908399105",
      "fullText" : "Der neue Arbeitsvertrag wird nachher zur Post gebracht und an dieser Stelle einmal ein ganz großes DANKE an @OpenBiblioJobs die mir jahrelang immer eine gute Quelle waren für die Stellensuche. Und jetzt hat es endlich geklappt :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1321814163908399105"
    }
  },
  {
    "like" : {
      "tweetId" : "1319233331662303233",
      "fullText" : "Heute startet der 4tägige weiterführende Workshop zur #ITKompetenz und #Datenkompetenz der Initiative Fortbildung für wissenschaftliche Spezialbibliotheken mit unseren Expert*innen @konradfoerstner @TillSauerwein und @MueRabea Wir wünschen viele neue Erkenntnisse und Spaß dabei!",
      "expandedUrl" : "https://twitter.com/i/web/status/1319233331662303233"
    }
  },
  {
    "like" : {
      "tweetId" : "1318632644180119552",
      "fullText" : "@OpenBiblioJobs Ach was, der zweite geht in Ordnung 😁 das weiß jeder was gemeint ist ☺️ dann 🍻 auf den Feierabend",
      "expandedUrl" : "https://twitter.com/i/web/status/1318632644180119552"
    }
  },
  {
    "like" : {
      "tweetId" : "1318625262532255747",
      "fullText" : "@OpenBiblioJobs Da hat sich ein kleiner Fehler eingeschlichen...🙂 Die Abt. Wirtschaftsförderung, Soziales, Weiterbildung und Kultur - Amt für Weiterbildung und Kultur sucht zur Kennziffer 210/2020 ab dem 01.12.2020, befristet bis 31.10.2023, Personal (m/w/d) für das Aufgabengebiet als",
      "expandedUrl" : "https://twitter.com/i/web/status/1318625262532255747"
    }
  },
  {
    "like" : {
      "tweetId" : "1307025164060766213",
      "fullText" : "Aktuelles #Stellenangebot: Unser Team sucht Verstärkung! \n\nFür das neue #OpenAccess-Lab (https://t.co/iji12yVf7u) an der @HAW_Hamburg ist eine Stelle ausgeschrieben: \n\nhttps://t.co/OlLZKu2Av7 @OpenBiblioJobs\n \nBis zum 15.10.2020 bewerben! 👍",
      "expandedUrl" : "https://twitter.com/i/web/status/1307025164060766213"
    }
  },
  {
    "like" : {
      "tweetId" : "1301493665588752390",
      "fullText" : "Kennt ihr Menschen in #Gelsenkirchen, die wegen Alter, Krankheit oder Behinderung ihr Zuhause nicht mehr verlassen können? Unser #MedienLieferService bringt Medien kostenlos nach Hause oder ins Heim. 👉https://t.co/xMz2TJvNrX https://t.co/GdiHJoLomY",
      "expandedUrl" : "https://twitter.com/i/web/status/1301493665588752390"
    }
  },
  {
    "like" : {
      "tweetId" : "1297621788076146691",
      "fullText" : "My first #TidyTuesday using stacked bar charts. Learning how to manipulate fonts, colours and margins. #dataviz #r4ds #ggplot2 #RStats https://t.co/7XidEKYG79",
      "expandedUrl" : "https://twitter.com/i/web/status/1297621788076146691"
    }
  },
  {
    "like" : {
      "tweetId" : "1297000057477070848",
      "fullText" : "@TroveAustralia But if we’re really want to examine these questions in depth we need to take search interfaces seriously as sites of critical analysis. I explore this a bit more in my article ‘Hacking heritage: Understanding the limits of online access’: https://t.co/S8gUhrCjVX https://t.co/HrHckAIGUF",
      "expandedUrl" : "https://twitter.com/i/web/status/1297000057477070848"
    }
  },
  {
    "like" : {
      "tweetId" : "1296985647559786496",
      "fullText" : "Hey #ozhist #twitterstorians, if you want to explore the gaps &amp; inconsistencies in @TroveAustralia’s coverage of digitised newspapers the #GLAMWorkbench can help! Here’s a few suggestions...",
      "expandedUrl" : "https://twitter.com/i/web/status/1296985647559786496"
    }
  },
  {
    "like" : {
      "tweetId" : "1288414249920888833",
      "fullText" : "@OpenBiblioJobs Wir arbeiteten gerade daran 😉 → jetzt auch sichtbar für alle buchhalterischen Nicht-Magier:innen. Die Bewerbungsfrist für die Stelle Sachbearbeiter:in Buchhaltung läuft noch bis 28.8.2020. \nhttps://t.co/QxG320uQkD",
      "expandedUrl" : "https://twitter.com/i/web/status/1288414249920888833"
    }
  },
  {
    "like" : {
      "tweetId" : "1286888918449819649",
      "fullText" : "@OpenBiblioJobs @Lambo Damals gab es @OpenBiblioJobs noch nicht.",
      "expandedUrl" : "https://twitter.com/i/web/status/1286888918449819649"
    }
  },
  {
    "like" : {
      "tweetId" : "1286767129774219264",
      "expandedUrl" : "https://twitter.com/i/web/status/1286767129774219264"
    }
  },
  {
    "like" : {
      "tweetId" : "1286665068881547266",
      "fullText" : "@OpenBiblioJobs Uups! Das haben wir nicht gesehen. Verdammtes Twitter-Algorithmus. :D",
      "expandedUrl" : "https://twitter.com/i/web/status/1286665068881547266"
    }
  },
  {
    "like" : {
      "tweetId" : "1286661771672027136",
      "fullText" : "@OpenBiblioJobs Ich kann mich ehrlich gesagt nicht mehr erinnern. 🙈",
      "expandedUrl" : "https://twitter.com/i/web/status/1286661771672027136"
    }
  },
  {
    "like" : {
      "tweetId" : "1286585197568368640",
      "fullText" : "@OpenBiblioJobs Klar, gerne! Wie läuft das?",
      "expandedUrl" : "https://twitter.com/i/web/status/1286585197568368640"
    }
  },
  {
    "like" : {
      "tweetId" : "1286585606039121921",
      "fullText" : "@OpenBiblioJobs Ah, okay, jetzt erst auf den Link geklickt. Wir werden versuchen, da regelmäßig dran zu denken! 🙏",
      "expandedUrl" : "https://twitter.com/i/web/status/1286585606039121921"
    }
  },
  {
    "like" : {
      "tweetId" : "1285897923365085184",
      "fullText" : "Indeed 😉. Und bräuchten Unterstützung. Bewerbungen sind jetzt sogar per Mail möglich\n\nhttps://t.co/NbP2yzU0CT https://t.co/CxP6DzCmNy",
      "expandedUrl" : "https://twitter.com/i/web/status/1285897923365085184"
    }
  },
  {
    "like" : {
      "tweetId" : "1284094084936880128",
      "fullText" : "@OpenBiblioJobs @SirNursington Immerhin 😅.",
      "expandedUrl" : "https://twitter.com/i/web/status/1284094084936880128"
    }
  },
  {
    "like" : {
      "tweetId" : "1280976969505673219",
      "fullText" : "Nachwuchsrekrutierung war heute ein Thema bei #NFDIKonf2020. Hier ein erster Vorschlag für mehr Sichtbarkeit: postet #NFDI #NFDI_de Jobs mit dem neuen Hashtag #NFDI_Jobs",
      "expandedUrl" : "https://twitter.com/i/web/status/1280976969505673219"
    }
  },
  {
    "like" : {
      "tweetId" : "1276500830703824896",
      "fullText" : "@OpenBiblioJobs Klaro! Immer! 😎",
      "expandedUrl" : "https://twitter.com/i/web/status/1276500830703824896"
    }
  },
  {
    "like" : {
      "tweetId" : "1272880436272906241",
      "fullText" : "@OpenBiblioJobs Rote Nasen im Büro müssen nicht unbedingt mit der Sonne zutun haben. Eventuell ist ja mal wieder eine Kollegin 50 geworden, oder ein Meeting lief sehr erfolgreich! 😅",
      "expandedUrl" : "https://twitter.com/i/web/status/1272880436272906241"
    }
  },
  {
    "like" : {
      "tweetId" : "1272856599015686144",
      "fullText" : "@OpenBiblioJobs Ich würde diesen Tweet zu gerne als Ausrede nutzen.\n\n\"Chef, ich kann jetzt nicht arbeiten und Jobs eintragen!\"\n\"Warum denn nicht, Kawuppke??\"\n\"Die Server sind down und die Seite sagt mir, ich soll ein Eis essen gehen\"\n\"Erlaubt, Kawuppke!\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1272856599015686144"
    }
  },
  {
    "like" : {
      "tweetId" : "1272858509584011268",
      "fullText" : "@OpenBiblioJobs Gut, ich wäre jetzt eher auf einer Suche nach einer Stelle, anstatt eine einzutragen. Aber der Tweet eignete sich perfekt für ein fiktives Gespräch!\n\nDanke für eure Arbeit und eure fleißigen Eintragungen!",
      "expandedUrl" : "https://twitter.com/i/web/status/1272858509584011268"
    }
  },
  {
    "like" : {
      "tweetId" : "1272421524117393408",
      "fullText" : "@OpenBiblioJobs Sehr cool. 👍🙂",
      "expandedUrl" : "https://twitter.com/i/web/status/1272421524117393408"
    }
  },
  {
    "like" : {
      "tweetId" : "1271396617439129600",
      "fullText" : "@OpenBiblioJobs Das hatte ich noch gar nicht gesehen, da ich meistens nur in den RSS-Feed schaue.\nWenn ich das richtig sehe, sind ja aber nirgends die abgelaufenen Stellenausschreibungen zu sehen, oder?",
      "expandedUrl" : "https://twitter.com/i/web/status/1271396617439129600"
    }
  },
  {
    "like" : {
      "tweetId" : "1271333289916166146",
      "fullText" : "Sollte es nicht mal ein Archiv für die Stellenausschreibungen von @OpenBiblioJobs geben oder habe ich das falsch in Erinnerung?\n\nIch meine mich zu erinnern, dass da etwas geplant war, um Stellenausschreibungen über einen längeren Zeitraum hinweg vergleichen zu können.",
      "expandedUrl" : "https://twitter.com/i/web/status/1271333289916166146"
    }
  },
  {
    "like" : {
      "tweetId" : "1271335656992768006",
      "fullText" : "@OpenBiblioJobs Die Metadaten sind in dem Fall vermutlich nicht ausreichend, aber ich bin gerade bei der Wayback Machine fündig geworden. 🙂",
      "expandedUrl" : "https://twitter.com/i/web/status/1271335656992768006"
    }
  },
  {
    "like" : {
      "tweetId" : "1271336057703936000",
      "fullText" : "@PiIsntPie @OpenBiblioJobs Daran erinnere mich auch, d.h. dass so etwas geplant war.",
      "expandedUrl" : "https://twitter.com/i/web/status/1271336057703936000"
    }
  },
  {
    "like" : {
      "tweetId" : "1271338760949714944",
      "fullText" : "@OpenBiblioJobs Auch viel wert. Wäre es denn eine Möglichkeit ein Archiv anzulegen, dass direkt zum Internet Archive verlinkt?",
      "expandedUrl" : "https://twitter.com/i/web/status/1271338760949714944"
    }
  },
  {
    "like" : {
      "tweetId" : "1271338627025588224",
      "fullText" : "@fdmhildesheim @PiIsntPie Das macht halt Arbeit... als Zwischenlösung würde ich ab jetzt bei jeder Anfrage die csv-Datei auch in Github hochladen und so für alle bereitstellen. (Phu)",
      "expandedUrl" : "https://twitter.com/i/web/status/1271338627025588224"
    }
  },
  {
    "like" : {
      "tweetId" : "1270796335495684098",
      "expandedUrl" : "https://twitter.com/i/web/status/1270796335495684098"
    }
  },
  {
    "like" : {
      "tweetId" : "1270788802068480006",
      "fullText" : "@OpenBiblioJobs @bib_info Ich bin auch kein BIB-Mitglied (sondern beim VDB).",
      "expandedUrl" : "https://twitter.com/i/web/status/1270788802068480006"
    }
  },
  {
    "like" : {
      "tweetId" : "1270788576427626498",
      "fullText" : "@OpenBiblioJobs @bib_info War absolut keine Kritik an eurer tollen Arbeit mit @OpenBiblioJobs . Mir ging es rein um die ausgeschriebe Stelle. Kann man sich auch an die KEB wenden, wenn es nicht um den eigenen Job geht?",
      "expandedUrl" : "https://twitter.com/i/web/status/1270788576427626498"
    }
  },
  {
    "like" : {
      "tweetId" : "1270779792107937792",
      "fullText" : "@OpenBiblioJobs Wobei mich eine Eiter-Leiter/in oder eine Weiter-Leiterin als Stelle durchaus interessieren würde! 😉",
      "expandedUrl" : "https://twitter.com/i/web/status/1270779792107937792"
    }
  },
  {
    "like" : {
      "tweetId" : "1258724584850948097",
      "fullText" : "@OpenBiblioJobs Perfektes Beispiel für die Diskussion gestern. Egal welchen Abschluss du hast, du leitest hier und bekommst die 9. Für Famis n guter Deal, für ausstudierte eher nicht. #fami",
      "expandedUrl" : "https://twitter.com/i/web/status/1258724584850948097"
    }
  },
  {
    "like" : {
      "tweetId" : "1258688036696723456",
      "fullText" : "This Tweet is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1258688036696723456"
    }
  },
  {
    "like" : {
      "tweetId" : "1256062184809025536",
      "fullText" : "@OpenBiblioJobs @bibliothekarin Schön, wenn es ein Team gibt und man sich die Arbeit teilen kann.",
      "expandedUrl" : "https://twitter.com/i/web/status/1256062184809025536"
    }
  },
  {
    "like" : {
      "tweetId" : "1245751318117048323",
      "fullText" : "@OpenBiblioJobs Immerhin ist es eine direkt referenzierbare HTML Seite und kein PDF ;-)",
      "expandedUrl" : "https://twitter.com/i/web/status/1245751318117048323"
    }
  },
  {
    "like" : {
      "tweetId" : "1245713687568154625",
      "fullText" : "Wer schon länger unseren Service nutzt nd noch nie eine freie Stelle eingetragen hat, muss diesen Link https://t.co/F547x3SyJj 10x abschreiben!",
      "expandedUrl" : "https://twitter.com/i/web/status/1245713687568154625"
    }
  },
  {
    "like" : {
      "tweetId" : "1239633154094313474",
      "fullText" : "@Sir_Ivan_ War heute leider nichts dabei, gern mal wieder reinschauen!",
      "expandedUrl" : "https://twitter.com/i/web/status/1239633154094313474"
    }
  },
  {
    "like" : {
      "tweetId" : "1239632784022482947",
      "fullText" : "@OpenBiblioJobs Danke @phu ... Ein bisschen Abwechslung in der Corona-Timeline tut gut.",
      "expandedUrl" : "https://twitter.com/i/web/status/1239632784022482947"
    }
  },
  {
    "like" : {
      "tweetId" : "1226497603107422208",
      "fullText" : "Super! @OpenBiblioJobs wird dadurch *noch* besser! https://t.co/ImwzmIoYNn",
      "expandedUrl" : "https://twitter.com/i/web/status/1226497603107422208"
    }
  },
  {
    "like" : {
      "tweetId" : "1225806691381522433",
      "fullText" : "Dort könnt ihr auch unsere aktuelle Stellenausschreibung für eine_n \"Mitarbeiter_in im Team Service &amp; Information (w/m/d)\" finden! 🙃 https://t.co/i4pvxepP79",
      "expandedUrl" : "https://twitter.com/i/web/status/1225806691381522433"
    }
  },
  {
    "like" : {
      "tweetId" : "1220105044672045057",
      "fullText" : "Amazon in München sucht einen \"Browse Developer &amp; Taxonomist\" - geeignet scheinen u.a. Bibliothekare und Informationswissenschaftler: https://t.co/xogLjXnIiw \n(gesehen im RSS-Feed von @OpenBiblioJobs)",
      "expandedUrl" : "https://twitter.com/i/web/status/1220105044672045057"
    }
  },
  {
    "like" : {
      "tweetId" : "1197625895663607819",
      "fullText" : "@OpenBiblioJobs @GI_weltweit Ich denke auch, dass Studierende Gelegenheit zu einem Auslandsaufenthalt bekommen sollten. Aber ohne Unterstützung der Praktikumsstelle trauen sich dies viele Studis sicherlich nicht zu und bewerben sich erst gar nicht. Wäre schade drum ... 🙁",
      "expandedUrl" : "https://twitter.com/i/web/status/1197625895663607819"
    }
  },
  {
    "like" : {
      "tweetId" : "1195429433156526080",
      "fullText" : "Übrigens war auch die Session zu @OpenBiblioJobs sehr informativ! Da steckt noch mehr Handarbeit drin als man denkt und jede Hilfe wird gerne angenommen!\n#bibcamp2019 https://t.co/kFo4OeKkrH",
      "expandedUrl" : "https://twitter.com/i/web/status/1195429433156526080"
    }
  },
  {
    "like" : {
      "tweetId" : "1191422799715459073",
      "fullText" : "Los... wer nen Job in Köln sucht. Die sind voll töfte da! https://t.co/kP3gT4M2RN",
      "expandedUrl" : "https://twitter.com/i/web/status/1191422799715459073"
    }
  },
  {
    "like" : {
      "tweetId" : "1189225838941818888",
      "fullText" : "Abends ... #Jena https://t.co/0HnHIn1u9o https://t.co/uTCMVJNh93",
      "expandedUrl" : "https://twitter.com/i/web/status/1189225838941818888"
    }
  },
  {
    "like" : {
      "tweetId" : "1186177262242148352",
      "fullText" : "@OpenBiblioJobs NRW-friends!",
      "expandedUrl" : "https://twitter.com/i/web/status/1186177262242148352"
    }
  },
  {
    "like" : {
      "tweetId" : "1176179927386853378",
      "fullText" : "This one is for our friends at @OpenBiblioJobs! 😘 https://t.co/84xqAZXBEg",
      "expandedUrl" : "https://twitter.com/i/web/status/1176179927386853378"
    }
  },
  {
    "like" : {
      "tweetId" : "1176176086306177024",
      "fullText" : "@bibliothekarin @OpenBiblioJobs @SilkeClausing Ist ein guter Punkt, die Bewerbung noch einmal etwas verfeinern ist ein Punkt den ich sicher angehen kann.\n\nAuch wenn ich ja i.d.R. immer eingeladen werde und danach erst ein : \"leider doch kein Interesse ... aber vielen Dank\" kommt.\n\nDanke für die Anregungen. @bibliothekarin  :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1176176086306177024"
    }
  },
  {
    "like" : {
      "tweetId" : "1176171256976216066",
      "fullText" : "@OpenBiblioJobs So unlogisch ist die Fake-Statistik auch nicht.\n\nDie Bibliotheken wollen Leute mit Berufserfahrung. Wenn sie dich aber als Neueinsteiger nach der Ausbildung nicht einstellen, kannst du keine Erfahrung sammeln. Daher wirste auch nicht eingestellt.\n\nEin Teufelskreis. Leider.",
      "expandedUrl" : "https://twitter.com/i/web/status/1176171256976216066"
    }
  },
  {
    "like" : {
      "tweetId" : "1176161313552252929",
      "fullText" : "Ich kann diesen Job sehr empfehlen: https://t.co/4ovJyWlUdm",
      "expandedUrl" : "https://twitter.com/i/web/status/1176161313552252929"
    }
  },
  {
    "like" : {
      "tweetId" : "1172184370452602881",
      "fullText" : "wir wollen ja keine langeweile beim freischalten bekommen ... https://t.co/a9zPkuOSv3",
      "expandedUrl" : "https://twitter.com/i/web/status/1172184370452602881"
    }
  },
  {
    "like" : {
      "tweetId" : "1172183198102634497",
      "fullText" : "Whoa, die Warteschlange im Dashboard. \nEs geht munter weiter mit den freien Stellen. https://t.co/M3BRAdbEHH",
      "expandedUrl" : "https://twitter.com/i/web/status/1172183198102634497"
    }
  },
  {
    "like" : {
      "tweetId" : "1171852370415947776",
      "fullText" : "@OpenBiblioJobs Für unsere Studierenden wäre eine zeitigere Ausschreibung wichtig, um mehr Vorlauf zu haben. @bibverband",
      "expandedUrl" : "https://twitter.com/i/web/status/1171852370415947776"
    }
  },
  {
    "like" : {
      "tweetId" : "1171784615595585536",
      "fullText" : "@OpenBiblioJobs @BibliothekSande Toll, dass in Sande ausgebildet wird.",
      "expandedUrl" : "https://twitter.com/i/web/status/1171784615595585536"
    }
  },
  {
    "like" : {
      "tweetId" : "1171692573477560320",
      "fullText" : "Stellen in Bibliotheken - nun nach WB und ÖB sortiert. Merci @OpenBiblioJobs https://t.co/W3vz1n2ZvA",
      "expandedUrl" : "https://twitter.com/i/web/status/1171692573477560320"
    }
  },
  {
    "like" : {
      "tweetId" : "1167495986660478976",
      "fullText" : "Das dürfte ein neuer Rekord sein, wir haben zurzeit 342 freie Stellen nachgewiesen.",
      "expandedUrl" : "https://twitter.com/i/web/status/1167495986660478976"
    }
  },
  {
    "like" : {
      "tweetId" : "1156270436596035584",
      "fullText" : "@OpenBiblioJobs https://t.co/bnvowkOuKQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1156270436596035584"
    }
  },
  {
    "like" : {
      "tweetId" : "1146504012491042816",
      "fullText" : "@OpenBiblioJobs Cool, danke für die schnelle Reaktion. Jetzt aber schönen Abend :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1146504012491042816"
    }
  },
  {
    "like" : {
      "tweetId" : "1146502708490383360",
      "fullText" : "Hi @OpenBiblioJobs, bei dieser Stelle https://t.co/sc6h654PBl scheint etwas mit den Geodaten nicht zu stimmen. Eintrag liegt auf direkt auf dem Äquator, in der Beschreibung: \"Der Dienstort ist Berlin.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1146502708490383360"
    }
  },
  {
    "like" : {
      "tweetId" : "1143206254376116229",
      "fullText" : "@OpenBiblioJobs Danke für eure aufopferungsvolle und mühsame Arbeit! Euch auch einen angenehmen Abend :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1143206254376116229"
    }
  },
  {
    "like" : {
      "tweetId" : "1142021866753855488",
      "fullText" : "@OpenBiblioJobs @bibliothekarin Ich hab mal eine SVG-Variante eures Logos gebaut, irgendwie gabs da noch nix. Ich hoffe, das war OK https://t.co/L6e7cNulnK",
      "expandedUrl" : "https://twitter.com/i/web/status/1142021866753855488"
    }
  },
  {
    "like" : {
      "tweetId" : "1141965517273620481",
      "fullText" : "@bibliothekarin @wonkestehle @OpenBiblioJobs #jobfairy #jobfairies for some!",
      "expandedUrl" : "https://twitter.com/i/web/status/1141965517273620481"
    }
  },
  {
    "like" : {
      "tweetId" : "1139866054589591552",
      "fullText" : "@bibliothekarin @OpenBiblioJobs Ja, da kommt angesichts des vergleichsweise hohen Durchschnittsalters der Kollegien einiges auf uns zu.",
      "expandedUrl" : "https://twitter.com/i/web/status/1139866054589591552"
    }
  },
  {
    "like" : {
      "tweetId" : "1129466369341317121",
      "fullText" : "Besonders attraktiv: hier wird die Mediathek nach Generalsanierung neu aufgebaut! #Schulbibliothek https://t.co/hClxR34wKm",
      "expandedUrl" : "https://twitter.com/i/web/status/1129466369341317121"
    }
  },
  {
    "like" : {
      "tweetId" : "1129477395566800897",
      "fullText" : "@OpenBiblioJobs https://t.co/T3HliPD5HK",
      "expandedUrl" : "https://twitter.com/i/web/status/1129477395566800897"
    }
  },
  {
    "like" : {
      "tweetId" : "1119203801431531521",
      "fullText" : "@OpenBiblioJobs Fragen zum Job beantworte ich gerne via DM.",
      "expandedUrl" : "https://twitter.com/i/web/status/1119203801431531521"
    }
  },
  {
    "like" : {
      "tweetId" : "1115158586945146881",
      "fullText" : "https://t.co/LCVpjeOGvG bringt ein paar Tipps für die Handhabung von @OpenBiblioJobs für Stellen_meldende_. https://t.co/vUlPCqZTP0",
      "expandedUrl" : "https://twitter.com/i/web/status/1115158586945146881"
    }
  },
  {
    "like" : {
      "tweetId" : "1114164049783160833",
      "fullText" : "Meine alte #OCRD-Stelle ist ausgeschrieben! Sie bietet ein umfassendes Aufgabenfeld in der #Projektkoordination, spannende Einblicke in die Softwareentwicklung, Digitalisierung und Arbeit mit hist. Material sowie ein tolles Team!\nhttps://t.co/S8F1mP3XwG\n@OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/1114164049783160833"
    }
  },
  {
    "like" : {
      "tweetId" : "1114104730198921216",
      "fullText" : "Kansalliskirjasto @NatLibFi hakee uusia IT-osaajia erilaisiin tehtäviin. Avoin haku 5.5. saakka. Kerro meille kuka olet, mitä osaat ja mitä haluaisit tehdä! https://t.co/snHWm390mh #UX #frontend #backend #työpaikat #jobs #library ping @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/1114104730198921216"
    }
  },
  {
    "like" : {
      "tweetId" : "1110798352243802112",
      "fullText" : "Sie sind Fachinformatikerin oder Fachinformatiker? Dann würden wir uns über Ihre Bewerbung sehr freuen:  https://t.co/3psbtWouKy #stellenangebot @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/1110798352243802112"
    }
  },
  {
    "like" : {
      "tweetId" : "1110283742181015552",
      "fullText" : "@OpenBiblioJobs Danke für den Hinweis  - wir kümmern uns drum!",
      "expandedUrl" : "https://twitter.com/i/web/status/1110283742181015552"
    }
  },
  {
    "like" : {
      "tweetId" : "1110257093653733376",
      "fullText" : "@OpenBiblioJobs @SilkeClausing Ja, das war bisher leider in vielen Fällen so. Mal sehen ob sich das ab 2020 verändert...",
      "expandedUrl" : "https://twitter.com/i/web/status/1110257093653733376"
    }
  },
  {
    "like" : {
      "tweetId" : "1108853275565215754",
      "fullText" : "@OpenBiblioJobs kennt ihr wahrscheinlich sowieso: https://t.co/hGnzr7jWzB",
      "expandedUrl" : "https://twitter.com/i/web/status/1108853275565215754"
    }
  },
  {
    "like" : {
      "tweetId" : "1109156883540201472",
      "fullText" : "Mit Hilfe von @EzellaGarnie tröten wir die Stellenangebote auch drüben auf https://t.co/fake90G6YW \nProbiert die Alternative zu Twitter aus! Open source, selbst gehostet und werbefrei.",
      "expandedUrl" : "https://twitter.com/i/web/status/1109156883540201472"
    }
  },
  {
    "like" : {
      "tweetId" : "1108778131111010304",
      "fullText" : "@OpenBiblioJobs @MHH_Paris Ich habe leider keinen Link, aber das @MHH_Paris macht das ggf. sicher gerne 🙈😊",
      "expandedUrl" : "https://twitter.com/i/web/status/1108778131111010304"
    }
  },
  {
    "like" : {
      "tweetId" : "1108776270270222338",
      "fullText" : "Gesichtet: ein tolles Bibliotheksstipendium im @MHH_Paris - Bewerbungsfrist läuft noch bis zum 31.03.! @OpenBiblioJobs https://t.co/uIeEVywhXT",
      "expandedUrl" : "https://twitter.com/i/web/status/1108776270270222338"
    }
  },
  {
    "like" : {
      "tweetId" : "1103023749975236608",
      "fullText" : "@OpenBiblioJobs Die Stelle ist mit A9 ausgeschrieben.",
      "expandedUrl" : "https://twitter.com/i/web/status/1103023749975236608"
    }
  },
  {
    "like" : {
      "tweetId" : "1100132984227856385",
      "fullText" : "@OpenBiblioJobs Ob würdig weiß ich nicht, aber auf jeden Fall interpretierbar. 😉",
      "expandedUrl" : "https://twitter.com/i/web/status/1100132984227856385"
    }
  },
  {
    "like" : {
      "tweetId" : "1097411334411636736",
      "fullText" : "FaMIs aufgepasst: Leitungsassistenz in der Medizinischen Bibliothek @ChariteBerlin gesucht, E8 TVöD! Bewerbungsfrist endet Mittwoch diese Woche --&gt; 20.2. \nhttps://t.co/ek5gZ54ztO @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/1097411334411636736"
    }
  },
  {
    "like" : {
      "tweetId" : "1095656069060325377",
      "fullText" : "@OpenBiblioJobs Done! :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1095656069060325377"
    }
  },
  {
    "like" : {
      "tweetId" : "1095303395982917632",
      "fullText" : "Unsere Idee für einen Kompetenzmonitor aufbauend auf @openbibliojobs, mit Endorsement von @bib_info und #VDB \n\nPotenzial von offenen, strukturierten Daten optimal nutzen für die Beobachtung der Entwicklung neuer Arbeitsfelder in Bibliotheken!!\n\nhttps://t.co/rQs3TPL6qq",
      "expandedUrl" : "https://twitter.com/i/web/status/1095303395982917632"
    }
  },
  {
    "like" : {
      "tweetId" : "1091626132330479616",
      "fullText" : "@Lambo @TIBHannover @OpenBiblioJobs @StabiHH @ZBW_MediaTalk @subugoe @sbb_news @ETHBibliothek @bibverband Hier die Hochschulen nicht vergessen. Wäre vielleichtein schönes Projekt #kiba @IMDHH",
      "expandedUrl" : "https://twitter.com/i/web/status/1091626132330479616"
    }
  },
  {
    "like" : {
      "tweetId" : "1091416324717318145",
      "fullText" : "@UrsulaGeorgy Themen, die von der @TIBHannover angeboten werden, gibt es als öffentliche Wiki-Seite. Vielleicht bräuchten wir für Projektthemen auch einen Aggregator, nach dem Modell von @OpenBiblioJobs? Interesse, @StabiHH, @ZBW_MediaTalk, @subugoe, @sbb_news, @ETHBibliothek, @bibverband...?",
      "expandedUrl" : "https://twitter.com/i/web/status/1091416324717318145"
    }
  },
  {
    "like" : {
      "tweetId" : "1089812419801726976",
      "fullText" : "@OpenBiblioJobs Das braucht man aber in München auch zum überleben ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/1089812419801726976"
    }
  },
  {
    "like" : {
      "tweetId" : "1089213354017726464",
      "fullText" : "@OpenBiblioJobs Anspruchsvoll und eigentlich genug für zwei Stellen ...",
      "expandedUrl" : "https://twitter.com/i/web/status/1089213354017726464"
    }
  },
  {
    "like" : {
      "tweetId" : "1085993319379976194",
      "fullText" : "@OpenBiblioJobs Och mittlerweile gibt es aber auch teils die seltsamsten Sachen,\n\n15h Stellen, Stellen wo du 100% als gelernter FaMI arbeiten sollst, aber nur TVL 3-4 geboten wird.\n\nMittlerweile muss man ja schon froh sein wenn die Stelle auf ein Jahr befristet ist.",
      "expandedUrl" : "https://twitter.com/i/web/status/1085993319379976194"
    }
  },
  {
    "like" : {
      "tweetId" : "1085993089599225856",
      "fullText" : "@OpenBiblioJobs Sieht man ja an der Anzeige aus München",
      "expandedUrl" : "https://twitter.com/i/web/status/1085993089599225856"
    }
  },
  {
    "like" : {
      "tweetId" : "1062354955951112193",
      "fullText" : "We're looking for IT people to work on exciting projects at @NatLibFi! https://t.co/CaykNIOi27 #jobs #library ping @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/1062354955951112193"
    }
  },
  {
    "like" : {
      "tweetId" : "1049704934713769984",
      "fullText" : "OpenBiblioJobs – offen, unabhängig und ehrenamtlich - Wie funktioniert eigentlich OBJ hinter den Kulissen. @herr_tu und @bibliothekarin beantworten diese Frage in der neuen o-bib-Ausgabe https://t.co/4IMFP0D7nM",
      "expandedUrl" : "https://twitter.com/i/web/status/1049704934713769984"
    }
  },
  {
    "like" : {
      "tweetId" : "1051808736434483200",
      "fullText" : "@wibblywobblywoo It’s data. You view and interpret it. You’ll be using your education, personal history and worldview to interpret this. You might see a wider point, you might not. Maybe you find this somehow interesting, maybe you won’t.",
      "expandedUrl" : "https://twitter.com/i/web/status/1051808736434483200"
    }
  },
  {
    "like" : {
      "tweetId" : "1042008107981922304",
      "fullText" : "Dieses Q-Wort gefällt mir (durchaus im doppelten Sinne) sehr gut, es sollte viel häufiger in Stellenausschreibungen von Bibliotheken stehen. https://t.co/DGL3YfQ2U5",
      "expandedUrl" : "https://twitter.com/i/web/status/1042008107981922304"
    }
  },
  {
    "like" : {
      "tweetId" : "1042051334919401475",
      "fullText" : "Zum Abschluss von #VIVOde18 untersucht @inablu eine Frage, die gerade sehr virulent ist: Welche Qualifikationen brauchen diejenigen, die zukünftig Forschungsinformationssysteme betreiben, und (wie) kommen sie an diese Kompetenzen? - Analyse von @OpenBiblioJobs, Curricula etc.",
      "expandedUrl" : "https://twitter.com/i/web/status/1042051334919401475"
    }
  },
  {
    "like" : {
      "tweetId" : "1039969127484542976",
      "fullText" : "@OpenBiblioJobs Eigentlich ein Traum, leider nur knapp 300km von mir entfernt.\nDanke für euren Job bei OpenBiblioJob(s)! :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1039969127484542976"
    }
  },
  {
    "like" : {
      "tweetId" : "1029423891461091328",
      "fullText" : "@OpenBiblioJobs Wird morgen nachgeholt!",
      "expandedUrl" : "https://twitter.com/i/web/status/1029423891461091328"
    }
  },
  {
    "like" : {
      "tweetId" : "1012653678191366147",
      "fullText" : "Really? https://t.co/DNXiXEL2bx",
      "expandedUrl" : "https://twitter.com/i/web/status/1012653678191366147"
    }
  },
  {
    "like" : {
      "tweetId" : "1006549343963402240",
      "fullText" : "Beispiele: o-bib (seit 2014) - eine zentrale Zeitschrift. Unterstützung d zentr. Jobbörse für d Bibwesen @OpenBiblioJobs durch Übernahme Serverkosten, https://t.co/9iTk9HAvEk,  hoher Nutzen für die ges. Community, Anpassungen d Deutschen Bibliothekartages\n#bibtag18 #bibmv18",
      "expandedUrl" : "https://twitter.com/i/web/status/1006549343963402240"
    }
  },
  {
    "like" : {
      "tweetId" : "1006107347759091713",
      "fullText" : "@nafunda Zum einen freue ich mich schon darauf, lauter nette Kolleg*innen wiederzutreffen oder neu kennenzulernen und dann bin ich auf die Gespräche gespannt am Stand der Verbände, wenn ich mit @herr_tu für @OpenBiblioJobs unterwegs bin #bibtag18",
      "expandedUrl" : "https://twitter.com/i/web/status/1006107347759091713"
    }
  },
  {
    "like" : {
      "tweetId" : "1000004277652328450",
      "fullText" : "@OpenBiblioJobs Ich hatte schon darüber nachgedacht, diese Wiki-Seite am Stand der Verbände und/oder dem Forum der LIS-Studiengänge vorzustellen, eben weil wir auch hoffen damit die Kommunikation in der Branche voranzutreiben...",
      "expandedUrl" : "https://twitter.com/i/web/status/1000004277652328450"
    }
  },
  {
    "like" : {
      "tweetId" : "997800658920267776",
      "fullText" : "@OpenBiblioJobs Einfach nur \"Danke\", dass ihr diese Plattform kostenfrei zur Verfügung stellt.",
      "expandedUrl" : "https://twitter.com/i/web/status/997800658920267776"
    }
  },
  {
    "like" : {
      "tweetId" : "996394326535168000",
      "fullText" : "@OpenBiblioJobs  Beim Landesbibliothekszentrum Rheinland-Pfalz (LBZ) ist am Standort Koblenz eine befristete Teilzeitstelle in der Landesstelle Bestandserhaltung zu besetzen. https://t.co/Slpg3WU8DT",
      "expandedUrl" : "https://twitter.com/i/web/status/996394326535168000"
    }
  },
  {
    "like" : {
      "tweetId" : "984522102064779265",
      "fullText" : "Nach &gt; 10 Jahren im Beruf nun einem Berufsverband beigetreten. Die Auswahl fiel nicht schwer: Finanzierung von @OpenBiblioJobs und Herausgabe von #obib als Open Access Fachpublikation macht den #VDB sehr sympathisch!",
      "expandedUrl" : "https://twitter.com/i/web/status/984522102064779265"
    }
  },
  {
    "like" : {
      "tweetId" : "979258236695171072",
      "fullText" : "@bibliothekarin @OpenBiblioJobs #Danke - geb die Info an den Bekannten weiter",
      "expandedUrl" : "https://twitter.com/i/web/status/979258236695171072"
    }
  },
  {
    "like" : {
      "tweetId" : "942048823324618752",
      "fullText" : "Seit einiger Zeit sieht man in den Tweets von @OpenBiblioJobs auch immer den #Arbeitsort. Sehr hilfreich - vielen Dank! https://t.co/4HjzHPbLVT",
      "expandedUrl" : "https://twitter.com/i/web/status/942048823324618752"
    }
  },
  {
    "like" : {
      "tweetId" : "933235159008124929",
      "fullText" : "Und @OpenBiblioJobs ist auch eine tolle Initiative getragen von tollen Leuten. Dort sind die drei Jahre schon eingetragen, bevor wir uns darum kümmern konnten. 🙏 https://t.co/DCvW5loGz3",
      "expandedUrl" : "https://twitter.com/i/web/status/933235159008124929"
    }
  },
  {
    "like" : {
      "tweetId" : "914783056963231744",
      "fullText" : "Das ist eine sinnvolle Verwendung für einen winzigen Teil der Mitgliedsbeiträge, sehr schön. https://t.co/7LlT7QEDgU",
      "expandedUrl" : "https://twitter.com/i/web/status/914783056963231744"
    }
  },
  {
    "like" : {
      "tweetId" : "914779564987076609",
      "fullText" : "@OpenBiblioJobs Danke für die viele Arbeit!",
      "expandedUrl" : "https://twitter.com/i/web/status/914779564987076609"
    }
  },
  {
    "like" : {
      "tweetId" : "907937465784205314",
      "fullText" : "Nutzt ihr @OpenBiblioJobs ? Dann solltet ihr @herr_tu unterstützen, der sich um den Betrieb kümmert und bislang selbst für den Server zahlt.",
      "expandedUrl" : "https://twitter.com/i/web/status/907937465784205314"
    }
  },
  {
    "like" : {
      "tweetId" : "881027023614955525",
      "fullText" : "@OpenBiblioJobs Ein Träumchen!",
      "expandedUrl" : "https://twitter.com/i/web/status/881027023614955525"
    }
  },
  {
    "like" : {
      "tweetId" : "872721054589997057",
      "fullText" : "@openbibliojobs https://t.co/Q5dGs3EJti",
      "expandedUrl" : "https://twitter.com/i/web/status/872721054589997057"
    }
  },
  {
    "like" : {
      "tweetId" : "872129414297001984",
      "fullText" : "@OpenBiblioJobs Leider ist dies ein toter Link, wollte ich nur Bescheid geben :)",
      "expandedUrl" : "https://twitter.com/i/web/status/872129414297001984"
    }
  },
  {
    "like" : {
      "tweetId" : "872138365113696256",
      "fullText" : "@OpenBiblioJobs Alles gut, wollts nur Bescheid geben :)",
      "expandedUrl" : "https://twitter.com/i/web/status/872138365113696256"
    }
  },
  {
    "like" : {
      "tweetId" : "869269145048817664",
      "fullText" : "*entfolgt voller Freude @OpenBiblioJobs",
      "expandedUrl" : "https://twitter.com/i/web/status/869269145048817664"
    }
  },
  {
    "like" : {
      "tweetId" : "868170148452151296",
      "fullText" : ".@o2de 45 Minuten Dauerschleife O2-Hotline sind um. Immer noch nicht dran.  Sollte vielleicht kündigen statt mit O2 umzuziehen. #keinservice",
      "expandedUrl" : "https://twitter.com/i/web/status/868170148452151296"
    }
  },
  {
    "like" : {
      "tweetId" : "856756841606512641",
      "fullText" : "In Magdeburg. Ich kann mir gar nicht vorstellen, wie verzweifelt ich sein müsste, das auch nur in Erwägung zu ziehen. https://t.co/fzvSANNv9c",
      "expandedUrl" : "https://twitter.com/i/web/status/856756841606512641"
    }
  },
  {
    "like" : {
      "tweetId" : "850351922976612352",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/850351922976612352"
    }
  },
  {
    "like" : {
      "tweetId" : "834111394647769088",
      "fullText" : "@OpenBiblioJobs Danke dafür! Eine großartige Sache!",
      "expandedUrl" : "https://twitter.com/i/web/status/834111394647769088"
    }
  },
  {
    "like" : {
      "tweetId" : "803611390732664832",
      "fullText" : "WOW: Knapp 400 Abstracts! Deutlich mehr als in Vorjahren. Jetzt erarbeiten die Gutachter ihre Empfehlung an die Programmkommission #bibtag17",
      "expandedUrl" : "https://twitter.com/i/web/status/803611390732664832"
    }
  },
  {
    "like" : {
      "tweetId" : "827444061309108224",
      "fullText" : "Fast steht dasr #bibtag17-Programm. Heute noch Check: \nParallele Programminhalte?\nReferenten nicht parallel eingeplant?\nAlles Plausibel? https://t.co/9P62hQmur9",
      "expandedUrl" : "https://twitter.com/i/web/status/827444061309108224"
    }
  },
  {
    "like" : {
      "tweetId" : "832644793138163713",
      "fullText" : "Veranstalte mit @cvvfj das Hands on Lab \"Heute baue ich meinen eigenen Artikelindex: Leichtgewichtige \nMetadatenverarbeitung\" #bibtag17 :)",
      "expandedUrl" : "https://twitter.com/i/web/status/832644793138163713"
    }
  },
  {
    "like" : {
      "tweetId" : "832575902361985024",
      "fullText" : "Mein Vortrag beim #bibtag17 wurde angenommen ☺ \"Offsettingverträge - Königsweg oder Road to Ruin?\" 31.05. 13.30-15.30 Uhr. #openaccess",
      "expandedUrl" : "https://twitter.com/i/web/status/832575902361985024"
    }
  },
  {
    "like" : {
      "tweetId" : "832594696304197632",
      "fullText" : "Wie jedes Jahr sind beim #bibtag17 die Vorträge von @mrudolf &amp;mir angenommen worden, die eher okay sind; nicht die, die spannend wären.",
      "expandedUrl" : "https://twitter.com/i/web/status/832594696304197632"
    }
  },
  {
    "like" : {
      "tweetId" : "832562739776253952",
      "fullText" : "Mein Vortrag für den @bibtag17 wurde angenommen *freu* #RDM #FDM #bibtag17",
      "expandedUrl" : "https://twitter.com/i/web/status/832562739776253952"
    }
  },
  {
    "like" : {
      "tweetId" : "825810908073037824",
      "fullText" : "Leiter/in der Stadtbibliothek, E 12 / 13 TVöD, Vollzeit zunächst befristet für 2 Jahre (mit Option auf Entfristung) https://t.co/BBBfRkLBj1",
      "expandedUrl" : "https://twitter.com/i/web/status/825810908073037824"
    }
  },
  {
    "like" : {
      "tweetId" : "823653041261907969",
      "fullText" : "Wenn Gewerkschaften Stellen ausschreiben... https://t.co/MHq7nIzre6",
      "expandedUrl" : "https://twitter.com/i/web/status/823653041261907969"
    }
  },
  {
    "like" : {
      "tweetId" : "809115696265392129",
      "fullText" : "@OpenBiblioJobs Ja.",
      "expandedUrl" : "https://twitter.com/i/web/status/809115696265392129"
    }
  },
  {
    "like" : {
      "tweetId" : "807146027526524929",
      "fullText" : "Cool, die @ubleipzig meldet jetzt auch ihre freien Stellen bei uns. Danke!\n\nWer möchte noch auf diese Liste? https://t.co/DGJezztuAc",
      "expandedUrl" : "https://twitter.com/i/web/status/807146027526524929"
    }
  },
  {
    "like" : {
      "tweetId" : "790454693965201408",
      "fullText" : "@OpenBiblioJobs Mitarbeiter/in Filmbibliothek, EG 9 TV-L, unbefristet in Teilzeit 76,93 % (zz. 30 Std./Wo.) https://t.co/Ruvwb1ULSr /ab",
      "expandedUrl" : "https://twitter.com/i/web/status/790454693965201408"
    }
  },
  {
    "like" : {
      "tweetId" : "790447327983067136",
      "fullText" : "@OpenBiblioJobs tvöd6 für eine Bibl-Stelle? Ein Fall für @_verdi würde ich sagen!",
      "expandedUrl" : "https://twitter.com/i/web/status/790447327983067136"
    }
  },
  {
    "like" : {
      "tweetId" : "783047720533622785",
      "fullText" : "@OpenBiblioJobs thanks :)",
      "expandedUrl" : "https://twitter.com/i/web/status/783047720533622785"
    }
  },
  {
    "like" : {
      "tweetId" : "781763784620724225",
      "fullText" : "@OpenBiblioJobs @fahrenkrog Good job!",
      "expandedUrl" : "https://twitter.com/i/web/status/781763784620724225"
    }
  },
  {
    "like" : {
      "tweetId" : "781763752005734401",
      "fullText" : "@OpenBiblioJobs @fahrenkrog Das war ein RT wert!",
      "expandedUrl" : "https://twitter.com/i/web/status/781763752005734401"
    }
  },
  {
    "like" : {
      "tweetId" : "779376127173361664",
      "fullText" : "It's innacurate to say I \"denounce\" @BASEsearch (or @OpenAIRE_eu). I say that promoting these services on raw numbers overlooks some issues. https://t.co/SacTxnjbcs",
      "expandedUrl" : "https://twitter.com/i/web/status/779376127173361664"
    }
  },
  {
    "like" : {
      "tweetId" : "768125176580046848",
      "fullText" : "Wir suchen Verstärkung im MDR-Medienarchiv in Erfurt! @vfm_online @VdAarchiv @OpenBiblioJobs @FaMI_Portal https://t.co/KHbjrGlEsy",
      "expandedUrl" : "https://twitter.com/i/web/status/768125176580046848"
    }
  },
  {
    "like" : {
      "tweetId" : "753573319308378112",
      "fullText" : "Das war unser 7500. Stellenangebot :) https://t.co/mgASV5Q0Sr",
      "expandedUrl" : "https://twitter.com/i/web/status/753573319308378112"
    }
  },
  {
    "like" : {
      "tweetId" : "757475171854934016",
      "fullText" : "Gratulation! Ich habe ab und zu mal bei Euch reingeschaut, bis ich etwas hatte. Super Sache! https://t.co/JVXKI6imPi",
      "expandedUrl" : "https://twitter.com/i/web/status/757475171854934016"
    }
  },
  {
    "like" : {
      "tweetId" : "751382139736817665",
      "fullText" : "Ein herzliches Dankeschön an die BetreiberInnen von Open Biblio Jobs &amp; an alle, die dort regelmäßig Stellen melden. https://t.co/ctEMXH4NVF",
      "expandedUrl" : "https://twitter.com/i/web/status/751382139736817665"
    }
  },
  {
    "like" : {
      "tweetId" : "747436072754348032",
      "fullText" : "Job gesucht? @OpenBiblioJobs ist DIE Adresse. #bibjobs",
      "expandedUrl" : "https://twitter.com/i/web/status/747436072754348032"
    }
  },
  {
    "like" : {
      "tweetId" : "742993886629498881",
      "fullText" : "Sehe ich auch so! https://t.co/8hxN7TxQlY",
      "expandedUrl" : "https://twitter.com/i/web/status/742993886629498881"
    }
  },
  {
    "like" : {
      "tweetId" : "742994026593406978",
      "fullText" : "@OpenBiblioJobs ich bedanke mich fuer die Stellentweets. Super Sache! Sie haben bestimmt schon vielen geholfen.",
      "expandedUrl" : "https://twitter.com/i/web/status/742994026593406978"
    }
  },
  {
    "like" : {
      "tweetId" : "727029371232464896",
      "fullText" : "@OpenBiblioJobs @bluna81 \"Robuschte\" Gesundheit ist da echt brauchbar. \"Du bist die Härtschte\" sagt mein Kollege immer :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/727029371232464896"
    }
  },
  {
    "like" : {
      "tweetId" : "727028840518791168",
      "fullText" : "@OpenBiblioJobs @bluna81 rechtlich weiss ichs nicht, aber Mensch MUSS im Bücherbus was aushalten können: kalt, heiss, eng, laut, Zeitdruck..",
      "expandedUrl" : "https://twitter.com/i/web/status/727028840518791168"
    }
  },
  {
    "like" : {
      "tweetId" : "727039010552614912",
      "fullText" : "@OpenBiblioJobs @bluna81 Denke das ist Benachteiligung, Verstoß gg. das AGG, siehe https://t.co/2kVTznqKjo https://t.co/KJszIrU7X1",
      "expandedUrl" : "https://twitter.com/i/web/status/727039010552614912"
    }
  },
  {
    "like" : {
      "tweetId" : "723581709330067458",
      "fullText" : "@OpenBiblioJobs E5?? Toller! Job aber hey, wenn Mensch das gut machen soll, doch mehr wert!",
      "expandedUrl" : "https://twitter.com/i/web/status/723581709330067458"
    }
  },
  {
    "like" : {
      "tweetId" : "723432431097782273",
      "fullText" : "#ULBBonn sucht z. nächst. Zeitp. Wiss. Hilfskraft zur Mitarbeit im #FIDRomanistik #Jobs #Stellenblog @OpenBiblioJobs https://t.co/pspDjj9Djb",
      "expandedUrl" : "https://twitter.com/i/web/status/723432431097782273"
    }
  },
  {
    "like" : {
      "tweetId" : "723143135547662336",
      "fullText" : "und wieder gibt es neue Stellenausschreibungen bei uns :)! Nr. 3 #hbz #köln #jobs #bibliothek  https://t.co/in89yacVD2",
      "expandedUrl" : "https://twitter.com/i/web/status/723143135547662336"
    }
  },
  {
    "like" : {
      "tweetId" : "723143040592809984",
      "fullText" : "und wieder gibt es neue Stellenausschreibungen bei uns :)! Nr.2 #hbz #köln #jobs #bibliothek  https://t.co/1c9TtaMI7l",
      "expandedUrl" : "https://twitter.com/i/web/status/723143040592809984"
    }
  },
  {
    "like" : {
      "tweetId" : "723142730436628481",
      "fullText" : "und wieder gibt es neue Stellenausschreibungen bei uns :)! #hbz #köln #jobs #bibliothek  https://t.co/QemiAYKTC8",
      "expandedUrl" : "https://twitter.com/i/web/status/723142730436628481"
    }
  },
  {
    "like" : {
      "tweetId" : "715766693734326272",
      "fullText" : "@OpenBiblioJobs @herr_tu scheint auch mobil down zu sein",
      "expandedUrl" : "https://twitter.com/i/web/status/715766693734326272"
    }
  },
  {
    "like" : {
      "tweetId" : "713029250408955904",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/713029250408955904"
    }
  },
  {
    "like" : {
      "tweetId" : "710437548737347585",
      "fullText" : "Insgesamt sind von #bibtag16 schon 245 Präsentationen auf BIB-OPUS zu finden https://t.co/3Xmk3ZsuzX",
      "expandedUrl" : "https://twitter.com/i/web/status/710437548737347585"
    }
  },
  {
    "like" : {
      "tweetId" : "710496444306890753",
      "fullText" : "Meine Folien vom #bibtag16 - warum WordPress ein Werkzeug für Empowerment von Bibliotheken sein kann: https://t.co/ztZNqmhDu4",
      "expandedUrl" : "https://twitter.com/i/web/status/710496444306890753"
    }
  },
  {
    "like" : {
      "tweetId" : "710553124067479552",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/710553124067479552"
    }
  },
  {
    "like" : {
      "tweetId" : "709780078377439232",
      "fullText" : "@AntjeTheise @xenzen Ansatz im Diskurs eine Service- u. Tätigkeitsmatrix zu bilden u. auf d. Basis umzustrukturieren, scheint zielführend",
      "expandedUrl" : "https://twitter.com/i/web/status/709780078377439232"
    }
  },
  {
    "like" : {
      "tweetId" : "708332429254270976",
      "fullText" : "@herr_tu ... so lange da ist. Am besten du schickst wöchentlich ein @OpenBiblioJobs Update an die Liste, dann muss sich niemand mehr Sorgen.",
      "expandedUrl" : "https://twitter.com/i/web/status/708332429254270976"
    }
  },
  {
    "like" : {
      "tweetId" : "707850387643101184",
      "fullText" : "@herr_tu Der #bibcast von @acka47 zu Lobid https://t.co/fBwGaEcALZ hat fast schon genau für diesen Fall die Antwort geliefert",
      "expandedUrl" : "https://twitter.com/i/web/status/707850387643101184"
    }
  },
  {
    "like" : {
      "tweetId" : "707534678585188352",
      "fullText" : "FYI: \"gemeldet von Leiterin der ...\" ist kein gültige URL ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/707534678585188352"
    }
  },
  {
    "like" : {
      "tweetId" : "704969829544038400",
      "fullText" : "@OpenBiblioJobs @ShishaGraf @StabiHH Ich wollte eigentlich den Nein Doch Ohh Scherz machen. Aber das war wohl zu umständlich.",
      "expandedUrl" : "https://twitter.com/i/web/status/704969829544038400"
    }
  },
  {
    "like" : {
      "tweetId" : "704760011860344834",
      "fullText" : "@OpenBiblioJobs wollte damit nur zum Ausdruck bringen, dass ich die Karte bisher nicht wahrgenommen habe",
      "expandedUrl" : "https://twitter.com/i/web/status/704760011860344834"
    }
  },
  {
    "like" : {
      "tweetId" : "704750372049567746",
      "fullText" : "@OpenBiblioJobs @StabiHH es gibt eine Karte? Tatsache... https://t.co/MXSjBIAf5Q",
      "expandedUrl" : "https://twitter.com/i/web/status/704750372049567746"
    }
  },
  {
    "like" : {
      "tweetId" : "697706888876654592",
      "fullText" : "@OpenBiblioJobs Japs, läuft wieder! Danke! Wow, das nenne ich mal fix *g*",
      "expandedUrl" : "https://twitter.com/i/web/status/697706888876654592"
    }
  },
  {
    "like" : {
      "tweetId" : "695287698219778050",
      "fullText" : "@OpenBiblioJobs Zu dem Angebot ist der Link auf der Website kaputt.",
      "expandedUrl" : "https://twitter.com/i/web/status/695287698219778050"
    }
  },
  {
    "like" : {
      "tweetId" : "694628158352539648",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/694628158352539648"
    }
  },
  {
    "like" : {
      "tweetId" : "694084659160969216",
      "fullText" : "Das sollte dann wohl für eine okkulte Bibliothek sein :-) https://t.co/rmFXEQVpmj",
      "expandedUrl" : "https://twitter.com/i/web/status/694084659160969216"
    }
  },
  {
    "like" : {
      "tweetId" : "694090007938756608",
      "fullText" : "@OpenBiblioJobs Herzlichen Dank für Ihren tollen Service!",
      "expandedUrl" : "https://twitter.com/i/web/status/694090007938756608"
    }
  },
  {
    "like" : {
      "tweetId" : "687572396115640320",
      "fullText" : "#ULBBonn sucht wiss. Mitarbeiter(in) f. #FID #romanistik ab 1.3.16 #jobs @OpenBiblioJobs #digitalhumanities #FDM https://t.co/wGEFa7laxB ^ar",
      "expandedUrl" : "https://twitter.com/i/web/status/687572396115640320"
    }
  },
  {
    "like" : {
      "tweetId" : "677532208089997312",
      "fullText" : "Die #ULBBonn sucht zum nächstmöglichen Termin Verstärkung für die IT-Abteilung #jobs @OpenBiblioJobs #it job https://t.co/YVqq35wfmC ^ar",
      "expandedUrl" : "https://twitter.com/i/web/status/677532208089997312"
    }
  },
  {
    "like" : {
      "tweetId" : "675065998421159937",
      "fullText" : "Es gibt echt viele total spannende Jobs gerade ... https://t.co/zpd1bFraUN",
      "expandedUrl" : "https://twitter.com/i/web/status/675065998421159937"
    }
  },
  {
    "like" : {
      "tweetId" : "670549918453538820",
      "fullText" : "Wiss. Mitarb. (E 13) #DLA in #Marbach via @openbibliojobs bzw #AKI20\nhttps://t.co/8GO4DulGTD",
      "expandedUrl" : "https://twitter.com/i/web/status/670549918453538820"
    }
  },
  {
    "like" : {
      "tweetId" : "669499753810501632",
      "fullText" : "Ich danke allen TeilnehmerInnen an den beiden Webinaren \"Social Media in Bibliotheken\". Insges. 431 Teiln. –Hammer! https://t.co/IXr7BmliFg",
      "expandedUrl" : "https://twitter.com/i/web/status/669499753810501632"
    }
  },
  {
    "like" : {
      "tweetId" : "664794895094280192",
      "fullText" : "@herr_tu @OpenBiblioJobs @tibub Danke, done.",
      "expandedUrl" : "https://twitter.com/i/web/status/664794895094280192"
    }
  },
  {
    "like" : {
      "tweetId" : "661954959353638912",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/661954959353638912"
    }
  },
  {
    "like" : {
      "tweetId" : "656507014416232448",
      "fullText" : "#LibraryThing Launches an iPhone App (An Android app is in the pipeline): https://t.co/9cWjGI2eNy via @inkbitspixels /mt",
      "expandedUrl" : "https://twitter.com/i/web/status/656507014416232448"
    }
  },
  {
    "like" : {
      "tweetId" : "652192213213016064",
      "fullText" : "Na @UltraBiblioteka ? :-) https://t.co/fTgHeJBEeF",
      "expandedUrl" : "https://twitter.com/i/web/status/652192213213016064"
    }
  },
  {
    "like" : {
      "tweetId" : "651101912872407040",
      "fullText" : "@OpenBiblioJobs die haben bestimmt gerade keinen #Tarifvertrag zur Hand…",
      "expandedUrl" : "https://twitter.com/i/web/status/651101912872407040"
    }
  }
]