window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "jobs@openbiblio.eu",
      "createdVia" : "web",
      "username" : "OpenBiblioJobs",
      "accountId" : "633519651",
      "createdAt" : "2012-07-12T03:58:19.000Z",
      "accountDisplayName" : "@obj@openbiblio.social"
    }
  }
]