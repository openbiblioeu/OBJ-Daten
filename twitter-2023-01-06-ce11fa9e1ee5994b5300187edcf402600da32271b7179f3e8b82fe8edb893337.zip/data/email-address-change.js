window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "633519651",
      "emailChange" : {
        "changedAt" : "2012-07-12T03:58:56.000Z",
        "changedTo" : "pascalngocphutu@gmail.com"
      }
    }
  },
  {
    "emailAddressChange" : {
      "accountId" : "633519651",
      "emailChange" : {
        "changedAt" : "2013-07-03T11:45:02.000Z",
        "changedFrom" : "pascalngocphutu@gmail.com",
        "changedTo" : "jobs@openbiblio.eu"
      }
    }
  }
]