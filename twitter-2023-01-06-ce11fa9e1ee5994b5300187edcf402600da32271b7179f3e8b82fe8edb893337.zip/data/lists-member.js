window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/juli_sail/lists/1583177531808780289"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/KanzleiLenz/lists/1547570651778535431"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/insommlisa/lists/1541156306727456773"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JessicaTittel/lists/1478303696584855555"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fine12029651/lists/1398911709293723650"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Eva63407679/lists/bibliothek-12584"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/casareska/lists/biblio"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/heidigloeckchen/lists/jobs"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/anne_knappe/lists/libraries"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fischerdata/lists/bibliothek"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BIBChatDE/lists/bibchatde"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SebastianTetsch/lists/bibliothek"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sophiasprengel/lists/libraries1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DRL_Posts/lists/interesting-january-11-20"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Fairway_Luxemb/lists/fairway-consulting-recrut"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/in4mationninja/lists/open-data"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CodeCnr/lists/java"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/paulthaas/lists/lis-bibliotheken"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/bryhaw/lists/product-managers"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/FabTinti/lists/digitalhumanitieslist"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/book2net/lists/libraries-librarians"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MatteoBalzarini/lists/b2c-marketing-experts"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/IsabelleTannous/lists/biblio"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JanaSolveigh/lists/bibliotheken"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BeeMad4to6/lists/ngo"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DataScientistsF/lists/datascience"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/imensa_de/lists/bibliotheken"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/iheartSAM/lists/museummonday-tweeters"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/bibliothekarin/lists/bibliojobs"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/FrnkZllnr/lists/dh"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LineBee1989/lists/arbeit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/postvonah/lists/jobs"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/postvonah/lists/bibliotheken"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/biblink/lists/jobs"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BibStMarien/lists/verschiedene"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/getwittscher/lists/bibliotheken"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Be_Sle/lists/rund-um-bibliotheken"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MadeHub/lists/sciences-de-l-info"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ubreg/lists/bibliotheken-und-archive"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/librarymistress/lists/librarystuff"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sumomi/lists/knowledgelibraryeducation"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/textundblog/lists/bib"
    }
  }
]