window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter, Inc.",
        "url" : ""
      },
      "name" : "Twitter for Android",
      "description" : "Twitter for Android",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2020-05-01T22:00:20.000Z",
      "id" : "258901"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter",
        "url" : "http://twitter.com"
      },
      "name" : "Mobile Web",
      "description" : "Twitter Mobile Web",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-07-08T07:14:04.000Z",
      "id" : "49152"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Handmark, Inc."
      },
      "name" : "TweetCaster for Android",
      "description" : "TweetCaster is the premier Twitter client for Android devices.",
      "permissions" : [
        "read",
        "write",
        "directmessages"
      ],
      "approvedAt" : "2013-07-08T20:20:20.000Z",
      "id" : "972529"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "",
        "url" : ""
      },
      "name" : "conTEXT NLP analytics",
      "description" : "Allows to semantically analyze text corpora (such as blogs, RSS/Atom feeds, Facebook, G+, Twitter or SlideWiki.org decks) and provides novel ways for browsing and visualizing the results.",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2015-01-31T12:39:13.000Z",
      "id" : "4903454"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "",
        "url" : ""
      },
      "name" : "OpenBiblioJobs",
      "description" : "Stellenangebote von Bibliotheken, Archiven und Informationseinrichtungen",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-07-03T21:13:27.000Z",
      "id" : "4701112"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter, Inc.",
        "url" : ""
      },
      "name" : "Twitter for Android",
      "description" : "Twitter for Android",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-08-18T12:49:23.000Z",
      "id" : "258901"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "TweetDeck"
      },
      "name" : "TweetDeck",
      "description" : "TweetDeck is an app that brings more flexibility and insight to power users.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-07-04T09:39:02.000Z",
      "id" : "55902"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Gratipay, LLC",
        "url" : "https://gratipay.com/"
      },
      "name" : "Gratipay",
      "description" : "Weekly payments, motivated by gratitude",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2013-08-01T10:17:33.000Z",
      "id" : "3213537"
    }
  }
]