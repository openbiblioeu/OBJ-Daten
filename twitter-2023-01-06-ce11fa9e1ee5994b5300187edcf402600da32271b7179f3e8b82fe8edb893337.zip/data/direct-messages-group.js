window.YTD.direct_messages_group.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1215657270597558272",
      "messages" : [
        {
          "participantsLeave" : {
            "userIds" : [
              "3302939757"
            ],
            "createdAt" : "2021-05-15T19:21:17.246Z"
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "BIS ist jetzt Bibliosuisse - bitte folgt @bibliosuisse. Danke!\n\nBIS est maintenant Bibliosuisse - svp suivez @bibliosuisse. Merci!\n\nBIS is now Bibliosuisse - please follow @bibliosuisse. Thank you!\n\nBIS è ora Bibliosuisse - si prega di seguire @bibliosuisse. Grazie!",
            "mediaUrls" : [ ],
            "senderId" : "1580502516",
            "id" : "1215657270597558276",
            "createdAt" : "2020-01-10T15:30:53.879Z"
          }
        },
        {
          "joinConversation" : {
            "initiatingUserId" : "1580502516",
            "participantsSnapshot" : [
              "3542300835",
              "372741401",
              "168427183",
              "404963683",
              "114696892",
              "820381651419152385",
              "3044906956",
              "1693264320",
              "50248046",
              "959530932352020481",
              "3302939757",
              "633519651",
              "1427318442",
              "1000806092698456064",
              "1580502516",
              "876366447290830848",
              "3251300621",
              "986301073",
              "998923789",
              "1271643798",
              "820328418441052163",
              "865127891310391297",
              "160565066",
              "474349509",
              "802615484881444864"
            ],
            "createdAt" : "2020-01-10T15:30:53.876Z"
          }
        }
      ]
    }
  }
]