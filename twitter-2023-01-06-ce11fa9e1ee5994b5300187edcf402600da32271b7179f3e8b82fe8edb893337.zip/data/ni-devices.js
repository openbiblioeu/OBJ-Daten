window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "messagingDevice" : {
        "phoneNumber" : "+491774679533",
        "carrier" : "tmobile_de",
        "deviceType" : "Auth",
        "updatedDate" : "2016.11.03",
        "createdDate" : "2015.06.16"
      }
    }
  }
]