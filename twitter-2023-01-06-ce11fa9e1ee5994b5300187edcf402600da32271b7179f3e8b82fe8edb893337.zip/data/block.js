window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "1491148463974854658",
      "userLink" : "https://twitter.com/intent/user?user_id=1491148463974854658"
    }
  },
  {
    "blocking" : {
      "accountId" : "1490744312920870913",
      "userLink" : "https://twitter.com/intent/user?user_id=1490744312920870913"
    }
  },
  {
    "blocking" : {
      "accountId" : "1457070306036699146",
      "userLink" : "https://twitter.com/intent/user?user_id=1457070306036699146"
    }
  },
  {
    "blocking" : {
      "accountId" : "1391694819500576770",
      "userLink" : "https://twitter.com/intent/user?user_id=1391694819500576770"
    }
  },
  {
    "blocking" : {
      "accountId" : "1213412346544017408",
      "userLink" : "https://twitter.com/intent/user?user_id=1213412346544017408"
    }
  },
  {
    "blocking" : {
      "accountId" : "1188941289540206592",
      "userLink" : "https://twitter.com/intent/user?user_id=1188941289540206592"
    }
  },
  {
    "blocking" : {
      "accountId" : "1129007333433073664",
      "userLink" : "https://twitter.com/intent/user?user_id=1129007333433073664"
    }
  },
  {
    "blocking" : {
      "accountId" : "867176916205350913",
      "userLink" : "https://twitter.com/intent/user?user_id=867176916205350913"
    }
  },
  {
    "blocking" : {
      "accountId" : "866184899195269120",
      "userLink" : "https://twitter.com/intent/user?user_id=866184899195269120"
    }
  },
  {
    "blocking" : {
      "accountId" : "865610327504846849",
      "userLink" : "https://twitter.com/intent/user?user_id=865610327504846849"
    }
  },
  {
    "blocking" : {
      "accountId" : "863416741715615744",
      "userLink" : "https://twitter.com/intent/user?user_id=863416741715615744"
    }
  },
  {
    "blocking" : {
      "accountId" : "858060287580053504",
      "userLink" : "https://twitter.com/intent/user?user_id=858060287580053504"
    }
  },
  {
    "blocking" : {
      "accountId" : "854699079150055424",
      "userLink" : "https://twitter.com/intent/user?user_id=854699079150055424"
    }
  },
  {
    "blocking" : {
      "accountId" : "777847612993048576",
      "userLink" : "https://twitter.com/intent/user?user_id=777847612993048576"
    }
  },
  {
    "blocking" : {
      "accountId" : "724211954651389954",
      "userLink" : "https://twitter.com/intent/user?user_id=724211954651389954"
    }
  },
  {
    "blocking" : {
      "accountId" : "4847083041",
      "userLink" : "https://twitter.com/intent/user?user_id=4847083041"
    }
  },
  {
    "blocking" : {
      "accountId" : "4846437279",
      "userLink" : "https://twitter.com/intent/user?user_id=4846437279"
    }
  },
  {
    "blocking" : {
      "accountId" : "3397462513",
      "userLink" : "https://twitter.com/intent/user?user_id=3397462513"
    }
  },
  {
    "blocking" : {
      "accountId" : "3377899877",
      "userLink" : "https://twitter.com/intent/user?user_id=3377899877"
    }
  },
  {
    "blocking" : {
      "accountId" : "3305508100",
      "userLink" : "https://twitter.com/intent/user?user_id=3305508100"
    }
  },
  {
    "blocking" : {
      "accountId" : "3184665644",
      "userLink" : "https://twitter.com/intent/user?user_id=3184665644"
    }
  },
  {
    "blocking" : {
      "accountId" : "3119199190",
      "userLink" : "https://twitter.com/intent/user?user_id=3119199190"
    }
  },
  {
    "blocking" : {
      "accountId" : "3048933599",
      "userLink" : "https://twitter.com/intent/user?user_id=3048933599"
    }
  },
  {
    "blocking" : {
      "accountId" : "3021529941",
      "userLink" : "https://twitter.com/intent/user?user_id=3021529941"
    }
  },
  {
    "blocking" : {
      "accountId" : "2976294275",
      "userLink" : "https://twitter.com/intent/user?user_id=2976294275"
    }
  },
  {
    "blocking" : {
      "accountId" : "2839456079",
      "userLink" : "https://twitter.com/intent/user?user_id=2839456079"
    }
  },
  {
    "blocking" : {
      "accountId" : "2805200886",
      "userLink" : "https://twitter.com/intent/user?user_id=2805200886"
    }
  },
  {
    "blocking" : {
      "accountId" : "2722310510",
      "userLink" : "https://twitter.com/intent/user?user_id=2722310510"
    }
  },
  {
    "blocking" : {
      "accountId" : "2522431765",
      "userLink" : "https://twitter.com/intent/user?user_id=2522431765"
    }
  },
  {
    "blocking" : {
      "accountId" : "2520187459",
      "userLink" : "https://twitter.com/intent/user?user_id=2520187459"
    }
  },
  {
    "blocking" : {
      "accountId" : "2414947212",
      "userLink" : "https://twitter.com/intent/user?user_id=2414947212"
    }
  },
  {
    "blocking" : {
      "accountId" : "2398575522",
      "userLink" : "https://twitter.com/intent/user?user_id=2398575522"
    }
  },
  {
    "blocking" : {
      "accountId" : "1960934269",
      "userLink" : "https://twitter.com/intent/user?user_id=1960934269"
    }
  },
  {
    "blocking" : {
      "accountId" : "1933026984",
      "userLink" : "https://twitter.com/intent/user?user_id=1933026984"
    }
  },
  {
    "blocking" : {
      "accountId" : "1854593587",
      "userLink" : "https://twitter.com/intent/user?user_id=1854593587"
    }
  },
  {
    "blocking" : {
      "accountId" : "1710447798",
      "userLink" : "https://twitter.com/intent/user?user_id=1710447798"
    }
  },
  {
    "blocking" : {
      "accountId" : "1431239750",
      "userLink" : "https://twitter.com/intent/user?user_id=1431239750"
    }
  },
  {
    "blocking" : {
      "accountId" : "1168562983",
      "userLink" : "https://twitter.com/intent/user?user_id=1168562983"
    }
  },
  {
    "blocking" : {
      "accountId" : "1125302569",
      "userLink" : "https://twitter.com/intent/user?user_id=1125302569"
    }
  },
  {
    "blocking" : {
      "accountId" : "1062763200",
      "userLink" : "https://twitter.com/intent/user?user_id=1062763200"
    }
  },
  {
    "blocking" : {
      "accountId" : "797867197",
      "userLink" : "https://twitter.com/intent/user?user_id=797867197"
    }
  },
  {
    "blocking" : {
      "accountId" : "597282815",
      "userLink" : "https://twitter.com/intent/user?user_id=597282815"
    }
  },
  {
    "blocking" : {
      "accountId" : "544972463",
      "userLink" : "https://twitter.com/intent/user?user_id=544972463"
    }
  },
  {
    "blocking" : {
      "accountId" : "492498691",
      "userLink" : "https://twitter.com/intent/user?user_id=492498691"
    }
  },
  {
    "blocking" : {
      "accountId" : "460143393",
      "userLink" : "https://twitter.com/intent/user?user_id=460143393"
    }
  },
  {
    "blocking" : {
      "accountId" : "450055621",
      "userLink" : "https://twitter.com/intent/user?user_id=450055621"
    }
  },
  {
    "blocking" : {
      "accountId" : "439388430",
      "userLink" : "https://twitter.com/intent/user?user_id=439388430"
    }
  },
  {
    "blocking" : {
      "accountId" : "437248388",
      "userLink" : "https://twitter.com/intent/user?user_id=437248388"
    }
  },
  {
    "blocking" : {
      "accountId" : "433114529",
      "userLink" : "https://twitter.com/intent/user?user_id=433114529"
    }
  },
  {
    "blocking" : {
      "accountId" : "384950134",
      "userLink" : "https://twitter.com/intent/user?user_id=384950134"
    }
  },
  {
    "blocking" : {
      "accountId" : "380862364",
      "userLink" : "https://twitter.com/intent/user?user_id=380862364"
    }
  },
  {
    "blocking" : {
      "accountId" : "376027242",
      "userLink" : "https://twitter.com/intent/user?user_id=376027242"
    }
  },
  {
    "blocking" : {
      "accountId" : "350075403",
      "userLink" : "https://twitter.com/intent/user?user_id=350075403"
    }
  },
  {
    "blocking" : {
      "accountId" : "259258282",
      "userLink" : "https://twitter.com/intent/user?user_id=259258282"
    }
  },
  {
    "blocking" : {
      "accountId" : "254471522",
      "userLink" : "https://twitter.com/intent/user?user_id=254471522"
    }
  },
  {
    "blocking" : {
      "accountId" : "245455890",
      "userLink" : "https://twitter.com/intent/user?user_id=245455890"
    }
  },
  {
    "blocking" : {
      "accountId" : "229838023",
      "userLink" : "https://twitter.com/intent/user?user_id=229838023"
    }
  },
  {
    "blocking" : {
      "accountId" : "228462983",
      "userLink" : "https://twitter.com/intent/user?user_id=228462983"
    }
  },
  {
    "blocking" : {
      "accountId" : "224501100",
      "userLink" : "https://twitter.com/intent/user?user_id=224501100"
    }
  },
  {
    "blocking" : {
      "accountId" : "168355110",
      "userLink" : "https://twitter.com/intent/user?user_id=168355110"
    }
  },
  {
    "blocking" : {
      "accountId" : "161702444",
      "userLink" : "https://twitter.com/intent/user?user_id=161702444"
    }
  },
  {
    "blocking" : {
      "accountId" : "119480392",
      "userLink" : "https://twitter.com/intent/user?user_id=119480392"
    }
  },
  {
    "blocking" : {
      "accountId" : "119246453",
      "userLink" : "https://twitter.com/intent/user?user_id=119246453"
    }
  },
  {
    "blocking" : {
      "accountId" : "92470054",
      "userLink" : "https://twitter.com/intent/user?user_id=92470054"
    }
  },
  {
    "blocking" : {
      "accountId" : "86479973",
      "userLink" : "https://twitter.com/intent/user?user_id=86479973"
    }
  },
  {
    "blocking" : {
      "accountId" : "81346386",
      "userLink" : "https://twitter.com/intent/user?user_id=81346386"
    }
  },
  {
    "blocking" : {
      "accountId" : "49590329",
      "userLink" : "https://twitter.com/intent/user?user_id=49590329"
    }
  },
  {
    "blocking" : {
      "accountId" : "29689820",
      "userLink" : "https://twitter.com/intent/user?user_id=29689820"
    }
  },
  {
    "blocking" : {
      "accountId" : "14418014",
      "userLink" : "https://twitter.com/intent/user?user_id=14418014"
    }
  },
  {
    "blocking" : {
      "accountId" : "12376612",
      "userLink" : "https://twitter.com/intent/user?user_id=12376612"
    }
  }
]