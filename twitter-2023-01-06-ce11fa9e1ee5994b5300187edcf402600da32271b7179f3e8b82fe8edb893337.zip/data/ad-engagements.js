window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91436",
                  "name" : "#Siemens175",
                  "description" : "Im Wandel die Zukunft gestalten."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Siemens",
                  "screenName" : "@Siemens"
                },
                "impressionTime" : "2022-10-12 11:22:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-12 11:22:58",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1571771076077551616",
                  "tweetText" : "Jedes Vermögen hat eine einzigartige Geschichte. Der erfolgreiche Unternehmer Jacob Fatih begleitet heute Gründer zum Erfolg. In Vermögensfragen begleiten wir ihn – mit Lösungen nach Maß.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Commerzbank",
                  "screenName" : "@commerzbank"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@handelsblatt"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@wef"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@business"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@wiwo"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@TheEconomist"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@FAZ_Wirtschaft"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@WorldBank"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "35 to 54"
                  }
                ],
                "impressionTime" : "2022-10-18 10:27:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-10-18 10:27:27",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2022-10-18 10:27:34",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2022-10-18 10:27:29",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-10-18 10:27:32",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2022-10-18 10:27:34",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2022-10-18 10:27:29",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-10-18 10:27:33",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2022-10-18 10:27:34",
                  "engagementType" : "VideoContentPlayback95"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92733",
                  "name" : "#ForniteWinterfest",
                  "description" : "❄️Packe bis zum 3. Januar kostenlose Geschenke im Spiel aus!❄️"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fortnite",
                  "screenName" : "@FortniteGame"
                },
                "impressionTime" : "2022-12-17 13:05:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-17 13:05:59",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1601196181559836673",
                  "tweetText" : "NEOM’s Media Village is home to industry standard, purpose-built production facilities unlike any in the region.🌐 With the most generous cash rebates we provide a seamless production experience. 🎥\n\n#NEOM",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "NEOM",
                  "screenName" : "@NEOM"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#Amc"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-12-17 13:05:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-17 13:06:38",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:35",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:37",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:47",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:33",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1595101936969302016",
                  "tweetText" : "Jede klimafreundliche Entscheidung zählt: ob auf @googlemaps mit spritsparenden Routen Kraftstoff, Energie &amp; Geld sparen, Fahrräder leihen, oder in der Google Suche Emissionen für Züge und Flüge vergleichen. Mehr Tipps unter https://t.co/R6aRGRlLDK. #Klimaschutz https://t.co/bwag8LI99u",
                  "urls" : [
                    "https://t.co/R6aRGRlLDK"
                  ],
                  "mediaUrls" : [
                    "https://t.co/bwag8LI99u"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Google Deutschland",
                  "screenName" : "@GoogleDE"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Sustainability"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Umgebung"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Nachhaltigkeit"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "German"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  }
                ],
                "impressionTime" : "2022-12-17 13:05:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-17 13:06:30",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:32",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:41",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:28",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:32",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:27",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:30",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1602621603803709447",
                  "tweetText" : "Wenn du eine Maus besitzt wirst du nie wieder deinen PC ausschalten.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "DITOGAMES",
                  "screenName" : "@DITOGAMESch"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "35 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "German"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2022-12-17 13:06:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-17 13:06:53",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:52",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:51",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:51",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-12-17 13:06:51",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1603748020280909825",
                  "tweetText" : "ULTIMATIVER KÖNIGLICHER SCHLITZER. KOSTENLOSE TESTPHASE 16.-22. DEZEMBER. #NARAKA",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "NARAKA: BLADEPOINT",
                  "screenName" : "@NARAKATHEGAME"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "cd projekt red"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Tabletop gaming"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "PC gaming"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "German"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-12-17 13:05:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-17 13:06:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92830",
                  "name" : "#SaturnMeinachten",
                  "description" : "Top-Technik im Bundle sichern!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "SATURN Deutschland",
                  "screenName" : "@SaturnDE"
                },
                "impressionTime" : "2022-12-18 22:43:26"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-18 22:43:27",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92830",
                  "name" : "#SaturnMeinachten",
                  "description" : "Top-Technik im Bundle sichern!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "SATURN Deutschland",
                  "screenName" : "@SaturnDE"
                },
                "impressionTime" : "2022-12-18 13:48:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-18 13:48:15",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1604505960378163201",
                  "tweetText" : "Leo Messi, Weltmeister. #ImpossibleIsNothing https://t.co/HDo2v1eJ63",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/HDo2v1eJ63"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "adidas Football",
                  "screenName" : "@adidasfootball"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2022-12-19 07:19:03"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-19 07:19:35",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1578045460035641345",
                  "tweetText" : "Monströse Aromen, rauchiger Biss: das ist Ardbeg Wee Beastie! Entdecke unsere rauchigen 'Planet Ardbeg' Stories auf https://t.co/igGZ0RTCPy #MassvollGeniessen \nBitte teile unsere Inhalte nur mit Personen ab 18 Jahren.",
                  "urls" : [
                    "https://t.co/igGZ0RTCPy"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ardbeg",
                  "screenName" : "@Ardbeg"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-11-01 14:54:41"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-01 14:55:39",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2022-11-01 14:55:29",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-11-01 14:55:40",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2022-11-01 14:55:32",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2022-11-01 14:55:28",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-11-01 14:55:40",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2022-11-01 14:55:53",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2022-11-01 14:55:36",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2022-11-01 14:55:26",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-11-01 14:54:44",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1575205658663829517",
                  "tweetText" : "Smart Trainer-Alarm🚨Hier kommt der #ZwiftHub. Nur 499 € und in wenigen Minuten fahrbereit. Das musst man gesehen haben 👀",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zwift",
                  "screenName" : "@GoZwift"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Cyclisme : Tour d'Italie 2017"
                  },
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "German"
                  }
                ],
                "impressionTime" : "2022-11-01 14:56:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-01 14:57:00",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-11-01 14:57:11",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2022-11-01 14:57:14",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2022-11-01 14:57:00",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2022-11-01 14:57:15",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2022-11-01 14:57:07",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2022-11-01 14:57:15",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2022-11-01 14:57:03",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1581948141695209472",
                  "tweetText" : "Wir glauben jedes Lächeln erzählt eine Geschichte. Mit atemberaubenden Filmen, unvergesslichen Original-Serien und exklusiven Sportsendungen gibt es auf Prime Video RICHTIG VIELE gute Gründe zu lächeln. https://t.co/1RT3AMhpFr",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/1RT3AMhpFr"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video DE",
                  "screenName" : "@PrimeVideoDE"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "appleTV"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@NetflixDE"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  }
                ],
                "impressionTime" : "2022-11-01 15:02:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-01 15:02:19",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1578045460035641345",
                  "tweetText" : "Monströse Aromen, rauchiger Biss: das ist Ardbeg Wee Beastie! Entdecke unsere rauchigen 'Planet Ardbeg' Stories auf https://t.co/igGZ0RTCPy #MassvollGeniessen \nBitte teile unsere Inhalte nur mit Personen ab 18 Jahren.",
                  "urls" : [
                    "https://t.co/igGZ0RTCPy"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ardbeg",
                  "screenName" : "@Ardbeg"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  }
                ],
                "impressionTime" : "2022-11-01 15:00:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-01 15:00:49",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1588473003981127680",
                  "tweetText" : "Begib dich auf eine epische und emotionale Reise in God of War Ragnarök. Jetzt exklusiv für #PS4 und #PS5 erhältlich.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "92010",
                  "name" : "#GodofWarRagnarok",
                  "description" : "Jetzt exklusiv für PS4 und PS5"
                },
                "advertiserInfo" : {
                  "advertiserName" : "PlayStationDE",
                  "screenName" : "@PlayStationDE"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-11-09 16:03:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-09 16:03:30",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-11-09 16:03:30",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-11-09 16:03:28",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-11-09 16:03:31",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2022-11-09 16:03:32",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2022-11-09 16:03:35",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2022-11-09 16:03:51",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1589256601726341121",
                  "tweetText" : "💪 #Hochschulen und #Forschung werden von der Bundesregierung in der Energiekrise mit zwei Milliarden Euro entlastet. https://t.co/WawbMonlO0",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/WawbMonlO0"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "BMBF",
                  "screenName" : "@BMBF_Bund"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@BMBF_Bund"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "German"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2022-11-09 16:00:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-09 16:01:04",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1585288201052332033",
                  "tweetText" : "Das Alles gibt es für nur 8,99€ pro Monat- ganz ohne versteckte Kosten.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+ DE",
                  "screenName" : "@DisneyPlusDE"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "entertainment"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-11-09 16:03:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-09 16:04:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1575205658663829517",
                  "tweetText" : "Smart Trainer-Alarm🚨Hier kommt der #ZwiftHub. Nur 499 € und in wenigen Minuten fahrbereit. Das musst man gesehen haben 👀",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zwift",
                  "screenName" : "@GoZwift"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Cyclisme : Tour d'Italie 2017"
                  },
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "German"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-11-09 16:03:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-09 16:03:53",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-11-09 16:03:51",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2022-11-09 16:03:59",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-11-09 16:03:52",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92010",
                  "name" : "#GodofWarRagnarok",
                  "description" : "Jetzt exklusiv für PS4 und PS5"
                },
                "advertiserInfo" : {
                  "advertiserName" : "PlayStationDE",
                  "screenName" : "@PlayStationDE"
                },
                "impressionTime" : "2022-11-09 16:00:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-09 16:00:49",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1578045460035641345",
                  "tweetText" : "Monströse Aromen, rauchiger Biss: das ist Ardbeg Wee Beastie! Entdecke unsere rauchigen 'Planet Ardbeg' Stories auf https://t.co/igGZ0RTCPy #MassvollGeniessen \nBitte teile unsere Inhalte nur mit Personen ab 18 Jahren.",
                  "urls" : [
                    "https://t.co/igGZ0RTCPy"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ardbeg",
                  "screenName" : "@Ardbeg"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  }
                ],
                "impressionTime" : "2022-11-11 08:41:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-11 08:41:40",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-11-11 08:41:38",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-11-11 08:41:42",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-11-11 08:41:41",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-11-11 08:41:37",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1587129072013950976",
                  "tweetText" : "Egal, ob du beruflich aufsteigen möchtest oder nach der Arbeit an deinem eigenen Lieblingsprojekt arbeitest – Windows 11 Laptops haben das, was du brauchst, um dieses Ziel zu erreichen. Schnelle Performance, Produktivitäts-Tools und natürlich erweiterte Sicherheit.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Microsoft Germany",
                  "screenName" : "@MicrosoftDE"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Windows"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-11-17 15:46:03"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-17 15:46:05",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1592862995079634950",
                  "tweetText" : "Bei ntv erfahren Sie alles rund um die Energiekrise",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ntv Nachrichten",
                  "screenName" : "@ntvde"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@spiegelonline"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@tagesschau"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@faznet"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@morgenpost"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@DIEZEIT"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@ZDF"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@ZDFheute"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@zeitonline_pol"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@zeitonline"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@SZ"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-11-19 09:44:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 09:50:17",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1588182712304664576",
                  "tweetText" : "Discover Noor Riyadh activities and artworks and book your tickets on our official website https://t.co/iBs3GfrIcf #NoorRiaydh #WeDreamofNewHorizons",
                  "urls" : [
                    "https://t.co/iBs3GfrIcf"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "نور الرياض",
                  "screenName" : "@NoorRiyadhFest"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  }
                ],
                "impressionTime" : "2022-11-19 09:44:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 09:46:40",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2022-11-19 09:46:33",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-11-19 09:46:36",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-11-19 09:46:40",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2022-11-19 09:46:20",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2022-11-19 09:47:58",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-11-19 09:46:35",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91212",
                  "name" : "#BlackWeeks",
                  "description" : "iPhone 14 bei Vodafone"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Vodafone Deutschland",
                  "screenName" : "@vodafone_de"
                },
                "impressionTime" : "2022-11-21 07:05:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-21 07:05:52",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91212",
                  "name" : "#BlackWeeks",
                  "description" : "iPhone 14 bei Vodafone"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Vodafone Deutschland",
                  "screenName" : "@vodafone_de"
                },
                "impressionTime" : "2022-11-21 07:33:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-21 07:33:22",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "91212",
                  "name" : "#BlackWeeks",
                  "description" : "iPhone 14 bei Vodafone"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Vodafone Deutschland",
                  "screenName" : "@vodafone_de"
                },
                "impressionTime" : "2022-11-21 07:28:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-21 07:28:08",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1588188314753851393",
                  "tweetText" : "Netflix gibt es jetzt schon ab 4,99 € pro Monat – mit dem neuen günstigeren Basis-Abo mit Werbung. https://t.co/Qx8Jg2ULO2",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/Qx8Jg2ULO2"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "netflixde",
                  "screenName" : "@NetflixDE"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "Movie - Black Widow"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Entertainment"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Disney+"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Netflix"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Disney"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@mubi"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#AppleTV"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "A&E"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "SUPERAUDIENCE - Marketing & Advertising professionals - Germany - 11-2022"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-11-30 11:47:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-30 11:47:22",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-11-30 11:47:21",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-11-30 11:47:20",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-11-30 11:47:19",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-11-30 11:47:18",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1584921761304420352",
                  "tweetText" : "Du möchtest Impact Investor:in werden? wiLLBe bietet dir die Chance – einfach, sicher und nachhaltig.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "wiLLBe",
                  "screenName" : "@willbe_invest"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Portfolio Manager"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "bildung"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@nytimes"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@NaturePortfolio"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@Nature"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@TheEconomist"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "German"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  }
                ],
                "impressionTime" : "2022-11-30 11:47:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-30 11:47:24",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-11-30 11:47:23",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1596180958415306757",
                  "tweetText" : "Die neue Original Serie #Willow nur auf Disney+ streamen.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "92537",
                  "name" : "#WillowSerie",
                  "description" : "Willow auf Disney+ streamen"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+ DE",
                  "screenName" : "@DisneyPlusDE"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2022-11-30 11:33:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-30 11:33:46",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-11-30 11:33:57",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2022-11-30 11:33:49",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-11-30 11:33:49",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-11-30 11:47:07",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-11-30 11:47:09",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-11-30 11:33:53",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2022-11-30 11:47:08",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-11-30 11:33:53",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2022-11-30 11:33:58",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92537",
                  "name" : "#WillowSerie",
                  "description" : "Willow auf Disney+ streamen"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+ DE",
                  "screenName" : "@DisneyPlusDE"
                },
                "impressionTime" : "2022-11-30 11:33:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-30 11:33:44",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92537",
                  "name" : "#WillowSerie",
                  "description" : "Willow auf Disney+ streamen"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+ DE",
                  "screenName" : "@DisneyPlusDE"
                },
                "impressionTime" : "2022-11-30 11:47:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-30 11:47:17",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1602627391775379456",
                  "tweetText" : "Wenn du eine Maus hast wirst du nie wieder deinen Computer ausschalten.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "DITOGAMES",
                  "screenName" : "@DITOGAMESch"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "German"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "35 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  }
                ],
                "impressionTime" : "2022-12-17 09:17:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-17 09:18:05",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:01",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:20",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:03",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:05",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:08",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:07",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:01",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:09",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:03",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:03",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:05",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:09",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2022-12-17 09:18:07",
                  "engagementType" : "VideoContentPlayback75"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92733",
                  "name" : "#ForniteWinterfest",
                  "description" : "❄️Packe bis zum 3. Januar kostenlose Geschenke im Spiel aus!❄️"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fortnite",
                  "screenName" : "@FortniteGame"
                },
                "impressionTime" : "2022-12-17 09:17:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-12-17 09:18:00",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  }
]