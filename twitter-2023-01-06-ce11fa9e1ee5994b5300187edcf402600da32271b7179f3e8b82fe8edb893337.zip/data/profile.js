window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "Stellenangebote von Bibliotheken, Archiven und Informationseinrichtungen. Follow us on Mastodon 👉 https://t.co/30vAzkDwKV",
        "website" : "https://t.co/BNeNYjude4",
        "location" : "Germany"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/698235575636254720/hJOqNtC6.jpg"
    }
  }
]