window.YTD.deleted_tweet_headers.part0 = [
  {
    "tweet" : {
      "tweet_id" : "1472979322348744706",
      "user_id" : "633519651",
      "created_at" : "Mon Dec 20 17:16:51 +0000 2021",
      "deleted_at" : "Sun Dec 25 14:55:10 +0000 2022"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1361294083524874241",
      "user_id" : "633519651",
      "created_at" : "Mon Feb 15 12:39:35 +0000 2021",
      "deleted_at" : "Sun Dec 25 14:57:30 +0000 2022"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1603742830391951360",
      "user_id" : "633519651",
      "created_at" : "Fri Dec 16 13:24:21 +0000 2022",
      "deleted_at" : "Mon Dec 26 19:53:40 +0000 2022"
    }
  }
]