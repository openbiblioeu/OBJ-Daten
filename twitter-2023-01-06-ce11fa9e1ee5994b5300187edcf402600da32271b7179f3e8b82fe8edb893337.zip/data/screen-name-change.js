window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "633519651",
      "screenNameChange" : {
        "changedAt" : "2013-07-03T11:37:42.000Z",
        "changedFrom" : "openbibliojobs",
        "changedTo" : "OpenBiblioJobs"
      }
    }
  }
]