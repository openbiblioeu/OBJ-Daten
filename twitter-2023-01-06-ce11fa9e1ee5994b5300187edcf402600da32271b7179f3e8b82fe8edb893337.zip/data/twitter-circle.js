window.YTD.twitter_circle.part0 = [
  {
    "twitterCircle" : {
      "id" : "1577410817993097218",
      "ownerUserId" : "633519651",
      "createdAt" : "2022-10-04T21:30:20.543Z"
    }
  }
]