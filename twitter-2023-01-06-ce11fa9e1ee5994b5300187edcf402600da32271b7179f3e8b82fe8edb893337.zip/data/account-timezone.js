window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "633519651",
      "timeZone" : "Europe/Berlin"
    }
  }
]