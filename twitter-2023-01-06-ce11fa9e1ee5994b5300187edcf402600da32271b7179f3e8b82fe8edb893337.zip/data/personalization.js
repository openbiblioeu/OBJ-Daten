window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "German",
            "isDisabled" : false
          },
          {
            "language" : "No linguistic content",
            "isDisabled" : false
          },
          {
            "language" : "Norwegian",
            "isDisabled" : false
          },
          {
            "language" : "French",
            "isDisabled" : false
          },
          {
            "language" : "Estonian",
            "isDisabled" : false
          },
          {
            "language" : "English",
            "isDisabled" : false
          },
          {
            "language" : "Romanian",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Agriculture",
            "isDisabled" : false
          },
          {
            "name" : "Amazon",
            "isDisabled" : false
          },
          {
            "name" : "American football",
            "isDisabled" : false
          },
          {
            "name" : "Angela Merkel",
            "isDisabled" : false
          },
          {
            "name" : "Animation",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Apple - iOS",
            "isDisabled" : false
          },
          {
            "name" : "Apple iPad",
            "isDisabled" : false
          },
          {
            "name" : "Art",
            "isDisabled" : false
          },
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Arts & culture",
            "isDisabled" : false
          },
          {
            "name" : "Augmented reality",
            "isDisabled" : false
          },
          {
            "name" : "Authors",
            "isDisabled" : false
          },
          {
            "name" : "Automobile Brands",
            "isDisabled" : false
          },
          {
            "name" : "Automotive",
            "isDisabled" : false
          },
          {
            "name" : "B2B",
            "isDisabled" : false
          },
          {
            "name" : "Baltimore Orioles",
            "isDisabled" : false
          },
          {
            "name" : "Baseball",
            "isDisabled" : false
          },
          {
            "name" : "Biology",
            "isDisabled" : false
          },
          {
            "name" : "Black Lives Matter",
            "isDisabled" : false
          },
          {
            "name" : "Blogging",
            "isDisabled" : false
          },
          {
            "name" : "Books",
            "isDisabled" : false
          },
          {
            "name" : "Brad Parscale",
            "isDisabled" : false
          },
          {
            "name" : "Bundesliga Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Bundesliga Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Burgers",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "Business professions",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "Cartoons",
            "isDisabled" : false
          },
          {
            "name" : "Christian Saydee",
            "isDisabled" : false
          },
          {
            "name" : "Classical music",
            "isDisabled" : false
          },
          {
            "name" : "Coffee",
            "isDisabled" : false
          },
          {
            "name" : "College life",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Comics",
            "isDisabled" : false
          },
          {
            "name" : "Common Medication",
            "isDisabled" : false
          },
          {
            "name" : "Computer gaming",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Consulting",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Cybersecurity",
            "isDisabled" : false
          },
          {
            "name" : "Dan Newhouse",
            "isDisabled" : false
          },
          {
            "name" : "Data science",
            "isDisabled" : false
          },
          {
            "name" : "DevOps",
            "isDisabled" : false
          },
          {
            "name" : "Digital nomads",
            "isDisabled" : false
          },
          {
            "name" : "Disney",
            "isDisabled" : false
          },
          {
            "name" : "Dogs",
            "isDisabled" : false
          },
          {
            "name" : "Donald Trump",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "E-books",
            "isDisabled" : false
          },
          {
            "name" : "ESPN",
            "isDisabled" : false
          },
          {
            "name" : "Education",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment industry",
            "isDisabled" : false
          },
          {
            "name" : "Esports",
            "isDisabled" : false
          },
          {
            "name" : "Ethereum cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Facebook",
            "isDisabled" : false
          },
          {
            "name" : "Family & relationships",
            "isDisabled" : false
          },
          {
            "name" : "Fashion",
            "isDisabled" : false
          },
          {
            "name" : "Fashion & beauty",
            "isDisabled" : false
          },
          {
            "name" : "Fashion Tags",
            "isDisabled" : false
          },
          {
            "name" : "Fields of study",
            "isDisabled" : false
          },
          {
            "name" : "Food",
            "isDisabled" : false
          },
          {
            "name" : "GPS and maps",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "George Floyd",
            "isDisabled" : false
          },
          {
            "name" : "George Floyd protests",
            "isDisabled" : false
          },
          {
            "name" : "George H. W. Bush",
            "isDisabled" : false
          },
          {
            "name" : "German Bundestag",
            "isDisabled" : false
          },
          {
            "name" : "GitHub",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "Graduate school",
            "isDisabled" : false
          },
          {
            "name" : "Graphic design",
            "isDisabled" : false
          },
          {
            "name" : "Harry Potter",
            "isDisabled" : false
          },
          {
            "name" : "History",
            "isDisabled" : false
          },
          {
            "name" : "Ice cream",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "Instagram",
            "isDisabled" : false
          },
          {
            "name" : "JK Rowling",
            "isDisabled" : false
          },
          {
            "name" : "Jan Bohmermann",
            "isDisabled" : false
          },
          {
            "name" : "Job searching & networking",
            "isDisabled" : false
          },
          {
            "name" : "Journalists",
            "isDisabled" : false
          },
          {
            "name" : "KBS",
            "isDisabled" : false
          },
          {
            "name" : "Libraries",
            "isDisabled" : false
          },
          {
            "name" : "Linux",
            "isDisabled" : false
          },
          {
            "name" : "Lunch",
            "isDisabled" : false
          },
          {
            "name" : "MLB Baseball",
            "isDisabled" : false
          },
          {
            "name" : "MLB Baseball",
            "isDisabled" : false
          },
          {
            "name" : "Machine learning",
            "isDisabled" : false
          },
          {
            "name" : "Marburg Virus",
            "isDisabled" : false
          },
          {
            "name" : "Marketing",
            "isDisabled" : false
          },
          {
            "name" : "Marvel Universe",
            "isDisabled" : false
          },
          {
            "name" : "Mathematics",
            "isDisabled" : false
          },
          {
            "name" : "Mohmmad Assagheer (محمد الصغير)",
            "isDisabled" : false
          },
          {
            "name" : "Movies & TV",
            "isDisabled" : false
          },
          {
            "name" : "Museums",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music festivals and concerts",
            "isDisabled" : false
          },
          {
            "name" : "NBC News",
            "isDisabled" : false
          },
          {
            "name" : "NFL players",
            "isDisabled" : false
          },
          {
            "name" : "NPR",
            "isDisabled" : false
          },
          {
            "name" : "Netflix",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Odell Beckham Jr",
            "isDisabled" : false
          },
          {
            "name" : "Online education",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "Outdoors",
            "isDisabled" : false
          },
          {
            "name" : "PAW Patrol",
            "isDisabled" : false
          },
          {
            "name" : "Pasta",
            "isDisabled" : false
          },
          {
            "name" : "Patti Smith",
            "isDisabled" : false
          },
          {
            "name" : "Photography",
            "isDisabled" : false
          },
          {
            "name" : "Physics",
            "isDisabled" : false
          },
          {
            "name" : "PlayStation",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Pokémon",
            "isDisabled" : false
          },
          {
            "name" : "Pokémon",
            "isDisabled" : false
          },
          {
            "name" : "Political events",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Potterheads",
            "isDisabled" : false
          },
          {
            "name" : "Professions",
            "isDisabled" : false
          },
          {
            "name" : "Project management",
            "isDisabled" : false
          },
          {
            "name" : "R&B and soul",
            "isDisabled" : false
          },
          {
            "name" : "Retail industry",
            "isDisabled" : false
          },
          {
            "name" : "Rock",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Social causes",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Soul music",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Sports photography",
            "isDisabled" : false
          },
          {
            "name" : "Sustainability",
            "isDisabled" : false
          },
          {
            "name" : "Tech industry",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Television",
            "isDisabled" : false
          },
          {
            "name" : "Tesla Motors",
            "isDisabled" : false
          },
          {
            "name" : "The Bachelor",
            "isDisabled" : false
          },
          {
            "name" : "The OA",
            "isDisabled" : false
          },
          {
            "name" : "The OA (Netflix)",
            "isDisabled" : false
          },
          {
            "name" : "Toni Morrison",
            "isDisabled" : false
          },
          {
            "name" : "Travel",
            "isDisabled" : false
          },
          {
            "name" : "Travel Actions",
            "isDisabled" : false
          },
          {
            "name" : "Twitter",
            "isDisabled" : false
          },
          {
            "name" : "Twitter Blue",
            "isDisabled" : false
          },
          {
            "name" : "UNESCO",
            "isDisabled" : false
          },
          {
            "name" : "US national news",
            "isDisabled" : false
          },
          {
            "name" : "United States Congress",
            "isDisabled" : false
          },
          {
            "name" : "United States political events",
            "isDisabled" : false
          },
          {
            "name" : "United States politics",
            "isDisabled" : false
          },
          {
            "name" : "University of Chicago",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Visual arts",
            "isDisabled" : false
          },
          {
            "name" : "Vivo",
            "isDisabled" : false
          },
          {
            "name" : "Water",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "Web development",
            "isDisabled" : false
          },
          {
            "name" : "WhatsApp",
            "isDisabled" : false
          },
          {
            "name" : "Work from home",
            "isDisabled" : false
          },
          {
            "name" : "Writing",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          },
          {
            "name" : "ポケットモンスター",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [
            "@360safecenter",
            "@8ballpool",
            "@ABEMA",
            "@AlexandrTankov",
            "@AmazonIT",
            "@AmazonJP",
            "@AmazonNewsES",
            "@AmazonNewsFR",
            "@AmazonUK",
            "@App_OfThe_Day",
            "@BlaBlaCarTR",
            "@BubbleWitchJP",
            "@Bubble_Witch",
            "@CandyCrushJelly",
            "@CandyCrushSaga",
            "@CandyCrushSoda",
            "@ClarkGermany",
            "@ClashRoyale",
            "@ClashRoyaleJP",
            "@ClashofClans",
            "@ClashofClansJP",
            "@CoupangEats",
            "@DeezerDE",
            "@DeezerFR",
            "@Eat24",
            "@Evony_TKR",
            "@FarmHeroesSuper",
            "@FlixBus",
            "@FoursquareGuide",
            "@FreeNow_DE",
            "@FreeNow_ES",
            "@FreeNow_IE",
            "@FreeNow_IT",
            "@Freeletics",
            "@GI_Mobile",
            "@Gemini",
            "@GeniesandGems",
            "@Hearthstone_ru",
            "@Immobilienscout",
            "@IndeedBrasil",
            "@IndeedDeutsch",
            "@IndeedEspana",
            "@IndeedMexico",
            "@IndeedNZ",
            "@IndeedSverige",
            "@Indeed_India",
            "@KL7",
            "@KyleD",
            "@LINE_tsumtsum_j",
            "@Lieferheld",
            "@LinkedIn",
            "@McDonalds_BR",
            "@NetflixJP",
            "@NieR_Rein",
            "@Omiai_jp",
            "@PERFMKTNG",
            "@PeacockStore",
            "@PetzOficial",
            "@PlayHearthstone",
            "@PlayPandaPop",
            "@RapCaviar",
            "@RappiBrasil",
            "@RappiMexico",
            "@Retale",
            "@SNOW_jp_SNOW",
            "@Shpock",
            "@ShpockUK",
            "@SimCityBuildIt",
            "@SkyscannerJapan",
            "@SoundCloud",
            "@Spotify",
            "@SpotifyARG",
            "@SpotifyAU",
            "@SpotifyAds",
            "@SpotifyAfrica",
            "@SpotifyArabia",
            "@SpotifyBrasil",
            "@SpotifyCanada",
            "@SpotifyCares",
            "@SpotifyChile",
            "@SpotifyColombia",
            "@SpotifyDE",
            "@SpotifyEurope",
            "@SpotifyHK",
            "@SpotifyID",
            "@SpotifyIreland",
            "@SpotifyJP",
            "@SpotifyKR",
            "@SpotifyKpop",
            "@SpotifyLive",
            "@SpotifyMY",
            "@SpotifyMexico",
            "@SpotifyNL",
            "@SpotifySG",
            "@SpotifySpain",
            "@SpotifyTurkiye",
            "@SpotifyUK",
            "@SpotifyUSA",
            "@SpotifyVietnam",
            "@Spotify_LATAM",
            "@Spotify_PH",
            "@Spotify_TH",
            "@Starbucks",
            "@StarbucksCanada",
            "@SuperMarioRunJP",
            "@TheSandwichBar",
            "@Tinder",
            "@Tribez_Game",
            "@Twitter",
            "@Uber",
            "@UberEats",
            "@Uber_Brasil",
            "@Uber_India",
            "@VineCreators",
            "@WishShopping",
            "@Yelp",
            "@_Kevork_",
            "@_WinTicket",
            "@accuweather",
            "@amazon",
            "@amazonDE",
            "@anchor",
            "@appreviwer",
            "@best_convert",
            "@blablacarIT",
            "@blinkist",
            "@blossomblast",
            "@blossomblast_jp",
            "@bodyfastapp",
            "@candyjelly_jp",
            "@ccjelly_fun",
            "@clashofkingsJP",
            "@cleanmaster_jp",
            "@eventbrite",
            "@forpodcasters",
            "@gameofwar",
            "@gonsuzuki0425",
            "@hearthstone_es",
            "@hearthstone_it",
            "@hepsiburada",
            "@here",
            "@houchishoujo",
            "@houzz",
            "@inDriveBrasil",
            "@jinchaoye",
            "@lovoo",
            "@mercari_jp",
            "@mercari_wolf",
            "@moovit",
            "@nytimes",
            "@piccoma_jp",
            "@rakutenapp",
            "@spotifyartists",
            "@spotifyfrance",
            "@spotifyindia",
            "@spotifypodcasts",
            "@spotifytaiwan",
            "@tapple_official",
            "@thetribez_game",
            "@tiktok_kuromame",
            "@tiktok_us",
            "@trivago",
            "@vodafone_de",
            "@zexy_news",
            "@zhihao",
            "@247GRAD",
            "@28dayschallenge",
            "@3DRobotics",
            "@7eleven",
            "@ASpokesman",
            "@AdHearthstone",
            "@AlJazirahFord",
            "@AmericanXRoads",
            "@AppMrsool",
            "@AshvsEvilDead",
            "@Athleta",
            "@Atlassian",
            "@AudienseCo",
            "@BICRazors",
            "@BNYMellon",
            "@Baxshop",
            "@BaxshopFR",
            "@BelieveAgainGOP",
            "@BentleyMotors",
            "@Bigstock",
            "@Bitly",
            "@BlaBlaCarMX",
            "@BlaBlaCar_FR",
            "@BlizzHeroesDE",
            "@BlizzHeroesFR",
            "@BlueDiamond",
            "@BofA_Tips",
            "@Bookatable",
            "@BookatableDE_",
            "@BootsUK",
            "@Box_Europe",
            "@Busbud",
            "@BuzzFeedNews",
            "@CBRE",
            "@CMEGroup",
            "@CQ_Chat",
            "@CROPonline",
            "@Cadillac",
            "@CaptainAmerica",
            "@Carglass_NL",
            "@Cartier",
            "@Ciszek",
            "@CocaCola_GB",
            "@CollisionHQ",
            "@Coolblue_NL",
            "@CureSimple",
            "@DAZN_DE",
            "@DeerParkWtr",
            "@DellEMCDSSD",
            "@DellEMCECS",
            "@DellEMCIsilon",
            "@DeloitteHC",
            "@DigitalFsp",
            "@Discovery",
            "@DisneyCruise",
            "@Disney_IT",
            "@Disneyland",
            "@DollarGeneral",
            "@Dove",
            "@DowJones",
            "@Drive_pedia",
            "@Dropbox",
            "@DropboxBusiness",
            "@DukeEnergy",
            "@EA_Benelux",
            "@EE",
            "@EmpireTVSeries",
            "@Exact_NL",
            "@FITLP1",
            "@FandangoNOW",
            "@Fidelity",
            "@FilmStruck",
            "@FishdomOfficial",
            "@Ford",
            "@FrankandOak",
            "@FreeEnterprise",
            "@G2A_com",
            "@GE_Europe",
            "@GIPHY",
            "@Gett",
            "@Glassdoor",
            "@GoDaddy",
            "@GoogleForEdu",
            "@Greenhouse",
            "@HLN_BE",
            "@Hallmark",
            "@Heart_of_Vegas",
            "@HiltonHonors",
            "@HireArt",
            "@Hired_HQ",
            "@HomeDepot",
            "@Honda",
            "@IIP",
            "@IM_DBS",
            "@IPSY",
            "@ImmoVerkauf_de",
            "@IntelUK",
            "@Intuit",
            "@JackLinks",
            "@JetBlue",
            "@JustGiving",
            "@KevinFromWorkTV",
            "@KimKardashian",
            "@KingsProphets",
            "@KingsmanMovie",
            "@KodakMomentsapp",
            "@KrampusMovie",
            "@LGUSAMobile",
            "@Lexus",
            "@LincolnMotorCo",
            "@Livefyre",
            "@Lohika",
            "@Lotame",
            "@Lowes",
            "@LuckyCharms",
            "@MBNA_Canada",
            "@MLive",
            "@MacrobondF",
            "@Macys",
            "@Mailchimp",
            "@MastercardBiz",
            "@McDonaldsUK",
            "@Medium",
            "@Michel_Augustin",
            "@MoneySupermkt",
            "@MrWorkNl",
            "@MuleSoft",
            "@NFIB",
            "@NOW",
            "@NRFnews",
            "@Nequi",
            "@NetflixBrasil",
            "@NetflixLAT",
            "@Netflix_CA",
            "@NewsweekUK",
            "@Nike",
            "@NinjaJournalist",
            "@NintendoAmerica",
            "@NissanLatino",
            "@NissanUSA",
            "@NitroHQ",
            "@O2",
            "@OANDA",
            "@OLDSPARE2",
            "@OldNavy",
            "@OnTheHub",
            "@OnePlus_UK",
            "@OrdnanceSurvey",
            "@OriginInsider",
            "@Otelcom",
            "@P3Protein",
            "@PCFinancial",
            "@PalladiumHotels",
            "@PartsUnknownCNN",
            "@PayPalUK",
            "@PayPayBankCorp",
            "@Phanto_Minds",
            "@PitneyBowes",
            "@PolandSpringWtr",
            "@Poshmarkapp",
            "@Predator_USA",
            "@PrinsenhofDelft",
            "@Purple",
            "@QuickBooksUK",
            "@QuizUp",
            "@RakutenJP",
            "@Rakutenwebsrch",
            "@ReutersTV",
            "@SAPAnalytics",
            "@SMExaminer",
            "@STARZ",
            "@SURGEConfHQ",
            "@SamsungMobile",
            "@SamsungMobileSA",
            "@SamsungUK",
            "@ScottforFlorida",
            "@ScottishWidows",
            "@Screenbreak2",
            "@Shopify",
            "@Smafi_media",
            "@Speedtest",
            "@Square",
            "@StaplesStores",
            "@StatSocial",
            "@Studyo",
            "@Style_Castle",
            "@SyfyTV",
            "@SymantecFR",
            "@SynergyPharma",
            "@T2InteractiveUS",
            "@TDAmeritrade",
            "@TEDxCESalonED",
            "@TNLUK",
            "@TakedaOncology",
            "@TangerineBank",
            "@Target",
            "@Tejas",
            "@Tesco",
            "@TheBHF",
            "@TheDaddest",
            "@ThePublicSquare",
            "@TheWeekUK",
            "@TimCoronel",
            "@TimHortons",
            "@TomCoronel",
            "@TommyHilfiger",
            "@TryChangeUp",
            "@TweetDeck",
            "@TwitterBusiness",
            "@TwitterDev",
            "@TwitterMktLatam",
            "@TwitterMktgBR",
            "@TwitterMktgDACH",
            "@TwitterMktgES",
            "@TwitterMktgFR",
            "@TwitterMktgMENA",
            "@TwitterSafety",
            "@TwitterSurveys",
            "@TwitterUK",
            "@USPS",
            "@VMware",
            "@VelaEdFund",
            "@Venmo",
            "@VersyLATAM",
            "@Vimeo",
            "@Visa",
            "@VisitBritainGCC",
            "@Vontobel_SP_CH",
            "@WHSmith",
            "@WSJ",
            "@Wallapop_US",
            "@Walmart",
            "@WaltDisneyWorld",
            "@Warcraft",
            "@Warcraft_DE",
            "@Warcraft_FR",
            "@WebSummit",
            "@Webroot",
            "@Wix",
            "@Xero",
            "@Yahoo_GYAO",
            "@Zenefits",
            "@ZomatoUK",
            "@Zurich",
            "@adidas",
            "@adultswim",
            "@affiliatepapy",
            "@allyapp_DE",
            "@aperolspritzita",
            "@asahi_globe",
            "@atomtickets",
            "@audibleDE",
            "@baristabar",
            "@bookingcom",
            "@boostmobile",
            "@budlight",
            "@business",
            "@buzzfeedpartner",
            "@caprelo",
            "@carsdotcom",
            "@cbasahi",
            "@chevrolet",
            "@chicagotribune",
            "@cibc",
            "@citrix",
            "@copromote",
            "@cruelsummer",
            "@crushpath",
            "@diamondcandles",
            "@digimartnet",
            "@digitalocean",
            "@discoveryplus",
            "@door2door",
            "@dunkindonuts",
            "@eBay_UK",
            "@eToroFr",
            "@eldiarioes",
            "@enstars_music",
            "@facetune",
            "@famitsuApp",
            "@fantv",
            "@finestqapp",
            "@fiverr",
            "@flightdelays",
            "@footlockercad",
            "@galka_max",
            "@generalelectric",
            "@global_big",
            "@guardian",
            "@guardianlife",
            "@hatebu",
            "@hbonow",
            "@hearthstone_de",
            "@hearthstone_fr",
            "@hootsuite",
            "@idealo_de",
            "@idolypride",
            "@ingnl",
            "@investmentnews",
            "@janellebruland",
            "@kayla_itsines",
            "@kraftcheese",
            "@krispykreme",
            "@latimes",
            "@lawson_ticket",
            "@leboncoinEmploi",
            "@levtech_inc",
            "@lifetimetv",
            "@lipsjp",
            "@lotrimin",
            "@lovelink_line",
            "@lovingthefilm",
            "@marksandspencer",
            "@maxmara",
            "@meshfire",
            "@mondaydotcom",
            "@monmouthu",
            "@musinsacom",
            "@n26",
            "@namedotcom",
            "@netflix",
            "@newgozaik",
            "@newmarkjschool",
            "@nielsen",
            "@nikeaustralia",
            "@nobleaudio_jp",
            "@noteableyfood",
            "@notonthehighst",
            "@oldelpaso",
            "@oneplus",
            "@oronaminc_drink",
            "@oscon",
            "@pandoramusic",
            "@paperpile",
            "@pepsi",
            "@realDonaldTrump",
            "@reedcouk",
            "@ricardo_ch",
            "@saji__love",
            "@sethrobot",
            "@sharper_brain",
            "@sidekick",
            "@slurpee",
            "@supermemo",
            "@suzukiireland",
            "@taimiapp",
            "@techreview",
            "@tescomobile",
            "@the_fashionball",
            "@thinkackee",
            "@threadless",
            "@throne_rush",
            "@tradegovuk",
            "@trustagentsgmbh",
            "@tsuruhaofficial",
            "@virginmedia",
            "@voice_evidence",
            "@voxsup",
            "@webtanforum",
            "@welt",
            "@wileyinresearch",
            "@zillow",
            "@zitlekker",
            "@zomato"
          ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [
          "A Discovery of Witches",
          "American Horror Story",
          "American Idol",
          "Babylon Berlin",
          "Barclays Premier League Football",
          "Barclays Premier League Soccer",
          "Being Mary Jane",
          "Better Call Saul",
          "Better Call Saul (Netflix UK)",
          "Big Brother Brasil",
          "Black Widow",
          "Breaking Bad",
          "Bridgerton",
          "Bruce Springsteen: In His Own Words",
          "Bundesliga Soccer",
          "Captain America: The First Avenger",
          "Catfish: The TV Show",
          "Charlie and the Chocolate Factory",
          "Chilling Adventures of Sabrina (Netflix)",
          "College Football",
          "Cyclisme : Tour d'Italie 2017",
          "Darkness",
          "Dexter",
          "Die Hard",
          "Don't Look Up",
          "Downton Abbey",
          "Downton Abbey: A New Era",
          "E.T. the Extra-Terrestrial",
          "English Premier League Soccer",
          "Eurovision Song Contest 2019",
          "Everything Everywhere All At Once",
          "Falco",
          "First Cow",
          "First Take",
          "Formula One Racing",
          "Frozen 2",
          "Futbol Alemana (Bundesliga)",
          "Futebol NFL",
          "Fútbol Americano de la NFL",
          "Game of Thrones",
          "Grease",
          "Grimm",
          "Hannibal",
          "His Dark Materials",
          "House of Cards",
          "L'Équipe du soir",
          "LISTENERS",
          "La reine des neiges",
          "Last Night in Soho",
          "Les Reines du Shopping",
          "Live: College Football",
          "Live: NBA Basketball",
          "Loki",
          "Luther",
          "MLB Baseball",
          "Madiba",
          "Masterpiece Classic (includes Downton Abbey)",
          "NBA Basketball",
          "NCIS",
          "NFL Football",
          "NHL Hockey",
          "National Treasure",
          "Nightmare Alley",
          "NinjaGo: Masters of Spinjitzu",
          "Nomadland",
          "Old",
          "PAW Patrol",
          "Peppa Pig",
          "Pinocchio (2022 - animated) ",
          "Premier League",
          "Premios Goya 2017",
          "Pride and Prejudice",
          "Promising Young Woman",
          "Ratatouille",
          "Riders of Justice",
          "Riverdale",
          "Saturday Night Live",
          "Scandal",
          "Scott & Bailey",
          "Sesame Street",
          "Shameless",
          "SpongeBob SquarePants",
          "Squid Game",
          "Star Trek Picard",
          "Stranger Things",
          "Stranger Things (Netflix)",
          "Tenet",
          "The 40th Annual Kennedy Center Honors",
          "The Bachelor",
          "The Daily Show with Trevor Noah",
          "The Endless Trench",
          "The French Dispatch",
          "The Muppets",
          "The Night Manager",
          "The OA (Netflix)",
          "The Queen's Gambit  ",
          "The Social Dilemma",
          "The State",
          "The Suicide Squad (2021)",
          "The Talk",
          "The Tonight Show Starring Jimmy Fallon",
          "The Voice Brasil",
          "The Walking Dead",
          "The Wire",
          "The Witcher (Netflix)",
          "Tick, Tick... Boom!",
          "Today With Hoda & Jenna",
          "UEFA Europa League Football",
          "Very British Problems",
          "West Side Story (2021)",
          "Wimbledon Tennis Championships 2017",
          "ネコぱら",
          "ハイキュー!! ",
          "十九歳",
          "日本プロ野球",
          "木ドラ25 テレビ演劇 サクセス荘"
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]