window.YTD.deleted_tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1472979322348744706"
          ],
          "editableUntil" : "2021-12-20T17:46:51.737Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Orangenöl @sinensetin@openbiblio.social",
            "screen_name" : "sinensetin",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1047535801855344640",
            "id" : "1047535801855344640"
          },
          {
            "name" : "stabihh",
            "screen_name" : "StabiHH",
            "indices" : [
              "40",
              "48"
            ],
            "id_str" : "52349626",
            "id" : "52349626"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1472979322348744706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1472979322348744706",
      "created_at" : "Mon Dec 20 17:16:51 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @sinensetin: Spannende Stelle an der @StabiHH für erfahrene Bachelor/Dipl Bibs: ePflicht, A10/E10, unbefristet.\n\nDie Lage der Stabi ist…",
      "deleted_at" : "Sun Dec 25 14:55:10 +0000 2022"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1361294083524874241"
          ],
          "editableUntil" : "2021-02-15T13:09:35.790Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Orangenöl @sinensetin@openbiblio.social",
            "screen_name" : "sinensetin",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1047535801855344640",
            "id" : "1047535801855344640"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1361294083524874241",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1361294083524874241",
      "created_at" : "Mon Feb 15 12:39:35 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @sinensetin: OA in den Rechtswissenschaften. Moderne Publikationsformen (multi-author blog als wissenschaftlicher Output).\n\n1x OA-Verlag…",
      "contributors" : [
        "1256125165416693760"
      ],
      "deleted_at" : "Sun Dec 25 14:57:30 +0000 2022"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1603742830391951360"
          ],
          "editableUntil" : "2022-12-16T13:54:21.523Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "@obj@openbiblio.social",
            "screen_name" : "OpenBiblioJobs",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "633519651",
            "id" : "633519651"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1603742830391951360",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1603742830391951360",
      "created_at" : "Fri Dec 16 13:24:21 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @OpenBiblioJobs: Liebe Leute,\nich möchte Twitter nicht mehr unterstützen und werde die Veröffentlichung der Job-Tweets zum Jahresende ab…",
      "lang" : "de",
      "deleted_at" : "Mon Dec 26 19:53:40 +0000 2022"
    }
  }
]