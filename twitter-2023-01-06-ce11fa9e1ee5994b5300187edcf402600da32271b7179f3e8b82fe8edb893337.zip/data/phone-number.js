window.YTD.phone_number.part0 = [
  {
    "device" : {
      "phoneNumber" : "+491774679533"
    }
  }
]