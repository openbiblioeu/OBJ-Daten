window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1571771076077551616",
                "tweetText" : "Jedes Vermögen hat eine einzigartige Geschichte. Der erfolgreiche Unternehmer Jacob Fatih begleitet heute Gründer zum Erfolg. In Vermögensfragen begleiten wir ihn – mit Lösungen nach Maß.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Commerzbank",
                "screenName" : "@commerzbank"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@handelsblatt"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@wef"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@business"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@wiwo"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FAZ_Wirtschaft"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WorldBank"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 to 54"
                }
              ],
              "impressionTime" : "2022-10-18 10:27:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SiteGround Deutschland",
                "screenName" : "@SiteGround_DE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "web development"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "business owner"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-10-18 10:27:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SiteGround Deutschland",
                "screenName" : "@SiteGround_DE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "web development"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "business owner"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-10-18 10:27:25"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1575205658663829517",
                "tweetText" : "Smart Trainer-Alarm🚨Hier kommt der #ZwiftHub. Nur 499 € und in wenigen Minuten fahrbereit. Das musst man gesehen haben 👀",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Zwift",
                "screenName" : "@GoZwift"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cyclisme : Tour d'Italie 2017"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-11-01 14:57:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "JENTIS",
                "screenName" : "@JentisGmbH"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "datenschutz"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-11-01 14:54:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "JENTIS",
                "screenName" : "@JentisGmbH"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "datenschutz"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-11-01 14:56:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1578045460035641345",
                "tweetText" : "Monströse Aromen, rauchiger Biss: das ist Ardbeg Wee Beastie! Entdecke unsere rauchigen 'Planet Ardbeg' Stories auf https://t.co/igGZ0RTCPy #MassvollGeniessen \nBitte teile unsere Inhalte nur mit Personen ab 18 Jahren.",
                "urls" : [
                  "https://t.co/igGZ0RTCPy"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ardbeg",
                "screenName" : "@Ardbeg"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer gaming"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-01 14:54:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "JENTIS",
                "screenName" : "@JentisGmbH"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "datenschutz"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-11-01 15:00:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1581948141695209472",
                "tweetText" : "Wir glauben jedes Lächeln erzählt eine Geschichte. Mit atemberaubenden Filmen, unvergesslichen Original-Serien und exklusiven Sportsendungen gibt es auf Prime Video RICHTIG VIELE gute Gründe zu lächeln. https://t.co/1RT3AMhpFr",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/1RT3AMhpFr"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Prime Video DE",
                "screenName" : "@PrimeVideoDE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "appleTV"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NetflixDE"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2022-11-01 15:02:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1578045460035641345",
                "tweetText" : "Monströse Aromen, rauchiger Biss: das ist Ardbeg Wee Beastie! Entdecke unsere rauchigen 'Planet Ardbeg' Stories auf https://t.co/igGZ0RTCPy #MassvollGeniessen \nBitte teile unsere Inhalte nur mit Personen ab 18 Jahren.",
                "urls" : [
                  "https://t.co/igGZ0RTCPy"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ardbeg",
                "screenName" : "@Ardbeg"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer gaming"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                }
              ],
              "impressionTime" : "2022-11-01 15:00:49"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1602627391775379456",
                "tweetText" : "Wenn du eine Maus hast wirst du nie wieder deinen Computer ausschalten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "DITOGAMES",
                "screenName" : "@DITOGAMESch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-12-17 09:18:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "MSC 🐟 Fisch in 🇩🇪🇦🇹🇨🇭",
                "screenName" : "@MSC_Fisch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-12-17 09:18:00"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1603748020280909825",
                "tweetText" : "ULTIMATIVER KÖNIGLICHER SCHLITZER. KOSTENLOSE TESTPHASE 16.-22. DEZEMBER. #NARAKA",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NARAKA: BLADEPOINT",
                "screenName" : "@NARAKATHEGAME"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cd projekt red"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Tabletop gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PC gaming"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer gaming"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-17 13:06:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1603877893871910912",
                "tweetText" : "Wir leben im Jahr 2022, diese Leute leben im Jahr 3025. 🤯",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "ParentMood",
                "screenName" : "@ParentMood"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-17 13:06:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1595101936969302016",
                "tweetText" : "Jede klimafreundliche Entscheidung zählt: ob auf @googlemaps mit spritsparenden Routen Kraftstoff, Energie &amp; Geld sparen, Fahrräder leihen, oder in der Google Suche Emissionen für Züge und Flüge vergleichen. Mehr Tipps unter https://t.co/R6aRGRlLDK. #Klimaschutz https://t.co/bwag8LI99u",
                "urls" : [
                  "https://t.co/R6aRGRlLDK"
                ],
                "mediaUrls" : [
                  "https://t.co/bwag8LI99u"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Google Deutschland",
                "screenName" : "@GoogleDE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Sustainability"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Umgebung"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Nachhaltigkeit"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                }
              ],
              "impressionTime" : "2022-12-17 13:06:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1463918224966393862",
                "tweetText" : "🎄Was diesen Rucksack zum besten Geschenk macht\n\nDer Siena Smart Backpack ist ein stilvoller und kompakter Rucksack, der alle Funktionen hat, die ein Reisender sich wünschen kann, und noch mehr!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Nordace",
                "screenName" : "@NordaceOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-17 13:06:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1602621603803709447",
                "tweetText" : "Wenn du eine Maus besitzt wirst du nie wieder deinen PC ausschalten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "DITOGAMES",
                "screenName" : "@DITOGAMESch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "35 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2022-12-17 13:06:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1601196181559836673",
                "tweetText" : "NEOM’s Media Village is home to industry standard, purpose-built production facilities unlike any in the region.🌐 With the most generous cash rebates we provide a seamless production experience. 🎥\n\n#NEOM",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "NEOM",
                "screenName" : "@NEOM"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#Amc"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-17 13:06:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1603886222027489280",
                "tweetText" : "Du wirst nicht glauben, was diese Flugbegleiter/innen zu sagen haben. 🤑",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Buzzerilla",
                "screenName" : "@buzzerilla"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-17 13:06:07"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1604505960378163201",
                "tweetText" : "Leo Messi, Weltmeister. #ImpossibleIsNothing https://t.co/HDo2v1eJ63",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/HDo2v1eJ63"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "adidas Football",
                "screenName" : "@adidasfootball"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                }
              ],
              "impressionTime" : "2022-12-19 07:19:35"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Telekom zockt",
                "screenName" : "@Telekom_zockt"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Internet of things"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PC gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 4"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer gaming"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-12-20 12:41:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1604876858247593985",
                "tweetText" : "Apple Pay ist gemacht, um sicher zu sein. Jede:r kann eine verlorene oder gestohlene Karte nutzen. Face ID ist gemacht, damit nur du bezahlen kannst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "92779",
                "name" : "#Apple20221220",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Apple",
                "screenName" : "@Apple"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-20 12:41:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Telekom zockt",
                "screenName" : "@Telekom_zockt"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Internet of things"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PC gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 4"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer gaming"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-20 12:41:11"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1588473003981127680",
                "tweetText" : "Begib dich auf eine epische und emotionale Reise in God of War Ragnarök. Jetzt exklusiv für #PS4 und #PS5 erhältlich.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "92010",
                "name" : "#GodofWarRagnarok",
                "description" : "Jetzt exklusiv für PS4 und PS5"
              },
              "advertiserInfo" : {
                "advertiserName" : "PlayStationDE",
                "screenName" : "@PlayStationDE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-09 16:03:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1585288201052332033",
                "tweetText" : "Das Alles gibt es für nur 8,99€ pro Monat- ganz ohne versteckte Kosten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Disney+ DE",
                "screenName" : "@DisneyPlusDE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "entertainment"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-09 16:04:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "ABB Robotics Deutschland",
                "screenName" : "@ABB_Robotics_DE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-09 16:03:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1589256601726341121",
                "tweetText" : "💪 #Hochschulen und #Forschung werden von der Bundesregierung in der Energiekrise mit zwei Milliarden Euro entlastet. https://t.co/WawbMonlO0",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/WawbMonlO0"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "BMBF",
                "screenName" : "@BMBF_Bund"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BMBF_Bund"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-11-09 16:01:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "nextMedia.Hamburg",
                "screenName" : "@NextMediaHH"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Content"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Medien"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@medialab"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@brandeins"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MEEDIA"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@t3n"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-09 16:03:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1575205658663829517",
                "tweetText" : "Smart Trainer-Alarm🚨Hier kommt der #ZwiftHub. Nur 499 € und in wenigen Minuten fahrbereit. Das musst man gesehen haben 👀",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Zwift",
                "screenName" : "@GoZwift"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cyclisme : Tour d'Italie 2017"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-09 16:03:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "ABB Robotics Deutschland",
                "screenName" : "@ABB_Robotics_DE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-11 08:41:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1578045460035641345",
                "tweetText" : "Monströse Aromen, rauchiger Biss: das ist Ardbeg Wee Beastie! Entdecke unsere rauchigen 'Planet Ardbeg' Stories auf https://t.co/igGZ0RTCPy #MassvollGeniessen \nBitte teile unsere Inhalte nur mit Personen ab 18 Jahren.",
                "urls" : [
                  "https://t.co/igGZ0RTCPy"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ardbeg",
                "screenName" : "@Ardbeg"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer gaming"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                }
              ],
              "impressionTime" : "2022-11-11 08:41:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "ABB Robotics Deutschland",
                "screenName" : "@ABB_Robotics_DE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Der_BDI"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-11 08:41:35"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "MCMvaccine",
                "screenName" : "@MCMvaccine"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NLM_NIH"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-11-17 15:46:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1587129072013950976",
                "tweetText" : "Egal, ob du beruflich aufsteigen möchtest oder nach der Arbeit an deinem eigenen Lieblingsprojekt arbeitest – Windows 11 Laptops haben das, was du brauchst, um dieses Ziel zu erreichen. Schnelle Performance, Produktivitäts-Tools und natürlich erweiterte Sicherheit.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Microsoft Germany",
                "screenName" : "@MicrosoftDE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Windows"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-17 15:46:05"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1593504060132433920",
                "tweetText" : "Die Wahrscheinlichkeit, dass jemand mit einem dieser erblichen Merkmale geboren wird, ist nicht so gering, wie wir dachten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "wackojaco",
                "screenName" : "@wacko_jaco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-19 09:48:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1592862995079634950",
                "tweetText" : "Bei ntv erfahren Sie alles rund um die Energiekrise",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "ntv Nachrichten",
                "screenName" : "@ntvde"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@spiegelonline"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@tagesschau"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@faznet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@morgenpost"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@DIEZEIT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ZDF"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ZDFheute"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@zeitonline_pol"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@zeitonline"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SZ"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-19 09:50:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1580307852639571969",
                "tweetText" : "Mach Dir Popcorn, Denn Diese Super Lustigen Und Peinlichen Pannen Sind Fast Genauso Lustig Wie Die Filme Selbst",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "DailyBee",
                "screenName" : "@DailyBee3"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-11-19 09:47:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1588182712304664576",
                "tweetText" : "Discover Noor Riyadh activities and artworks and book your tickets on our official website https://t.co/iBs3GfrIcf #NoorRiaydh #WeDreamofNewHorizons",
                "urls" : [
                  "https://t.co/iBs3GfrIcf"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "نور الرياض",
                "screenName" : "@NoorRiyadhFest"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                }
              ],
              "impressionTime" : "2022-11-19 09:46:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1592647166471901189",
                "tweetText" : "Leute haben ihre Kreuzfahrterfahrungen geteilt, und es ist an der Zeit,  die Urlaubspläne zu überdenken",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TravlerzMagazine",
                "screenName" : "@TravlerzMag"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-11-19 09:48:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1592167468843139072",
                "tweetText" : "Spielen Sie dieses Spiel nicht, wenn Sie unter 40 Jahre alt sind!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Gamesvid",
                "screenName" : "@gvdagencymb"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2022-11-19 09:44:52"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "MCMvaccine",
                "screenName" : "@MCMvaccine"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NLM_NIH"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-11-21 07:28:08"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "MCMvaccine",
                "screenName" : "@MCMvaccine"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NLM_NIH"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-30 11:33:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SOS-Kinderdörfer weltweit",
                "screenName" : "@soskinderdorf"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aktion_mensch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BMFSFJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@seawatchcrew"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-30 11:47:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Telekom zockt",
                "screenName" : "@Telekom_zockt"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer gaming"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FCBayern"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Internet of things"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PC gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 4"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-30 11:33:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1588188314753851393",
                "tweetText" : "Netflix gibt es jetzt schon ab 4,99 € pro Monat – mit dem neuen günstigeren Basis-Abo mit Werbung. https://t.co/Qx8Jg2ULO2",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/Qx8Jg2ULO2"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "netflixde",
                "screenName" : "@NetflixDE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Movies and TV shows",
                  "targetingValue" : "Movie - Black Widow"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Entertainment"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Disney+"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Netflix"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Disney"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@mubi"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#AppleTV"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "A&E"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "SUPERAUDIENCE - Marketing & Advertising professionals - Germany - 11-2022"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-30 11:47:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1596180958415306757",
                "tweetText" : "Die neue Original Serie #Willow nur auf Disney+ streamen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "92537",
                "name" : "#WillowSerie",
                "description" : "Willow auf Disney+ streamen"
              },
              "advertiserInfo" : {
                "advertiserName" : "Disney+ DE",
                "screenName" : "@DisneyPlusDE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-11-30 11:33:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SLG ––– Sebastian Seelig",
                "screenName" : "@slgworks"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2022-11-30 11:34:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1584921761304420352",
                "tweetText" : "Du möchtest Impact Investor:in werden? wiLLBe bietet dir die Chance – einfach, sicher und nachhaltig.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "wiLLBe",
                "screenName" : "@willbe_invest"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Portfolio Manager"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "bildung"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nytimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NaturePortfolio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Nature"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                }
              ],
              "impressionTime" : "2022-11-30 11:47:23"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "NEOM",
                "screenName" : "@NEOM"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-13 08:44:59"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Visit Oman",
                "screenName" : "@visitoman_vo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel Actions"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-12-16 09:57:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Visit Oman",
                "screenName" : "@visitoman_vo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel Actions"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-12-16 09:57:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1603525315548119042",
                "tweetText" : "Die App zur Ausstellung \"Eine Stadt wird bunt. Hamburg Graffiti History 1980-1999\" im Museum für Hamburgische Geschichte. Ihr könnt 55 Graffiti-Spots via AR erkunden, Fotos von damals sehen &amp; weitere Infos lesen. Kreiert Ihr Eure eigene Styles!\n\nhttps://t.co/d8ik3wHKis",
                "urls" : [
                  "https://t.co/d8ik3wHKis"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Stiftung Historische Museen Hamburg",
                "screenName" : "@histmuseenhh"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Hamburg"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Hamburg"
                }
              ],
              "impressionTime" : "2022-12-16 08:51:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Visit Oman",
                "screenName" : "@visitoman_vo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "@goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#goal"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-16 08:23:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Visit Oman",
                "screenName" : "@visitoman_vo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "@goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#goal"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-12-16 08:11:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Visit Oman",
                "screenName" : "@visitoman_vo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "@goal"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-12-16 08:23:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Visit Oman",
                "screenName" : "@visitoman_vo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "@goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#goal"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2022-12-16 08:06:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Visit Oman",
                "screenName" : "@visitoman_vo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "@goal"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#goal"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2022-12-16 08:11:54"
            }
          ]
        }
      }
    }
  }
]