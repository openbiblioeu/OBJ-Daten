window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "emXonqkDjKBANirxysUc17IBOY3F04QcNy4bq8YY",
      "createdAt" : "2021-08-04T05:24:44.659Z",
      "lastSeenAt" : "2021-08-04T05:24:44.661Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "vcqLY981xhDKoJ82Y6YwE5vqTuLufnATQEL5FJU7",
      "createdAt" : "2021-09-03T06:32:32.857Z",
      "lastSeenAt" : "2021-09-03T06:32:32.859Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]