window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "19238793-633519651",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Dankeschön, Dörte.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1559533067722694661",
            "createdAt" : "2022-08-16T13:30:32.759Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Phu, erstmal gute Besserung. Ich werde ein Auge drauf haben. Mach dir keine Sorgen und sieh zu, dass du bald wieder gesund wirst. Daumen sind gedrückt, dass es glimpflich bleibt.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1559531551544823812",
            "createdAt" : "2022-08-16T13:24:31.289Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Dörte, ich habe mit Covid zu kämpfen.. kannst Du diese Woche die Freischaltung übernehmen? Ich weiß nicht, wie aktiv die anderen dabei sind.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1559529717858025479",
            "createdAt" : "2022-08-16T13:17:14.101Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [
              {
                "senderId" : "19238793",
                "reactionKey" : "like",
                "eventId" : "1540093900731420679",
                "createdAt" : "2022-06-23T22:06:14.176Z"
              }
            ],
            "urls" : [ ],
            "text" : "Gab zum Glück schon ein Update des Plugins, funktioniert wieder!",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1540088858930515975",
            "createdAt" : "2022-06-23T21:46:12.124Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [
              {
                "senderId" : "19238793",
                "reactionKey" : "agree",
                "eventId" : "1539879700662730752",
                "createdAt" : "2022-06-23T07:55:04.894Z"
              }
            ],
            "urls" : [ ],
            "text" : "Nein, der trötet den RSS-Feed.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1539879654051422212",
            "createdAt" : "2022-06-23T07:54:53.796Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Okay, danke für die Info. Betrifft dies auch den Bot in Mastodon?",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1539879189616132103",
            "createdAt" : "2022-06-23T07:53:03.063Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ich musste das WP to Twitter Plugin deaktivieren. Schaue heute Abend mal genauer nach.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1539878942412312586",
            "createdAt" : "2022-06-23T07:52:04.135Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [
              {
                "senderId" : "19238793",
                "reactionKey" : "agree",
                "eventId" : "1476342715877109765",
                "createdAt" : "2021-12-30T00:01:47.254Z"
              }
            ],
            "urls" : [ ],
            "text" : "Nacht!",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1476342520716185613",
            "createdAt" : "2021-12-30T00:01:00.757Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Danke. Lass uns darüber in Ruhe reden. Wünsche dir eine gute Nacht und, falls wir uns nicht mehr lesen, komm gut ins Jahr 2022",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1476342238217125896",
            "createdAt" : "2021-12-29T23:59:53.393Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Habs wieder ausgeblendet!",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1476341843696705541",
            "createdAt" : "2021-12-29T23:58:19.326Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ich konnte nicht einschlafen und habe mir dabei nicht viel gedacht.. :) hat 15 Minuten gedauert, rückgängig machen geht noch schneller...",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1476341515224068106",
            "createdAt" : "2021-12-29T23:57:01.017Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Funktioniert. Bin mir nur unsicher, ob wir das wirklich brauchen. Was ist die Aussage und Konsequenz dahinter? Bringt es einen spürbaren Mehrwert für jemanden? - Vielleicht ist eine Mail ggf. günstiger, wenn sie einen anfangs vorformulierten Text enthält und dann eine Begründung herausfordert. Zudem sollte dies dann auch mit dem BIB und den Beteiligten der KEB abgesprochen werden.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1476340619173941255",
            "createdAt" : "2021-12-29T23:53:27.395Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/aBwULhWHra",
                "expanded" : "https://jobs.openbiblio.eu/",
                "display" : "jobs.openbiblio.eu"
              }
            ],
            "text" : "Ich hab testweise Like/Dislike-Däumchen eingebaut... https://t.co/aBwULhWHra",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1476337990146342919",
            "createdAt" : "2021-12-29T23:43:00.607Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Jepp, sehe ich auch so. Ohne organisierte Hilfe, zumindest beim Nacherfassen der Informationen wird das nichts. - Wenn sie mehr wollen, sollten sie vielleicht den Kompetenzmonitor umsetzen, der mal geplant war, zwar mit anderer Intention, aber der würde ihnen heute weiterhelfen.- Den neuen Beitrag werde ich die Woche fertig machen. \nUnd Umzug. Du machst es mir wohl nach. 16 Umzüge in 21 Jahren? Kann verstehen, dass du da eigentlich nicht noch mehr tun kannst.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1369036162787115012",
            "createdAt" : "2021-03-08T21:23:51.373Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Jo, kannst gern machen. Ich bin grad (mal wieder) umgezogen und hab auch viel um die Ohren. \nFür Wunder brauchen wir 5 Stunden die Woche jemand, der die Daten kuratiert :)",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1369034746194460681",
            "createdAt" : "2021-03-08T21:18:13.618Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ich hätte im Moment auch keine Zeit. Jeder, der für uns Werbung macht, ist Willkommen. Im Moment fände ich fast wichtiger hinzuweisen, dass die Volltexte direkt verlinkt werden mit funktionierenden Links. Ich könnte unsere Hilfe für die Links nochmal im Blog von OBJ veröffentlichen. Julia Brauer ist jetzt auch wieder aktiv, weil Kinder endlich wieder in die Schule können und kein Homeschooling nötig ist.\nIch glaube, sie hat gehofft, wir könnten Wunderdinge möglich machen.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1369033572892413967",
            "createdAt" : "2021-03-08T21:13:33.881Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "obib-Artikel finde ich übertrieben, wir könnten einfach mal wieder per Twitter ein paar HInweise einstreuen. Und Frau Söllner kann natürlich gerne alles weitergeben.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1369032369370501124",
            "createdAt" : "2021-03-08T21:08:46.950Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Phu,\n\nwollen wir uns nochmal verständigen wie wir damit umgehen wollen?\nKann auch kurzfristig dazu ein Zoom-Meeting /Skype gestalten. Oder per Telefon.\nLG\nDörte",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1368941371911008263",
            "createdAt" : "2021-03-08T15:07:11.466Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [
              {
                "senderId" : "19238793",
                "reactionKey" : "agree",
                "eventId" : "1295690177151729665",
                "createdAt" : "2020-08-18T11:53:05.660Z"
              }
            ],
            "urls" : [ ],
            "text" : "Ach so, das ist ein Hinweis für Admins. Ich bin normalerweise als OBJ-Redakteur angemeldet und sehe sie nicht.\nWenn mal viel Zeit, kümmere ich mich um diese jquery-Geschichte.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1295687309602545669",
            "createdAt" : "2020-08-18T11:41:42.030Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/3LoOBtacBY",
                "expanded" : "https://twitter.com/messages/media/1295685896210190341",
                "display" : "pic.twitter.com/3LoOBtacBY"
              }
            ],
            "text" : "hast du die dashboard-fehlermeldung gesehen? bin mit recht altem firefox (66.0.3 (64-Bit)) auf arbeit unterwegs ... https://t.co/3LoOBtacBY",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1295685896210190341/1295685667222159362/jAuifYsA.png"
            ],
            "senderId" : "19238793",
            "id" : "1295685896210190341",
            "createdAt" : "2020-08-18T11:36:05.098Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Interessant, die habe ich noch nicht zu GEsicht bekommen.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1295684776649728005",
            "createdAt" : "2020-08-18T11:31:38.101Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/khlXRZZkQN",
                "expanded" : "https://twitter.com/messages/media/1295388388615434244",
                "display" : "pic.twitter.com/khlXRZZkQN"
              }
            ],
            "text" : "Gab folgend Fehlermeldung - Anzeige in der Karte passte dann aber wieder https://t.co/khlXRZZkQN",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1295388388615434244/1295388326774689795/wDDFg6bo.png"
            ],
            "senderId" : "19238793",
            "id" : "1295388388615434244",
            "createdAt" : "2020-08-17T15:53:53.807Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Wünsche ich dir auch",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1295276096917733380",
            "createdAt" : "2020-08-17T08:27:41.261Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "👍 Schönen Wochenstart!",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1295249683884003333",
            "createdAt" : "2020-08-17T06:42:43.899Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Danke für die Info",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1295009410289475593",
            "createdAt" : "2020-08-16T14:47:58.223Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ich habe OBJ auf WP 5.5 geupdatet. Falls es Probleme im Admin-Bereich gibt, bitte Strg+F5 drücken.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1294925268797267972",
            "createdAt" : "2020-08-16T09:13:37.318Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja, das würde ich unterschreiben",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1286262878648111109",
            "createdAt" : "2020-07-23T11:32:22.568Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "👍 \nDie Tagcloud und Suche würde ich später bauen, aber im Moment bin ich eher skeptisch wegen des Plegeaufwands.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1286255657130360836",
            "createdAt" : "2020-07-23T11:03:40.824Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Phu, genau das ist auch meine Beobachtung. Zudem fehlt irgendwie, dass die Tags als Wolke angezeigt werden und dass sie anklickbar sind (eine Suche auslösen). Daneben hängt auch von der Länge der vorhergehenden Daten ab, ob und wieviele Tags bei Twitter mitgegebe werden. Im Moment würde ich von einer Bewerbung der Tags absehen, weil sich deutlich die Frage stellt, was sollen Tags und wie werden sie dann richtig vergeben. Das wird vermutlich genauso verpfuffen wie den richtigen Stellen- und Einrichtungstyp zu vergeben. Schauen wir also mal eine Weile zu.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1286249674274373637",
            "createdAt" : "2020-07-23T10:39:54.398Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Die Tags sind bei der Freischaltung doch etwas hakelig und aufwändig: mehrere Tags sind manchmal nicht kommasepariert eingegeben, Tags mit mehreren Wörtern müssen händisch zusammengeschrieben oder mit Unterstrich o.ä. ergänzt werden.\nRichtig Schrott war bisher nicht dabei, aber ziemlich unnötige und redundante wie Archiv, Bibliothek u.ä.\nIch wills noch eine Weile experimentiell lassen und die Tags auch noch nicht so prominent anzeigen. Auf den Dateilseiten werden sie schon angezeigt.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1286244062174097417",
            "createdAt" : "2020-07-23T10:17:36.388Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Also aktiv würde ich auch keine vergeben, aber wenn jemand #schrott schreibt, würde ich #schrott gerne weglöschen können - und dafür muss man ein Auge haben ... aber ich denke, das muss nicht sofort sein, sondern wenn es sichtbarer wird.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1283437094032093189",
            "createdAt" : "2020-07-15T16:23:43.013Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Eigentlich wollte ich Dir damit keine Arbeit machen...",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1283436393495244813",
            "createdAt" : "2020-07-15T16:20:55.992Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sollte jetzt erstmal ein kleiner Testlauf sein. Ich hätte die Tags nur ggf. bearbeitet, wenn da Tippfehler o.ä. drin sind und ansonsten nicht aktiv welche vergeben. Das sollen die Nutzer machen. Du hast Recht, wenn wir die Tags einführen, muss das dann in die Anleitung.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1283436234153525254",
            "createdAt" : "2020-07-15T16:20:18.016Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Gut, dann mache ich im Laufe der nächsten Woche einen Blogbeitrag dazu fertig. Für unsere OBJ-Redakteure wäre es gut zu wissen, dass die Tags im Quick-Edit angzeigt werden und dass bei der Bearbeitenmodus der gemeldeten Stellen die Tags ganz unten auf der Seite angezeigt werden und man die Bearbeitungsspalte nach oben ziehen sollte, falls mal jemand Mist eingibt. Auge drauf haben müssen wir schon",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1283434981260394504",
            "createdAt" : "2020-07-15T16:15:19.287Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ah, gut zu wissen, dass das funktioniert. Ich baue die Anzeige der Tags am Wochenende ein.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1283433992952446980",
            "createdAt" : "2020-07-15T16:11:23.653Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/xLyfl24H9k",
                "expanded" : "https://twitter.com/OpenBiblioJobs/status/1283431227274547200",
                "display" : "twitter.com/OpenBiblioJobs…"
              }
            ],
            "text" : "Hier der Tweet dazu: https://t.co/xLyfl24H9k",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1283433305875128324",
            "createdAt" : "2020-07-15T16:08:39.863Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/x6ccgdoCj1",
                "expanded" : "https://jobs.openbiblio.eu/stellenangebote/52546",
                "display" : "jobs.openbiblio.eu/stellenangebot…"
              }
            ],
            "text" : "Hi, die Hashtags sind eine gute Idee, werden aber nur bei Twitter angezeigt, oder? Bei OBJ habe ich jetzt nichts entdecken können. - Der Hashtag wird bei Twitter gut ausgeliefert: https://t.co/x6ccgdoCj1",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1283432937464254469",
            "createdAt" : "2020-07-15T16:07:12.060Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Bild bei Frage nach dem Volltext ändere ich, aber da gab es kein Problem,. Wer weiß, wo er sich da wieder aufgehangen hat.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1281659286247149572",
            "createdAt" : "2020-07-10T18:39:20.613Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Alles klar.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1281658042279436294",
            "createdAt" : "2020-07-10T18:34:24.023Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sehr seltsam. Jetzt sieht es bei mir auch okay aus. Das andere war auf dem Rechner auf Arbeit. Sollte da das Problem nochmal auftreten, würde ich mich melden ...  Keine Ahnung, was das wieder war.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1281657473624154117",
            "createdAt" : "2020-07-10T18:32:08.457Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Mir ist nur aufgefallen, dass im Beitrag \"Die Frage nach dem Volltext einer Stelle\" ein Bild von dem Amber-Popup von Deinem Blog eingebunden wird und zwar mit http. Das führt zu sog. \"mixed content\", einige Browser blocken solche potenziell unsicheren Inhalte.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1281657429181300740",
            "createdAt" : "2020-07-10T18:31:57.863Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hm, bei mir sieht es gut aus. Hat sich das Problem schon erledigt?",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1281656806654316548",
            "createdAt" : "2020-07-10T18:29:29.450Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/Y5OBmJ1Tjv",
                "expanded" : "https://twitter.com/messages/media/1281550385673646084",
                "display" : "pic.twitter.com/Y5OBmJ1Tjv"
              }
            ],
            "text" : "Hallo Phu,\nkannst du mal schauen, im akuellen Blogbeitrag werden folgende Bilder eingeblendet, obwohl die Bilder von OBJ als Screenshot hochgeladen worden und dann eingebunden worden sind. Eine Korrektur ist nicht möglich, z.B. durch erneutes Einbinden der Bilder.\n\nLG\nDörte https://t.co/Y5OBmJ1Tjv",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1281550385673646084/1281549487429820419/_3nbOIxc.png"
            ],
            "senderId" : "19238793",
            "id" : "1281550385673646084",
            "createdAt" : "2020-07-10T11:26:36.826Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Stimmt, kann ich bestätigen. An der Stelle gibt es ein Fehler im edit-comments.min.js von WordPress. Betrifft wahrscheinlich alle WPs. Wenn man den Haken setzt und dann Endgültig löschen auswählt und übernimmt, dann gehts.\nIch warte mal das nächste WP-Update ab.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1273870937377722372",
            "createdAt" : "2020-06-19T06:51:13.543Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Schräg, probier ich mal, wenn wieder Spam reinkommt. Die ich vorhin gelöscht habe sind wirklich weg.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1273535252573704196",
            "createdAt" : "2020-06-18T08:37:20.044Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Bei Spamfilter leeren kommt \"Link ist abgelaufen\" - Löschen geht auf den ersten Blick, mit Reload sind sie wieder da gewesen. Und einmal habe ich das vom Chrome auf meinem Rechner gemacht (gestern abend) und heute morgen von Chrome auf meinem Handy.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1273502154179973125",
            "createdAt" : "2020-06-18T06:25:48.769Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "können. Ich schau heute Abend mal nach.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1273499022981042181",
            "createdAt" : "2020-06-18T06:13:22.229Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Komisch, ich konnte sie eben als OBJ-Redaktuer endgültig löschen. Als Admin müsstest Du das erst recht.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1273498850372747268",
            "createdAt" : "2020-06-18T06:12:41.081Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Guten Morgen, \nder Blog bei OBJ wird gerade zugespamt. Die Spamkommentare lassen sich dann zwar in den Spamordner schieben,  aber nicht endgültig löschen. \nLG\nDörte",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1273489680684679174",
            "createdAt" : "2020-06-18T05:36:14.856Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "bin ich auch gespannt",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272965297255976970",
            "createdAt" : "2020-06-16T18:52:32.107Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Na klar. Mal sehen, was deren Motivation ist.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272964436010184708",
            "createdAt" : "2020-06-16T18:49:06.768Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Okay, in die Richtung wäre ich auch gegangen. Danke für die \"Rückendeckung\".",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272963358057209861",
            "createdAt" : "2020-06-16T18:44:49.771Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ich würde anmerken, dass die Stelle noch online ist und  nach dem Grund fragen. Und eventuell darauf hinweisen, dass wir ohne trifftigen Grund nicht löschen.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272963155786956809",
            "createdAt" : "2020-06-16T18:44:01.537Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Habe dir gerade mal eine E-Mail (an deine Googlemail-Adresse) weitergeleitet. Im Moment weiß ich nicht, wie ich darauf reagieren soll.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272954740306063365",
            "createdAt" : "2020-06-16T18:10:35.132Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Neben Jobs eintragen und suchen fehlte eigentlich noch freischalten. Next time",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272953112593137668",
            "createdAt" : "2020-06-16T18:04:07.058Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ich saß in einem sonnigen Büro bei 27 Grad und war meilenweit entfernt von einem Eis, aber das Lachen hat gut getan",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272952791343005700",
            "createdAt" : "2020-06-16T18:02:50.465Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ich saß auf dem sonnigen Balkon, es war so das erste, was mir einfiel ;)",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272952463973330949",
            "createdAt" : "2020-06-16T18:01:32.414Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ist okay. Ich nutze das immer, um auf den institutionellen Account hinzuweisen, wo das dann gleich in ihrer Hand liegt ;-) - Blogbeitrag ist angepasst. - Übrigens über das Eis habe ich gut gelacht heute :D",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272951459739504646",
            "createdAt" : "2020-06-16T17:57:32.987Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Danke! \nBtw, ich habe eben auf Anfrage der DNB aus einem Sammeleintrag 4 einzelne Einträge gemacht, alle mit der selben URL und Kennziffer. Die einzelnen Bezeichungen gehen zwar nicht aus dem Ausschreibungstext hervor, aber so wollten sie es gern haben. Nur so zur Info.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272950071294865412",
            "createdAt" : "2020-06-16T17:52:01.959Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "upps, das war heute morgen auf arbeit ... - dann korrigiere ich mal",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272949143539986436",
            "createdAt" : "2020-06-16T17:48:20.761Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Muss Dich nochmal nerven.. die archivierten Stellen haben wie besprochen einen schwarzen Punkt. Wenn bei Dir kein Punkt angzeigt wird, ist das der Cache! Bitte einmal neuladen.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272948966280302596",
            "createdAt" : "2020-06-16T17:47:38.499Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Perfekt. Nac h Datum macht glaube bei unserem Angebot mehr Sinn. Dankeschön.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272767898763898889",
            "createdAt" : "2020-06-16T05:48:08.641Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Moin, ich habs gefixt. Und die Suchergebnisse sind jetzt nach Datum sortiert. Vorher war es wohl nach Relevanz.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272766802494459908",
            "createdAt" : "2020-06-16T05:43:47.267Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "war auf mehreren browsern der fall ...",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272595937475661828",
            "createdAt" : "2020-06-15T18:24:49.869Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh, tatsächlich... dachte das Problem schon behoben zu haben..",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272595601553797125",
            "createdAt" : "2020-06-15T18:23:29.784Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hast du mal die Seite neu geladen?",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272594867290595332",
            "createdAt" : "2020-06-15T18:20:34.721Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "verwendet habe ich chrome :)",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272594610368454661",
            "createdAt" : "2020-06-15T18:19:33.461Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "gibt ein problem. suche mal nach berlin, ohne einschränkungen = 1832 treffer verteilt auf 92 seiten. passt rechnerisch. dann gucke mal auf seite 92, 91 ... - leider \"nichts gefunden\". so heißt es auch ab seite 8.\naußerdem ist die seitenzählung am ende der seite doppelt. dort sind es aber auch maximal 7 seiten.\n\nbei der suche nach e 10 gibt es über 4923 treffer, am ende sind es nur 17 seiten. - mit jeder angezeigten seite verringern sich auch die trefferzahlen unverhältnismäßig. \n\nsuche nach fachreferat ergibt 52 treffer auf 3 seiten, aber schon ab seite 2 heißt es \"nichts gefunden\"",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272594077545103366",
            "createdAt" : "2020-06-15T18:17:26.427Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Jo, hab ich gemacht.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272588645854306312",
            "createdAt" : "2020-06-15T17:55:51.413Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Gute Idee :)",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272497373902778372",
            "createdAt" : "2020-06-15T11:53:10.480Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ich kann die archivierten heute Abend schwarz einfärben..",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272497097913307140",
            "createdAt" : "2020-06-15T11:52:04.680Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Nee, finde ich nicht. Mir ist nämlich eingefallen, dass du das mal gemacht hast, als du auch die Umstellung mit der Nummerierung getan hast. Bliebe nur die Frage, geht noch eine dritte Farbe wie rot oder so für archivierte Stellen? Eingangsdatum würde nicht funktionieren, weil wir zum Teil Ausbildungsstellen haben, die 5 Monate und länger \"aktuell\" sind laut Bewerbungsfrist ... - das wäre natürlich auch eine Variante",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272490590480093190",
            "createdAt" : "2020-06-15T11:26:13.190Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Was ich eigentlich mal machen wollte:\nHeute frisch erschienen\n-- Job 1\n-- Job 2\nLetzte Woche erschienen\n-- Job 3\n-- Job 4\nNoch älter\n-- Job 5",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272490341124526085",
            "createdAt" : "2020-06-15T11:25:13.736Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ist aber sowieso ne Schnapsidee von mir und deine Interpretation ist besser als die Umsetzung :)",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272489911082500101",
            "createdAt" : "2020-06-15T11:23:31.209Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Auf das Eingangsdatum.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272489729926234117",
            "createdAt" : "2020-06-15T11:22:48.019Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Zu kurz gedacht. Also muss man da auf die Frist schauen ... Naja, ich korrigiere das gleich mal. So kann ich es jedenfalls nicht stehen lassen.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1272484190647443460",
            "createdAt" : "2020-06-15T11:00:47.349Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Die tagesaktuellen Einträge haben sogar einen leuchtend-grünen Punkt... lol",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272482849162235909",
            "createdAt" : "2020-06-15T10:55:27.509Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Du, die grünen und grauen Punkte hab ich irgendwann mal eingeführt. Grün bedeutet in den letzten 7 Tagen veröffentlicht, grau alles davor. Die Idee ias, dass man beim Scrollen erkennt, ob es sich lohnt, weiter zu scrollen oder nicht..  Also nicht aktuell/archiviert. Ich weiß nicht, ob das irgendjemand verstanden hat :)",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272482630953578501",
            "createdAt" : "2020-06-15T10:54:35.492Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh wow, danke für die ausführliche Rückmeldung. Ich habe jetzt auf die Schnelle es in Stellenarchiv umbenannt und die Seitennummerierung nach links gezogen. Weitere Anpassungen mache ich ein anderes Mal, vielleicht wenn noch mehr Reckmeldungen gekommen sind.\nIch setz mal gleich ein Tweet ab. Danke Dir und schönen Abend noch!",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272230335057715207",
            "createdAt" : "2020-06-14T18:12:03.463Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/SNefWMtnER",
                "expanded" : "https://twitter.com/messages/media/1272211212223250436",
                "display" : "pic.twitter.com/SNefWMtnER"
              }
            ],
            "text" : "Auf den ersten Blick sieht es gut aus. Die Einschränkungsoptionen gefallen mir und die Sucherergebnisse ergeben Sinn.\n\nDann ein paar Vorschläge von meiner Seiter, sowohl zum Angebot als auch zum weiteren Vorgehen.\n\nEine zeitliche Einschränkbarkeit könnte das Ganze später gut ergänzen. \n\nStellenarchiv wäre vielleicht eine klare Bezeichnung oder OBJ-Archiv.\n\nBei der Darstellung würde ich die Seitennummerierung ganz nach vorne ziehen, wenn das möglich ist.\n\nBei der Suche, ich würde auf den\"normalen\" Seiten keine Suche im Archiv anbieten. Damit bleibt unser Fokus auf den aktuellen Stellen. Die Suche würde ich direkt auf der Archiv-Seite einbinden und nicht unbedingt in der Seitenleiste. \n\nZudem würde ich das Ganze erstmal als Beta-Version kennzeichnen und um Rückmeldung unserer Community bitten und vielleicht zum 01.07. das Ganze zugänglich machen .\n\nAber erstmal eine tolle Lösung. :D\n\nUnd zuletzt: Ein Relaunch wäre sicherlich gut mit der gesammelten Erfahrung, aber dafür musst du genug Luft haben. Zudem bedarf es jetzt auch ein bisschen mehr Vorbereitungszeit, da dann Arbeitsabläufe auch neu beschrieben werden müssen etc. Aber zum Testen und Co kannst du gerne mit mir rechnen.\n\nLG https://t.co/SNefWMtnER",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1272211212223250436/1272208545220624386/E5CoLuqE.png"
            ],
            "senderId" : "19238793",
            "id" : "1272211212223250436",
            "createdAt" : "2020-06-14T16:56:04.324Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Vielleicht archivierte-jobs? Ist nicht ganz so lang.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272209079918886916",
            "createdAt" : "2020-06-14T16:47:35.839Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Achso, und die Seite \"Archiv\" zu nennen könnte etwas verwirrend sein, oder?",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272207552596586505",
            "createdAt" : "2020-06-14T16:41:31.699Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/n3fiArmBAn",
                "expanded" : "https://jobs.openbiblio.eu/abgelaufene-stellenangebote",
                "display" : "jobs.openbiblio.eu/abgelaufene-st…"
              }
            ],
            "text" : "Huhu, hab eben die Archivseite heimlich freigeschaltet, aber noch nicht in der Navigation verlinkt: https://t.co/n3fiArmBAn\nDazu gibt eine minimalistische Suche rechts in der Sidebar. Generell sucht man jetzt im gesamten Bestand und nicht nur in den aktuellen Jobs.\nGuckst mal drauf? KÖnnen wir das so auf die Leute loslassen?\nDie Suchfunktion würde ich mit der Zeit weiter ausbauen. \n(Am liebsten würde ich OBJ komplett neu machen, aber das ist ein anderes Projekt... ;))",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1272207328834719749",
            "createdAt" : "2020-06-14T16:40:39.095Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Okay, Beitrag erscheint dann heute Nachmittag. Gehe heue mal früher und mach ihn dann fertig.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1271411808419688457",
            "createdAt" : "2020-06-12T11:59:31.502Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Kannst du gern machen.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1271411636608348167",
            "createdAt" : "2020-06-12T11:58:50.548Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Soll ich darauf mit verweisen?",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1271394840861986830",
            "createdAt" : "2020-06-12T10:52:06.134Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/kH4wWhNhKi",
                "expanded" : "https://github.com/openbiblioeu/OBJ-Daten",
                "display" : "github.com/openbiblioeu/O…"
              }
            ],
            "text" : "Super, danke. Sieht gut aus. Ich habe grad einen aktuellen csv-Export hierhin https://t.co/kH4wWhNhKi hochgeladen. Da ist auch der alte Export von der Google-Tabelle drin.\nWenn eine Anfrage kommt, werde ich die Export-Datei aus WordPress aktualisieren.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1271391142014267396",
            "createdAt" : "2020-06-12T10:37:24.685Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Phu,\n\nschau mal auf den Beitragsentwurf \"Die Frage nach dem Volltext einer Stelle\" bei OBJ. Hast du dazu noch Ergänzungen? Würde damit gerne ein wenig die Anfrage von Jan heute aufgreifen.\n\nLG\nDörte",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "1271360980933640196",
            "createdAt" : "2020-06-12T08:37:33.301Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Mach das.",
            "mediaUrls" : [ ],
            "senderId" : "19238793",
            "id" : "578590031146852352",
            "createdAt" : "2015-03-19T16:13:07.788Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "19238793",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ich bin mal so frech und veröffentliche jetzt den Finanzbuchhalter, ok?",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "578583547121963008",
            "createdAt" : "2015-03-19T15:47:21.982Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "27883670-633519651",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "27883670",
            "reactions" : [
              {
                "senderId" : "27883670",
                "reactionKey" : "agree",
                "eventId" : "1509450761150816258",
                "createdAt" : "2022-03-31T08:41:20.365Z"
              }
            ],
            "urls" : [ ],
            "text" : "Wenn die Einrichutngen ihre Angebote auf Englisch haben, übernehmen wir das. Soeben für  die Einträge von TIB und SPK nachträglich gemacht.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1509441588002496520",
            "createdAt" : "2022-03-31T08:04:53.331Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Die angebote sind zum Teil auf Deutsch. Wäre es möglich, sie zumindest auf Engl. zu übersetzen? Deutsch können in der UA vermutlich die wenigsten.",
            "mediaUrls" : [ ],
            "senderId" : "27883670",
            "id" : "1509092873890938887",
            "createdAt" : "2022-03-30T08:59:13.408Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/5gy7iBsL74",
                "expanded" : "https://jobs.openbiblio.eu/standwithukraine",
                "display" : "jobs.openbiblio.eu/standwithukrai…"
              }
            ],
            "text" : "Ми збираємо пропозиції щодо допомоги з працевлаштування для українських бібліотекарів, які були змушені залишити країну та шукають прихистку у Німеччині. Інформацію зібрано на спеціальному веб-сайті: https://t.co/5gy7iBsL74\n\nPlus ein Hashtag. Falls Ihr der Übersetzerin in einem Drunter-Tweet danken möchtet: @NataliiaKaliuz3",
            "mediaUrls" : [ ],
            "senderId" : "27883670",
            "id" : "1509092677526200329",
            "createdAt" : "2022-03-30T08:58:26.631Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "27883670",
            "reactions" : [
              {
                "senderId" : "27883670",
                "reactionKey" : "agree",
                "eventId" : "1507662192476311560",
                "createdAt" : "2022-03-26T10:14:12.362Z"
              }
            ],
            "urls" : [ ],
            "text" : "Ja, gerne den Tweet übersetzen. Wir tweeten das dann.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1507644377040134149",
            "createdAt" : "2022-03-26T09:03:24.848Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/QiavIPA94r",
                "expanded" : "https://twitter.com/OpenBiblioJobs/status/1506029818122543107",
                "display" : "twitter.com/OpenBiblioJobs…"
              }
            ],
            "text" : "Hierzu meine ich. https://t.co/QiavIPA94r",
            "mediaUrls" : [ ],
            "senderId" : "27883670",
            "id" : "1507638259861659657",
            "createdAt" : "2022-03-26T08:39:06.421Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Moin! Der Tweet auf Ukrainisch wäre vermutlich nützlich, oder? Wir haben schon Stipendiatinnen an der TIB, die am Montag bestimmt schnell helfen. Schreibt mir einfach, wie die Botschaft lauten soll.",
            "mediaUrls" : [ ],
            "senderId" : "27883670",
            "id" : "1507638112444461062",
            "createdAt" : "2022-03-26T08:38:31.261Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "68723145-633519651",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Jo, war auch mein initialer Gedanke. Prima.",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1583347643551551492",
            "createdAt" : "2022-10-21T06:41:10.086Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hab den Eintrag in den Papierkorb getan.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1583347437414109188",
            "createdAt" : "2022-10-21T06:40:20.949Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Moin Felix, ich würde sie nicht freischalten, weil weder in den Tätigkeiten noch in den Qualifikationen was mit Bibliothek drin steht. Phu",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1583347084110987268",
            "createdAt" : "2022-10-21T06:38:56.704Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/SZ7e0alfoX",
                "expanded" : "https://jobs.openbiblio.eu/?post_type=stellenangebote&p=81943&preview=true",
                "display" : "jobs.openbiblio.eu/?post_type=ste…"
              }
            ],
            "text" : "Hi, was sagt ihr zu dieser Einreichung: https://t.co/SZ7e0alfoX -- Filialleitung in einer Buchhandlung. Soll diese Branche auch auf OBJ sichtbar sein? Ich habe die Stelle bis zu eurer Antwort erstmal nicht freigeschaltet.",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1583345883994853381",
            "createdAt" : "2022-10-21T06:34:10.596Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Danke, Felix! Diese Fehlermeldung ist mir auch schon ein paar Mal aufgefallen. Ich habe sie bisher ignoriert, weil das Geocoding nachträglich dann doch funktioniert. \"Commercial service\" kommt eher nicht in Frage..",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1552044718019813385",
            "createdAt" : "2022-07-26T21:34:31.072Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/uRui45sfJb",
                "expanded" : "https://jobs.openbiblio.eu/wp-admin/post.php?post=78805&action=edit",
                "display" : "jobs.openbiblio.eu/wp-admin/post.…"
              }
            ],
            "text" : "Siehe diesen Eintrag https://t.co/uRui45sfJb. Ich würde denken, dass es ausreicht zu warten, wollte euch aber informieren.",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1551995194677026821",
            "createdAt" : "2022-07-26T18:17:43.821Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Das Stellenformular zeigt im Feld \"geocoding_error\" folgende Meldung an: 19: the hourly limit of 1000 credits for geomashup has been exceeded. Please throttle your requests or use the commercial service.\n\nEs lässt sich keine Verknüpfung zum Ort herstellen.",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1551995003769180164",
            "createdAt" : "2022-07-26T18:16:58.272Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Gerne :)",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1531367055764733956",
            "createdAt" : "2022-05-30T20:08:52.204Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Kannst aufhören, ich übernehme den Rest :) VG Phu",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1531366756622684167",
            "createdAt" : "2022-05-30T20:07:40.892Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ok, also kein Ausschlusskriterium ;) Schönen Abend!",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1531366633431875593",
            "createdAt" : "2022-05-30T20:07:11.508Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Wenns schnell geht (ist erledigt), sonst löschen.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1531366474966781957",
            "createdAt" : "2022-05-30T20:06:33.736Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/dy3B4866Ea",
                "expanded" : "https://jobs.openbiblio.eu/wp-admin/post.php?post=76401&action=edit",
                "display" : "jobs.openbiblio.eu/wp-admin/post.…"
              }
            ],
            "text" : "Moin, was macht ihr bei defekten Stellenanzeigen-Links? Hinterher googlen oder löschen? Bsp.: https://t.co/dy3B4866Ea",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1531365631848812548",
            "createdAt" : "2022-05-30T20:03:12.722Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Bis nachher!",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1525104096537083909",
            "createdAt" : "2022-05-13T13:22:06.365Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/v6r4QvC8Tz",
                "expanded" : "https://uni-hamburg.zoom.us/j/67175139265?pwd=SngzSlkrY2MweGQyTU8wY29la1dYdz09",
                "display" : "uni-hamburg.zoom.us/j/67175139265?…"
              }
            ],
            "text" : "https://t.co/v6r4QvC8Tz",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1525104057538469893",
            "createdAt" : "2022-05-13T13:21:57.837Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Heute passt. Wir haben Webex, bin aber offen für alle Tools.",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1525103877418373124",
            "createdAt" : "2022-05-13T13:21:14.123Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Heute 16:30? Sonst nächsten Mittwoch.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1525103581845671945",
            "createdAt" : "2022-05-13T13:20:03.655Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Okay. Ich bin gerade in Elternzeit und Kristin arbeitet wieder, sodass es erst ab dem späteren Nachmittag bei mir passt (16 Uhr ff). Bekommen wir das hin?",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1525102307758772229",
            "createdAt" : "2022-05-13T13:14:59.905Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "per",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1525102151168557063",
            "createdAt" : "2022-05-13T13:14:22.563Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Cool, am besten machen wir mal 15 Minuten Einweisung der Screensharing. Es gibt nämlich ein paar \"Quirks\" im Freischaltungsworkflow.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1525101992569364484",
            "createdAt" : "2022-05-13T13:13:44.742Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey Phu, ich würde mich an der Mithilfe beim Freischalten gern mal versuchen wollen.",
            "mediaUrls" : [ ],
            "senderId" : "68723145",
            "id" : "1525101317760368646",
            "createdAt" : "2022-05-13T13:11:03.856Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "68723145",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Felix, hier ist Phu. \n(Die DMs können einige andere aus dem OBJ-Team lesen.)",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1525089175938248709",
            "createdAt" : "2022-05-13T12:22:49.016Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "156578973-633519651",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hallo, ich möchte auch gerne spenden. Wäre PayPal auch okay?",
            "mediaUrls" : [ ],
            "senderId" : "156578973",
            "id" : "907628766230347781",
            "createdAt" : "2017-09-12T15:35:35.505Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "357509606-633519651",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "http://t.co/lIDTjaNaT4",
                "expanded" : "http://truetwit.com/vy248208939",
                "display" : "truetwit.com/vy248208939"
              }
            ],
            "text" : "StbSalzgitter uses TrueTwit validation service.  To validate click here: http://t.co/lIDTjaNaT4",
            "mediaUrls" : [ ],
            "senderId" : "357509606",
            "id" : "364699613602672640",
            "createdAt" : "2013-08-06T10:48:58.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "577003730-633519651",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Prima! Danke!",
            "mediaUrls" : [ ],
            "senderId" : "577003730",
            "id" : "1323908586859384836",
            "createdAt" : "2020-11-04T08:42:58.821Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "577003730",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Alles klar, ist schon gelöscht!",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1323908504999071749",
            "createdAt" : "2020-11-04T08:42:39.306Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hallo zusammen, habe gerade für die HCU ein Stellenangebot eingetragen. Bitte diesen Eintrag ignorieren/ löschen, da fehlt die Hälfte ^^ War zu schnell mit klicken auf absenden. Neues und vollständiges Angebot folgt",
            "mediaUrls" : [ ],
            "senderId" : "577003730",
            "id" : "1323907230274625543",
            "createdAt" : "2020-11-04T08:37:35.401Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "633519651-888491883663691776",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Danke für den Hinweis und den Retweet! Ich habe die Stelle jetzt eingetragen.",
            "mediaUrls" : [ ],
            "senderId" : "888491883663691776",
            "id" : "1593540427604525060",
            "createdAt" : "2022-11-18T09:43:39.175Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "888491883663691776",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/bF4hO3cdz9",
                "expanded" : "https://jobs.openbiblio.eu/eingabe-formular",
                "display" : "jobs.openbiblio.eu/eingabe-formul…"
              }
            ],
            "text" : "Hm, die Stelle ist noch gar nicht bei uns eingetragen. Bitte nachholen, dann wird sie automatisch getwittert und getrötet. https://t.co/bF4hO3cdz9",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1593222032812134406",
            "createdAt" : "2022-11-17T12:38:27.991Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/cOVIm0BE89",
                "expanded" : "https://twitter.com/StBibCharlowilm/status/1593189611563778048",
                "display" : "twitter.com/StBibCharlowil…"
              }
            ],
            "text" : "Liebes Team,\nwir würden uns über eine Erwähnung unserer (verlängerten) Ausschreibung auf Ihrem Account freuen! \nLiebe Grüße \nTabea Bader https://t.co/cOVIm0BE89",
            "mediaUrls" : [ ],
            "senderId" : "888491883663691776",
            "id" : "1593202994685874181",
            "createdAt" : "2022-11-17T11:22:48.933Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "633519651-928980309940559872",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "928980309940559872",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "👍😀 Ebenfalls ein sonniges Wochenende!",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1552993668285562884",
            "createdAt" : "2022-07-29T12:25:18.441Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ABER JETZT! Wirklich! Danke und schönes Wochenende!",
            "mediaUrls" : [ ],
            "senderId" : "928980309940559872",
            "id" : "1552991182082433029",
            "createdAt" : "2022-07-29T12:15:25.669Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Eijeijei, in Frankfurt ist es schon wieder viel zu warm. Dankeschön noch mal. Die Kollegin tauscht es aus.",
            "mediaUrls" : [ ],
            "senderId" : "928980309940559872",
            "id" : "1552988271671746564",
            "createdAt" : "2022-07-29T12:03:51.778Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "928980309940559872",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Die Voraussetzung mit der FaMI-Ausbildung ist noch drin!",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1552987043097100292",
            "createdAt" : "2022-07-29T11:58:58.860Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "633519651-1048279470157774848",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Danke, Phu!",
            "mediaUrls" : [ ],
            "senderId" : "1048279470157774848",
            "id" : "1601203157962563589",
            "createdAt" : "2022-12-09T13:12:36.464Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1048279470157774848",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Alles klar. Kein Problem! Ich werde bei der nächsten Aufräumaktion die Seite offline nehmen.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1601153777930829829",
            "createdAt" : "2022-12-09T09:56:23.341Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Phu, hatte ja versprochen mich wieder zu melden. Konnte mit den anderen reden und wir können die Plattform abschalten - für Demozwecke, um zu zeigen, warum wir gescheitert sind reicht auch der Internet-Archive-Crawl...\n\nDANKE, dass du uns das technisch ermöglichst hast. Ich weiß das wirklich sehr zu schätzen! Tut mir Leid, dass du dich so lange damit rumärgern musstest...",
            "mediaUrls" : [ ],
            "senderId" : "1048279470157774848",
            "id" : "1600919241850589188",
            "createdAt" : "2022-12-08T18:24:25.599Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1048279470157774848",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja, kein Problem. Dann ziehe ich noch eine Weile die Updates für die Seite.",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1590655898611064841",
            "createdAt" : "2022-11-10T10:41:33.868Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "633519651",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Phu, an sich nicht - aber gibst du mir noch etwas Zeit? Das IBI hat mich gefragt, ob ich ein Praxisseminar zum Thema Praktikumsplattform mit übernehme. Da könnte dieses Projekt zumindest als Erfahrungsquelle helfen, \"fail positive\" und so. Ich klär es ab und meld mich spätestens Ende Dezember, wäre das okay?",
            "mediaUrls" : [ ],
            "senderId" : "1048279470157774848",
            "id" : "1590619179924787204",
            "createdAt" : "2022-11-10T08:15:39.468Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1048279470157774848",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/COtqYBB1XE",
                "expanded" : "http://students.openbiblio.eu/",
                "display" : "students.openbiblio.eu"
              }
            ],
            "text" : "Hi Luis, was dagegen, wenn ich demnächst https://t.co/COtqYBB1XE abschalte? Bei den vielen Plugins tauchen da immer wieder Sicherheitslücken auf. \nVG Phu",
            "mediaUrls" : [ ],
            "senderId" : "633519651",
            "id" : "1587407386762952710",
            "createdAt" : "2022-11-01T11:33:08.402Z"
          }
        }
      ]
    }
  }
]